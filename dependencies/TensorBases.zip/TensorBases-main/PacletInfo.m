(* ::Package:: *)

PacletObject[
    <|
        "Name" -> "TensorBases",
        "Version" -> "1.0.0",
        "WolframVersion" -> "13.3+",
        "Extensions" ->
            {
                {
                    "Kernel",
                    "Context" -> {
                        { "TensorBases`" , "TensorBases.m" }
                    }
                },
                {
                    "Documentation",
                    "Language" -> "English"
                }
            }
    |>
]
