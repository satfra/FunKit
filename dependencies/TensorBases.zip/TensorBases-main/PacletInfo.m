(* ::Package:: *)

PacletObject[<|"Name" -> "TensorBases", "Version" -> "1.3.0", "WolframVersion" -> "11.0+", "Extensions" -> {{"Kernel", "Context" -> {{"TensorBases`", "TensorBases.m"}}}, {"Documentation", "Language" -> "English"}}|>]
