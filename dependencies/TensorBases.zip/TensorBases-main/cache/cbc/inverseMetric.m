(* Created with the Wolfram Language : www.wolfram.com *)
{{(-1 + Global`Nc^2)^(-1)}}
