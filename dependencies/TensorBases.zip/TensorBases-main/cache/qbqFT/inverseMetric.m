(* Created with the Wolfram Language : www.wolfram.com *)
{{-1/4*1/(Global`Nc*Global`Nf), 0, 0}, 
 {0, 1/(4*Global`Nc*Global`Nf*TBsps[Global`p1, Global`p1]), 0}, 
 {0, 0, 1/(4*Global`Nc*Global`Nf)}}
