(* Created with the Wolfram Language : www.wolfram.com *)
{{-1/12*1/Global`Nf, 0, 0}, {0, 1/(12*Global`Nf*TBsps[Global`p1, Global`p1]), 
  0}, {0, 0, 1/(12*Global`Nf)}}
