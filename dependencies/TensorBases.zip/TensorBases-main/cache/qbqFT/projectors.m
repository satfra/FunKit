(* Created with the Wolfram Language : www.wolfram.com *)
{((-1/4*I)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
   TBgamma[0, Global`d1, Global`d2])/(Global`Nc*Global`Nf), 
 ((I/4)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
   TBgamma[Global`mu$33, Global`d1, Global`d2]*
   TBvecs[Global`p1, Global`mu$33])/(Global`Nc*Global`Nf*
   TBsps[Global`p1, Global`p1]), (TBdeltaDirac[Global`d1, Global`d2]*
   TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`flavor, Global`F1, Global`F2])/(4*Global`Nc*Global`Nf)}
