(* Created with the Wolfram Language : www.wolfram.com *)
{I*TBdeltaFund[Global`color, Global`A1, Global`A2]*
  TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
  TBgamma[0, Global`d1, Global`d2], 
 I*TBdeltaFund[Global`color, Global`A1, Global`A2]*
  TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
  TBgamma[Global`mu$851816, Global`d1, Global`d2]*
  TBvecs[Global`p1, Global`mu$851816], TBdeltaDirac[Global`d1, Global`d2]*
  TBdeltaFund[Global`color, Global`A1, Global`A2]*
  TBdeltaFund[Global`flavor, Global`F1, Global`F2]}
