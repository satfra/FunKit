(* Created with the Wolfram Language : www.wolfram.com *)
{{Global`Nc/(8 - 60*Global`Nc^2 + 52*Global`Nc^4), 0}, 
 {0, Global`Nc/(96*(-1 + Global`Nc^2)*
    ((-2 + Global`Nc^2)*TBsp[Global`p1, Global`p1] + 
     (-3 + 2*Global`Nc^2)*TBsp[Global`p1, Global`p3] - 
     TBsp[Global`p1, Global`p4] + (-1 + Global`Nc^2)*
      TBsp[Global`p3, Global`p3] - TBsp[Global`p3, Global`p4]))}}
