(* Created with the Wolfram Language : www.wolfram.com *)
{{Global`Nc/(8*Global`Nf - 60*Global`Nc^2*Global`Nf + 
    52*Global`Nc^4*Global`Nf), 0}, 
 {0, Global`Nc/(96*(-1 + Global`Nc^2)*Global`Nf*
    ((-2 + Global`Nc^2)*TBsp[Global`p1, Global`p1] + 
     (-3 + 2*Global`Nc^2)*TBsp[Global`p1, Global`p3] - 
     TBsp[Global`p1, Global`p4] + (-1 + Global`Nc^2)*
      TBsp[Global`p3, Global`p3] - TBsp[Global`p3, Global`p4]))}}
