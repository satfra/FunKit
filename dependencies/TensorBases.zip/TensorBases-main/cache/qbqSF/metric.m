(* Created with the Wolfram Language : www.wolfram.com *)
{{4*Global`Nc*TBsp[Global`p1, Global`p1], 0}, {0, 4*Global`Nc}}
