(* Created with the Wolfram Language : www.wolfram.com *)
{I*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`nu, Global`d2, Global`d3]*TBT[Global`color, Global`a1, 
   Global`A2, Global`A3]*Global`transProj[-Global`p2 - Global`p3, Global`mu, 
   Global`nu], TBdeltaDirac[Global`d2, Global`d3]*
  TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`nu] - TBvec[Global`p3, Global`nu])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`nu], 
 (TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
   (TBgamma[Global`nu, Global`dint2$5129, Global`d3]*
     TBgamma[Global`rho, Global`d2, Global`dint2$5129] - 
    TBgamma[Global`nu, Global`d2, Global`dint1$5129]*
     TBgamma[Global`rho, Global`dint1$5129, Global`d3])*
   TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho])*
   Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`nu])/2, 
 (TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
   (TBgamma[Global`mu, Global`dint2$5131, Global`d3]*
     TBgamma[Global`rho, Global`d2, Global`dint2$5131] - 
    TBgamma[Global`mu, Global`d2, Global`dint1$5131]*
     TBgamma[Global`rho, Global`dint1$5131, Global`d3])*
   TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   (-TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho]))/2, 
 I*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`mu$5133, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (-TBvec[Global`p2, Global`mu$5133] - TBvec[Global`p3, Global`mu$5133])*
  (TBvec[Global`p2, Global`nu] - TBvec[Global`p3, Global`nu])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`nu], 
 (-I)*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`nu, Global`d2, Global`d3]*(-TBsp[Global`p2, Global`p2] + 
   TBsp[Global`p3, Global`p3])*TBT[Global`color, Global`a1, Global`A2, 
   Global`A3]*(Global`transProj[-Global`p2 - Global`p3, Global`mu, 
    Global`nu] - Global`transProj[-Global`p2 - Global`p3, 
    Global`p2 - Global`p3, Global`mu, Global`nu]), 
 (-1/6*I)*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  ((TBgamma[Global`alpha, Global`dint2$5135, Global`dint]*
      TBgamma[Global`beta, Global`d2, Global`dint2$5135] - 
     TBgamma[Global`alpha, Global`d2, Global`dint1$5135]*
      TBgamma[Global`beta, Global`dint1$5135, Global`dint])*
    TBgamma[Global`mu, Global`dint, Global`d3] + 
   TBgamma[Global`alpha, Global`dint, Global`d3]*
    (TBgamma[Global`beta, Global`dint2$5137, Global`dint]*
      TBgamma[Global`mu, Global`d2, Global`dint2$5137] - 
     TBgamma[Global`beta, Global`d2, Global`dint1$5137]*
      TBgamma[Global`mu, Global`dint1$5137, Global`dint]) + 
   TBgamma[Global`beta, Global`dint, Global`d3]*
    (-(TBgamma[Global`alpha, Global`dint1$5139, Global`dint]*
       TBgamma[Global`mu, Global`d2, Global`dint1$5139]) + 
     TBgamma[Global`alpha, Global`d2, Global`dint2$5139]*
      TBgamma[Global`mu, Global`dint2$5139, Global`dint]))*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  TBvec[Global`p3, Global`alpha]*(2*TBvec[Global`p2, Global`beta] + 
   TBvec[Global`p3, Global`beta]), 
 -1/2*(TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
   (TBgamma[Global`nu, Global`dint1$5141, Global`d3]*
     TBgamma[Global`rho, Global`d2, Global`dint1$5141] - 
    TBgamma[Global`nu, Global`d2, Global`dint2$5141]*
     TBgamma[Global`rho, Global`dint2$5141, Global`d3])*
   (-TBsp[Global`p2, Global`p2] + TBsp[Global`p3, Global`p3])*
   TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   (-TBvec[Global`p2, Global`nu] - TBvec[Global`p3, Global`nu])*
   Global`transProj[-Global`p2 - Global`p3, Global`p2 - Global`p3, Global`mu, 
    Global`rho]), I*Global`longProj[-Global`p2 - Global`p3, Global`mu, 
   Global`rho]*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`rho, Global`d2, Global`d3]*TBT[Global`color, Global`a1, 
   Global`A2, Global`A3], Global`longProj[-Global`p2 - Global`p3, Global`mu, 
   Global`rho]*TBdeltaDirac[Global`d2, Global`d3]*
  TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho]), 
 (-I)*Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho]*
  TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`mu$5143, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`mu$5143] - TBvec[Global`p3, Global`mu$5143])*
  (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho]), 
 (Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho]*
   TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
   TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   (-(TBgamma[Global`mu$5145, Global`md1, Global`d3]*
      TBgamma[Global`mu$5147, Global`d2, Global`md1]*
      TBvec[Global`p2, Global`mu$5145]*TBvec[Global`p3, Global`mu$5147]) + 
    TBgamma[Global`mu$5149, Global`d2, Global`md1]*TBgamma[Global`mu$5151, 
      Global`md1, Global`d3]*TBvec[Global`p2, Global`mu$5149]*
     TBvec[Global`p3, Global`mu$5151])*(TBvec[Global`p2, Global`rho] - 
    TBvec[Global`p3, Global`rho]))/2}
