(* Created with the Wolfram Language : www.wolfram.com *)
{(((-(TBdeltaLorentz[Global`v1$12575, Global`v4$12584]*
        TBdeltaLorentz[Global`v2$12578, Global`v3$12581]) + 
      TBdeltaLorentz[Global`v1$12575, Global`v3$12581]*
       TBdeltaLorentz[Global`v2$12578, Global`v4$12584])*
     TBF[Global`color, Global`i$12587, Global`a1, Global`a2]*
     TBF[Global`color, Global`i$12587, Global`a3, Global`a4] + 
    (-(TBdeltaLorentz[Global`v1$12575, Global`v4$12584]*
        TBdeltaLorentz[Global`v2$12578, Global`v3$12581]) + 
      TBdeltaLorentz[Global`v1$12575, Global`v2$12578]*
       TBdeltaLorentz[Global`v3$12581, Global`v4$12584])*
     TBF[Global`color, Global`i$12590, Global`a1, Global`a3]*
     TBF[Global`color, Global`i$12590, Global`a2, Global`a4] + 
    (-(TBdeltaLorentz[Global`v1$12575, Global`v3$12581]*
        TBdeltaLorentz[Global`v2$12578, Global`v4$12584]) + 
      TBdeltaLorentz[Global`v1$12575, Global`v2$12578]*
       TBdeltaLorentz[Global`v3$12581, Global`v4$12584])*
     TBF[Global`color, Global`i$12593, Global`a1, Global`a4]*
     TBF[Global`color, Global`i$12593, Global`a2, Global`a3])*
   TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
   TBsp[Global`p3, Global`p3]*TBsp[Global`p4, Global`p4]*
   Global`transProj[Global`p1, Global`mu, Global`v1$12575]*
   Global`transProj[Global`p2, Global`nu, Global`v2$12578]*
   Global`transProj[Global`p3, Global`rho, Global`v3$12581]*
   Global`transProj[Global`p4, Global`sig, Global`v4$12584])/
  (216*(-(TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p4]^2*
      TBsp[Global`p3, Global`p3]) + TBsp[Global`p1, Global`p4]^2*
     (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
       TBsp[Global`p3, Global`p3]) + 3*TBsp[Global`p1, Global`p1]*
     TBsp[Global`p2, Global`p3]*TBsp[Global`p2, Global`p4]*
     TBsp[Global`p3, Global`p4] + TBsp[Global`p1, Global`p2]^2*
     TBsp[Global`p3, Global`p4]^2 - TBsp[Global`p1, Global`p1]*
     TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p4]^2 - 
    TBsp[Global`p1, Global`p4]*(TBsp[Global`p1, Global`p3]*
       (TBsp[Global`p2, Global`p3]*TBsp[Global`p2, Global`p4] - 
        3*TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p4]) + 
      TBsp[Global`p1, Global`p2]*(-3*TBsp[Global`p2, Global`p4]*
         TBsp[Global`p3, Global`p3] + TBsp[Global`p2, Global`p3]*
         TBsp[Global`p3, Global`p4])) - 
    (TBsp[Global`p1, Global`p2]^2*TBsp[Global`p3, Global`p3] + 
      TBsp[Global`p1, Global`p1]*(TBsp[Global`p2, Global`p3]^2 - 
        12*TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3]))*
     TBsp[Global`p4, Global`p4] + TBsp[Global`p1, Global`p3]^2*
     (TBsp[Global`p2, Global`p4]^2 - TBsp[Global`p2, Global`p2]*
       TBsp[Global`p4, Global`p4]) + TBsp[Global`p1, Global`p2]*
     TBsp[Global`p1, Global`p3]*
     (-(TBsp[Global`p2, Global`p4]*TBsp[Global`p3, Global`p4]) + 
      3*TBsp[Global`p2, Global`p3]*TBsp[Global`p4, Global`p4])))}
