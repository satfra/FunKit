(* Created with the Wolfram Language : www.wolfram.com *)
{((-(TBdeltaLorentz[Global`v1, Global`v4]*TBdeltaLorentz[Global`v2, 
        Global`v3]) + TBdeltaLorentz[Global`v1, Global`v3]*
      TBdeltaLorentz[Global`v2, Global`v4])*TBF[Global`color, 
     Global`i$127956, Global`a1, Global`a2]*TBF[Global`color, 
     Global`i$127956, Global`a3, Global`a4] + 
   (-(TBdeltaLorentz[Global`v1, Global`v4]*TBdeltaLorentz[Global`v2, 
        Global`v3]) + TBdeltaLorentz[Global`v1, Global`v2]*
      TBdeltaLorentz[Global`v3, Global`v4])*TBF[Global`color, 
     Global`i$127957, Global`a1, Global`a3]*TBF[Global`color, 
     Global`i$127957, Global`a2, Global`a4] + 
   (-(TBdeltaLorentz[Global`v1, Global`v3]*TBdeltaLorentz[Global`v2, 
        Global`v4]) + TBdeltaLorentz[Global`v1, Global`v2]*
      TBdeltaLorentz[Global`v3, Global`v4])*TBF[Global`color, 
     Global`i$127958, Global`a1, Global`a4]*TBF[Global`color, 
     Global`i$127958, Global`a2, Global`a3])*Global`transProj[Global`p1, 
   Global`mu, Global`v1]*Global`transProj[Global`p2, Global`nu, Global`v2]*
  Global`transProj[Global`p3, Global`rho, Global`v3]*
  Global`transProj[Global`p4, Global`sig, Global`v4]}
