(* Created with the Wolfram Language : www.wolfram.com *)
{((3*Global`Nc^2*Global`Nf^2*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[Global`\[Mu]$11881, Global`d1, Global`d2]*
       TBgamma[Global`\[Mu]$11881, Global`d3, Global`d4] - 
      TBgamma[Global`\[Mu]$11881, Global`d1, Global`dc$11884]*
       TBgamma[Global`\[Mu]$11881, Global`d3, Global`dc$11887]*
       TBgamma5[Global`dc$11884, Global`d2]*TBgamma5[Global`dc$11887, 
        Global`d4]))/(-1 + Global`Nc^2) + 
   (2*(2 + Global`Nc*(-4*Global`Nf + Global`Nc*(-2 + 7*Global`Nc*Global`Nf)))*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4]*
       TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      2*Global`Nf*TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
        Global`d4]*TBT[Global`flavor, Global`f$11808, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$11808, Global`F3, Global`F4]))/
    (-1 + Global`Nc^2) + 
   (2*(2 + Global`Nc*(-2*Global`Nc + (-4 + Global`Nc^2)*Global`Nf))*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] - 
      2*Global`Nf*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
        Global`d4]*TBT[Global`flavor, Global`f$11824, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$11824, Global`F3, Global`F4]))/
    (-1 + Global`Nc^2) - 8*Global`Nc*(TBdeltaDirac[Global`d1, Global`d2]*
      TBdeltaDirac[Global`d3, Global`d4] + TBgamma5[Global`d1, Global`d2]*
      TBgamma5[Global`d3, Global`d4])*TBT[Global`color, Global`a$11840, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$11840, Global`A3, 
     Global`A4]*(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     2*Global`Nf*TBT[Global`flavor, Global`f$11843, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$11843, Global`F3, Global`F4]) + 
   (4*(Global`Nf + 2*Global`Nc*(-2 + Global`Nf^2))*TBdeltaFund[Global`color, 
      Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] + 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      2*Global`Nf*TBT[Global`flavor, Global`f$11928, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$11928, Global`F3, Global`F4]))/Global`Nf + 
   8*Global`Nc*(TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
       Global`d4] + TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
       Global`d4])*TBT[Global`color, Global`a$11944, Global`A1, Global`A2]*
    TBT[Global`color, Global`a$11944, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
     2*Global`Nf*TBT[Global`flavor, Global`f$11947, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$11947, Global`F3, Global`F4]) + 
   (6*Global`Nc*(-2 + Global`Nf^2)*TBdeltaFund[Global`color, Global`A1, 
      Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      2*Global`Nf*TBT[Global`flavor, Global`f$11963, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$11963, Global`F3, Global`F4]))/Global`Nf + 
   (12*Global`Nc^2*(-2 + Global`Nf^2)*(TBdeltaDirac[Global`d1, Global`d2]*
       TBdeltaDirac[Global`d3, Global`d4] - TBgamma5[Global`d1, Global`d2]*
       TBgamma5[Global`d3, Global`d4])*TBT[Global`color, Global`a$11979, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$11979, Global`A3, 
      Global`A4]*(-(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
        TBdeltaFund[Global`flavor, Global`F3, Global`F4]) + 
      2*Global`Nf*TBT[Global`flavor, Global`f$11982, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$11982, Global`F3, Global`F4]))/
    ((-1 + Global`Nc^2)*Global`Nf))/(768*Global`Nc^3*(-1 + Global`Nf^2)), 
 ((3*Global`Nc^2*Global`Nf^2*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[Global`\[Mu]$4248, Global`d1, Global`d2]*
       TBgamma[Global`\[Mu]$4248, Global`d3, Global`d4] - 
      TBgamma[Global`\[Mu]$4248, Global`d1, Global`dc$4251]*
       TBgamma[Global`\[Mu]$4248, Global`d3, Global`dc$4254]*
       TBgamma5[Global`dc$4251, Global`d2]*TBgamma5[Global`dc$4254, 
        Global`d4]))/(-1 + Global`Nc^2) + 
   (2*(2 + Global`Nc*(-2*Global`Nc + (-4 + Global`Nc^2)*Global`Nf))*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (-(TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4]*
        TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
        TBdeltaFund[Global`flavor, Global`F3, Global`F4]) + 
      2*Global`Nf*TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
        Global`d4]*TBT[Global`flavor, Global`f$4175, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$4175, Global`F3, Global`F4]))/
    (-1 + Global`Nc^2) + 
   (2*(2 + Global`Nc*(-4*Global`Nf + Global`Nc*(-2 + 7*Global`Nc*Global`Nf)))*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (-(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
        TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
        TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]) + 
      2*Global`Nf*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
        Global`d4]*TBT[Global`flavor, Global`f$4191, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$4191, Global`F3, Global`F4]))/
    (-1 + Global`Nc^2) + 8*Global`Nc*(TBdeltaDirac[Global`d1, Global`d2]*
      TBdeltaDirac[Global`d3, Global`d4] + TBgamma5[Global`d1, Global`d2]*
      TBgamma5[Global`d3, Global`d4])*TBT[Global`color, Global`a$4207, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$4207, Global`A3, 
     Global`A4]*(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     2*Global`Nf*TBT[Global`flavor, Global`f$4210, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$4210, Global`F3, Global`F4]) - 
   (4*(Global`Nf + 2*Global`Nc*(-2 + Global`Nf^2))*TBdeltaFund[Global`color, 
      Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] + 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      2*Global`Nf*TBT[Global`flavor, Global`f$4295, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$4295, Global`F3, Global`F4]))/Global`Nf - 
   8*Global`Nc*(TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
       Global`d4] + TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
       Global`d4])*TBT[Global`color, Global`a$4311, Global`A1, Global`A2]*
    TBT[Global`color, Global`a$4311, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
     2*Global`Nf*TBT[Global`flavor, Global`f$4314, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$4314, Global`F3, Global`F4]) + 
   (6*Global`Nc*(-2 + Global`Nf^2)*TBdeltaFund[Global`color, Global`A1, 
      Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      2*Global`Nf*TBT[Global`flavor, Global`f$4330, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$4330, Global`F3, Global`F4]))/Global`Nf + 
   (12*Global`Nc^2*(-2 + Global`Nf^2)*(TBdeltaDirac[Global`d1, Global`d2]*
       TBdeltaDirac[Global`d3, Global`d4] - TBgamma5[Global`d1, Global`d2]*
       TBgamma5[Global`d3, Global`d4])*TBT[Global`color, Global`a$4346, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$4346, Global`A3, 
      Global`A4]*(-(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
        TBdeltaFund[Global`flavor, Global`F3, Global`F4]) + 
      2*Global`Nf*TBT[Global`flavor, Global`f$4349, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$4349, Global`F3, Global`F4]))/
    ((-1 + Global`Nc^2)*Global`Nf))/(768*Global`Nc^3*(-1 + Global`Nf^2)), 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*(-(TBdeltaDirac[Global`d1, Global`d2]*
       TBdeltaDirac[Global`d3, Global`d4]*TBdeltaFund[Global`flavor, 
        Global`F1, Global`F2]*TBdeltaFund[Global`flavor, Global`F3, 
        Global`F4]) + 2*Global`Nf*TBgamma5[Global`d1, Global`d2]*
      TBgamma5[Global`d3, Global`d4]*TBT[Global`flavor, Global`f$4239, 
       Global`F1, Global`F2]*TBT[Global`flavor, Global`f$4239, Global`F3, 
       Global`F4]) + TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (-(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]) + 
     2*Global`Nf*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
       Global`d4]*TBT[Global`flavor, Global`f$4255, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$4255, Global`F3, Global`F4]) + 
   (2*Global`Nc*(1 + 2*Global`Nc*Global`Nf)*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] + 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$4271, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$4271, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      2*Global`Nf*TBT[Global`flavor, Global`f$4274, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$4274, Global`F3, Global`F4]))/
    (-1 + Global`Nc^2) + TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] + 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
     2*Global`Nf*TBT[Global`flavor, Global`f$4359, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$4359, Global`F3, Global`F4]) - 
   (2*Global`Nc*(Global`Nf - 2*Global`Nc*(-2 + Global`Nf^2))*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] + 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$4375, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$4375, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      2*Global`Nf*TBT[Global`flavor, Global`f$4378, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$4378, Global`F3, Global`F4]))/
    ((-1 + Global`Nc^2)*Global`Nf))/(96*Global`Nc^2*(-1 + Global`Nf^2)), 
 (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
   TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
   ((-1 + Global`Nc*Global`Nf)*TBdeltaFund[Global`color, Global`A1, 
      Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBgamma[Global`\[Mu]$4608, Global`d1, Global`d2]*
       TBgamma[Global`\[Mu]$4608, Global`d3, Global`d4] + 
      TBgamma[Global`\[Mu]$4608, Global`d1, Global`dc$4611]*
       TBgamma[Global`\[Mu]$4608, Global`d3, Global`dc$4614]*
       TBgamma5[Global`dc$4611, Global`d2]*TBgamma5[Global`dc$4614, 
        Global`d4]) - 2*Global`Nc*(TBgamma[Global`\[Mu]$4652, Global`d1, 
        Global`d2]*TBgamma[Global`\[Mu]$4652, Global`d3, Global`d4] + 
      TBgamma[Global`\[Mu]$4652, Global`d1, Global`dc$4655]*
       TBgamma[Global`\[Mu]$4652, Global`d3, Global`dc$4658]*
       TBgamma5[Global`dc$4655, Global`d2]*TBgamma5[Global`dc$4658, 
        Global`d4])*TBT[Global`color, Global`a$4661, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$4661, Global`A3, Global`A4]))/
  (128*Global`Nc^3*(-1 + Global`Nf^2)), 
 (Global`Nf^2*TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (Global`Nc*Global`Nf*TBgamma[Global`\[Mu]$4959, Global`d1, Global`d2]*
        TBgamma[Global`\[Mu]$4959, Global`d3, Global`d4] - 
       2*TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] - 
       Global`Nc*Global`Nf*TBgamma[Global`\[Mu]$4959, Global`d1, 
         Global`dc$4962]*TBgamma[Global`\[Mu]$4959, Global`d3, 
         Global`dc$4965]*TBgamma5[Global`dc$4962, Global`d2]*
        TBgamma5[Global`dc$4965, Global`d4]) - 
     4*Global`Nf*TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
       Global`d4]*TBT[Global`flavor, Global`f$4886, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$4886, Global`F3, Global`F4]) + 
   4*Global`Nc*(-2 + Global`Nf^2)*TBgamma5[Global`d1, Global`d2]*
    TBgamma5[Global`d3, Global`d4]*TBT[Global`color, Global`a$5057, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$5057, Global`A3, 
     Global`A4]*(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     2*Global`Nf*TBT[Global`flavor, Global`f$5060, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$5060, Global`F3, Global`F4]) + 
   2*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4]*
    (Global`Nf^2*TBdeltaFund[Global`color, Global`A1, Global`A2]*
      TBdeltaFund[Global`color, Global`A3, Global`A4]*
      (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
        TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
       2*Global`Nf*TBT[Global`flavor, Global`f$4902, Global`F1, Global`F2]*
        TBT[Global`flavor, Global`f$4902, Global`F3, Global`F4]) + 
     2*Global`Nc*(-2 + Global`Nf^2)*TBT[Global`color, Global`a$5057, 
       Global`A1, Global`A2]*TBT[Global`color, Global`a$5057, Global`A3, 
       Global`A4]*(-(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
         TBdeltaFund[Global`flavor, Global`F3, Global`F4]) + 
       2*Global`Nf*TBT[Global`flavor, Global`f$5060, Global`F1, Global`F2]*
        TBT[Global`flavor, Global`f$5060, Global`F3, Global`F4])))/
  (512*Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf^2)), 
 (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
   TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
   (-((-1 + Global`Nc^2)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
      TBdeltaFund[Global`color, Global`A3, Global`A4]*
      (TBgamma[Global`\[Mu]$4593, Global`d1, Global`d2]*
        TBgamma[Global`\[Mu]$4593, Global`d3, Global`d4] + 
       TBgamma[Global`\[Mu]$4593, Global`d1, Global`dc$4596]*
        TBgamma[Global`\[Mu]$4593, Global`d3, Global`dc$4599]*
        TBgamma5[Global`dc$4596, Global`d2]*TBgamma5[Global`dc$4599, 
         Global`d4])) + 2*Global`Nc*(1 + Global`Nc*Global`Nf)*
     (TBgamma[Global`\[Mu]$4637, Global`d1, Global`d2]*
       TBgamma[Global`\[Mu]$4637, Global`d3, Global`d4] + 
      TBgamma[Global`\[Mu]$4637, Global`d1, Global`dc$4640]*
       TBgamma[Global`\[Mu]$4637, Global`d3, Global`dc$4643]*
       TBgamma5[Global`dc$4640, Global`d2]*TBgamma5[Global`dc$4643, 
        Global`d4])*TBT[Global`color, Global`a$4646, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$4646, Global`A3, Global`A4]))/
  (64*Global`Nc^2*(-1 + Global`Nc^2)*(-1 + Global`Nf^2)), 
 (Global`Nf*(Global`Nf + 2*Global`Nc*(-2 + Global`Nf^2))*
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4]*
      TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     2*Global`Nf*TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
       Global`d4]*TBT[Global`flavor, Global`f$4137, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$4137, Global`F3, Global`F4]) + 
   Global`Nf*(Global`Nf + 2*Global`Nc*(-2 + Global`Nf^2))*
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] - 
     2*Global`Nf*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
       Global`d4]*TBT[Global`flavor, Global`f$4153, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$4153, Global`F3, Global`F4]) + 
   2*Global`Nc*Global`Nf^2*(TBdeltaDirac[Global`d1, Global`d2]*
      TBdeltaDirac[Global`d3, Global`d4] + TBgamma5[Global`d1, Global`d2]*
      TBgamma5[Global`d3, Global`d4])*TBT[Global`color, Global`a$4169, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$4169, Global`A3, 
     Global`A4]*(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     2*Global`Nf*TBT[Global`flavor, Global`f$4172, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$4172, Global`F3, Global`F4]) + 
   (-4 + Global`Nf^2*(3 + 2*Global`Nc*Global`Nf))*TBdeltaFund[Global`color, 
     Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] + 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
     2*Global`Nf*TBT[Global`flavor, Global`f$4257, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$4257, Global`F3, Global`F4]) + 
   2*Global`Nc*(-4 + 3*Global`Nf^2)*(TBdeltaDirac[Global`d1, Global`d2]*
      TBdeltaDirac[Global`d3, Global`d4] + TBgamma5[Global`d1, Global`d2]*
      TBgamma5[Global`d3, Global`d4])*TBT[Global`color, Global`a$4273, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$4273, Global`A3, 
     Global`A4]*(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
     2*Global`Nf*TBT[Global`flavor, Global`f$4276, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$4276, Global`F3, Global`F4]))/
  (192*Global`Nc^3*Global`Nf^2*(-1 + Global`Nf^2)), 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*(TBdeltaDirac[Global`d1, Global`d2]*
      TBdeltaDirac[Global`d3, Global`d4]*TBdeltaFund[Global`flavor, 
       Global`F1, Global`F2]*TBdeltaFund[Global`flavor, Global`F3, 
       Global`F4] - 2*Global`Nf*TBgamma5[Global`d1, Global`d2]*
      TBgamma5[Global`d3, Global`d4]*TBT[Global`flavor, Global`f$4162, 
       Global`F1, Global`F2]*TBT[Global`flavor, Global`f$4162, Global`F3, 
       Global`F4]) + TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] - 
     2*Global`Nf*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
       Global`d4]*TBT[Global`flavor, Global`f$4178, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$4178, Global`F3, Global`F4]) - 
   (2*Global`Nc*(Global`Nf - 2*Global`Nc*(-2 + Global`Nf^2))*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] + 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$4194, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$4194, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      2*Global`Nf*TBT[Global`flavor, Global`f$4197, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$4197, Global`F3, Global`F4]))/
    ((-1 + Global`Nc^2)*Global`Nf) + 
   ((-4 + 3*Global`Nf^2)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] + 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      2*Global`Nf*TBT[Global`flavor, Global`f$4282, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$4282, Global`F3, Global`F4]))/
    Global`Nf^2 + (2*Global`Nc*(4 + Global`Nf^2*(-3 + 2*Global`Nc*Global`Nf))*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] + 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$4298, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$4298, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      2*Global`Nf*TBT[Global`flavor, Global`f$4301, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$4301, Global`F3, Global`F4]))/
    ((-1 + Global`Nc^2)*Global`Nf^2))/(96*Global`Nc^2*(-1 + Global`Nf^2)), 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`color, Global`A3, Global`A4]*
   (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4]*
     ((-1 + Global`Nf^2)*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      Global`Nf*(-2 + Global`Nf^2)*TBT[Global`flavor, Global`f$3742, 
        Global`F1, Global`F2]*TBT[Global`flavor, Global`f$3742, Global`F3, 
        Global`F4] - Global`Nf^3*TBT[Global`flavor, Global`f$3881, Global`F1, 
        Global`F2]*TBT[Global`flavor, Global`f$3881, Global`F3, Global`F4]) + 
    TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]*
     (-((-1 + Global`Nf^2)*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
        TBdeltaFund[Global`flavor, Global`F3, Global`F4]) - 
      Global`Nf*(-2 + Global`Nf^2)*TBT[Global`flavor, Global`f$3726, 
        Global`F1, Global`F2]*TBT[Global`flavor, Global`f$3726, Global`F3, 
        Global`F4] + Global`Nf^3*TBT[Global`flavor, Global`f$3881, Global`F1, 
        Global`F2]*TBT[Global`flavor, Global`f$3881, Global`F3, Global`F4])))/
  (64*Global`Nc^2*Global`Nf*(-1 + Global`Nf^2)), 
 -1/128*((-2 + Global`Nf^2)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (Global`Nc*Global`Nf*TBgamma[Global`\[Mu]$3472, Global`d1, Global`d2]*
         TBgamma[Global`\[Mu]$3472, Global`d3, Global`d4] - 
        2*TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] - 
        Global`Nc*Global`Nf*TBgamma[Global`\[Mu]$3472, Global`d1, 
          Global`dc$3475]*TBgamma[Global`\[Mu]$3472, Global`d3, 
          Global`dc$3478]*TBgamma5[Global`dc$3475, Global`d2]*
         TBgamma5[Global`dc$3478, Global`d4]) - 
      4*Global`Nf*TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
        Global`d4]*TBT[Global`flavor, Global`f$3399, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$3399, Global`F3, Global`F4]) + 
    4*Global`Nc*Global`Nf^2*TBgamma5[Global`d1, Global`d2]*
     TBgamma5[Global`d3, Global`d4]*TBT[Global`color, Global`a$3570, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$3570, Global`A3, 
      Global`A4]*(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      2*Global`Nf*TBT[Global`flavor, Global`f$3573, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$3573, Global`F3, Global`F4]) + 
    2*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4]*
     ((-2 + Global`Nf^2)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
       TBdeltaFund[Global`color, Global`A3, Global`A4]*
       (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
         TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
        2*Global`Nf*TBT[Global`flavor, Global`f$3415, Global`F1, Global`F2]*
         TBT[Global`flavor, Global`f$3415, Global`F3, Global`F4]) + 
      2*Global`Nc*Global`Nf^2*TBT[Global`color, Global`a$3570, Global`A1, 
        Global`A2]*TBT[Global`color, Global`a$3570, Global`A3, Global`A4]*
       (-(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
          TBdeltaFund[Global`flavor, Global`F3, Global`F4]) + 
        2*Global`Nf*TBT[Global`flavor, Global`f$3573, Global`F1, Global`F2]*
         TBT[Global`flavor, Global`f$3573, Global`F3, Global`F4])))/
   (Global`Nc*(-1 + Global`Nc^2)*Global`Nf*(-1 + Global`Nf^2))}
