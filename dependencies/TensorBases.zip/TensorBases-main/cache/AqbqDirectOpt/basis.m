(* Created with the Wolfram Language : www.wolfram.com *)
{I*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`rho, Global`d2, Global`d3]*TBT[Global`color, Global`a1, 
   Global`A2, Global`A3]*Global`transProj[-Global`p2 - Global`p3, Global`mu, 
   Global`rho], (Sqrt[3]*TBdeltaDirac[Global`d2, Global`d3]*
   TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
   TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho])*
   Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho])/
  Sqrt[2*TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
    2*TBsp[Global`p3, Global`p3]], 
 (Sqrt[3]*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
   TBgamma[Global`mu$9707, Global`d2, Global`md]*
   TBgamma[Global`rho, Global`md, Global`d3]*TBT[Global`color, Global`a1, 
    Global`A2, Global`A3]*(TBvec[Global`p2, Global`mu$9707] - 
    TBvec[Global`p3, Global`mu$9707])*Global`transProj[
    -Global`p2 - Global`p3, Global`mu, Global`rho])/
  Sqrt[2*TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
    2*TBsp[Global`p3, Global`p3]], 
 -((Sqrt[3]*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
    TBgamma[Global`mu$9709, Global`d2, Global`md]*
    TBgamma[Global`rho, Global`md, Global`d3]*TBT[Global`color, Global`a1, 
     Global`A2, Global`A3]*(TBvec[Global`p2, Global`mu$9709] + 
     TBvec[Global`p3, Global`mu$9709])*Global`transProj[
     -Global`p2 - Global`p3, Global`mu, Global`rho])/
   Sqrt[2*TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
     2*TBsp[Global`p3, Global`p3]]), 
 ((3*I)*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
   TBgamma[Global`mu$9711, Global`d2, Global`d3]*TBT[Global`color, Global`a1, 
    Global`A2, Global`A3]*(TBvec[Global`p2, Global`mu$9711] + 
    TBvec[Global`p3, Global`mu$9711])*(TBvec[Global`p2, Global`rho] - 
    TBvec[Global`p3, Global`rho])*Global`transProj[-Global`p2 - Global`p3, 
    Global`mu, Global`rho])/(2*TBsp[Global`p2, Global`p2] + 
   2*TBsp[Global`p2, Global`p3] + 2*TBsp[Global`p3, Global`p3]), 
 ((-I)*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
   TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   ((4*TBgamma[Global`rho, Global`d2, Global`d3]*
      (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
        TBsp[Global`p3, Global`p3]))/(TBsp[Global`p2, Global`p2] + 
      2*TBsp[Global`p2, Global`p3] + TBsp[Global`p3, Global`p3]) + 
    3*TBgamma[Global`mu$9713, Global`d2, Global`d3]*
     (TBvec[Global`p2, Global`mu$9713] - TBvec[Global`p3, Global`mu$9713])*
     (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho]))*
   Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho])/
  (2*TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
   2*TBsp[Global`p3, Global`p3]), 
 (((3*I)/2)*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
   TBgamma[Global`rho, Global`dint2, Global`d3]*TBT[Global`color, Global`a1, 
    Global`A2, Global`A3]*
   (-(TBgamma[Global`mu$9715, Global`dint1, Global`dint2]*
      TBgamma[Global`mu$9717, Global`d2, Global`dint1]*
      TBvec[Global`p2, Global`mu$9715]*TBvec[Global`p3, Global`mu$9717]) + 
    TBgamma[Global`mu$9719, Global`d2, Global`dint1]*
     TBgamma[Global`mu$9721, Global`dint1, Global`dint2]*
     TBvec[Global`p2, Global`mu$9719]*TBvec[Global`p3, Global`mu$9721])*
   Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho])/
  (2*TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
   2*TBsp[Global`p3, Global`p3]), 
 (3*Sqrt[3]*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
   TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   (-(TBgamma[Global`mu$9723, Global`md1, Global`d3]*
      TBgamma[Global`mu$9725, Global`d2, Global`md1]*
      TBvec[Global`p2, Global`mu$9723]*TBvec[Global`p3, Global`mu$9725]) + 
    TBgamma[Global`mu$9727, Global`d2, Global`md1]*TBgamma[Global`mu$9729, 
      Global`md1, Global`d3]*TBvec[Global`p2, Global`mu$9727]*
     TBvec[Global`p3, Global`mu$9729])*(TBvec[Global`p2, Global`rho] - 
    TBvec[Global`p3, Global`rho])*Global`transProj[-Global`p2 - Global`p3, 
    Global`mu, Global`rho])/
  (2*(2*TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
     2*TBsp[Global`p3, Global`p3])^(3/2)), 
 I*Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho]*
  TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`rho, Global`d2, Global`d3]*TBT[Global`color, Global`a1, 
   Global`A2, Global`A3], Global`longProj[-Global`p2 - Global`p3, Global`mu, 
   Global`rho]*TBdeltaDirac[Global`d2, Global`d3]*
  TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho]), 
 (-I)*Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho]*
  TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`mu$9731, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`mu$9731] - TBvec[Global`p3, Global`mu$9731])*
  (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho]), 
 (Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho]*
   TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
   TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   (-(TBgamma[Global`mu$9733, Global`md1, Global`d3]*
      TBgamma[Global`mu$9735, Global`d2, Global`md1]*
      TBvec[Global`p2, Global`mu$9733]*TBvec[Global`p3, Global`mu$9735]) + 
    TBgamma[Global`mu$9737, Global`d2, Global`md1]*TBgamma[Global`mu$9739, 
      Global`md1, Global`d3]*TBvec[Global`p2, Global`mu$9737]*
     TBvec[Global`p3, Global`mu$9739])*(TBvec[Global`p2, Global`rho] - 
    TBvec[Global`p3, Global`rho]))/2}
