(* Created with the Wolfram Language : www.wolfram.com *)
{{1/(4*Global`Nc*Global`Nf*TBsp[Global`p1, Global`p1]), 0}, 
 {0, 1/(4*Global`Nc*Global`Nf)}}
