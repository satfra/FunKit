(* Created with the Wolfram Language : www.wolfram.com *)
{
 (((-(TBdeltaLorentz[Global`v1$4649, Global`v4$4658]*TBdeltaLorentz[
         Global`v2$4652, Global`v3$4655]) + 
      TBdeltaLorentz[Global`v1$4649, Global`v3$4655]*
       TBdeltaLorentz[Global`v2$4652, Global`v4$4658])*
     TBF[Global`color, Global`i$4661, Global`a1, Global`a2]*
     TBF[Global`color, Global`i$4661, Global`a3, Global`a4] + 
    (-(TBdeltaLorentz[Global`v1$4649, Global`v4$4658]*
        TBdeltaLorentz[Global`v2$4652, Global`v3$4655]) + 
      TBdeltaLorentz[Global`v1$4649, Global`v2$4652]*
       TBdeltaLorentz[Global`v3$4655, Global`v4$4658])*
     TBF[Global`color, Global`i$4664, Global`a1, Global`a3]*
     TBF[Global`color, Global`i$4664, Global`a2, Global`a4] + 
    (-(TBdeltaLorentz[Global`v1$4649, Global`v3$4655]*
        TBdeltaLorentz[Global`v2$4652, Global`v4$4658]) + 
      TBdeltaLorentz[Global`v1$4649, Global`v2$4652]*
       TBdeltaLorentz[Global`v3$4655, Global`v4$4658])*
     TBF[Global`color, Global`i$4667, Global`a1, Global`a4]*
     TBF[Global`color, Global`i$4667, Global`a2, Global`a3])*
   TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
   TBsp[Global`p3, Global`p3]*(TBsp[Global`p1, Global`p1] + 
    2*TBsp[Global`p1, Global`p2] + 2*TBsp[Global`p1, Global`p3] + 
    TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
    TBsp[Global`p3, Global`p3])*Global`transProj[Global`p1, Global`mu, 
    Global`v1$4649]*Global`transProj[Global`p2, Global`nu, Global`v2$4652]*
   Global`transProj[-Global`p1 - Global`p2 - Global`p3, Global`sig, 
    Global`v4$4658]*Global`transProj[Global`p3, Global`rho, Global`v3$4655])/
  (3*Global`Nc^2*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p2]^3*
     TBsp[Global`p3, Global`p3] + 11*TBsp[Global`p1, Global`p1]^2*
     TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3] + 
    TBsp[Global`p1, Global`p2]^2*(TBsp[Global`p1, Global`p3]^2 + 
      5*TBsp[Global`p1, Global`p3]*TBsp[Global`p2, Global`p3] + 
      TBsp[Global`p2, Global`p3]^2 + (TBsp[Global`p1, Global`p1] + 
        2*TBsp[Global`p1, Global`p3] + TBsp[Global`p2, Global`p2] + 
        2*TBsp[Global`p2, Global`p3])*TBsp[Global`p3, Global`p3]) + 
    TBsp[Global`p1, Global`p3]^2*(TBsp[Global`p1, Global`p3]*
       TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p3]^2 + 
      TBsp[Global`p2, Global`p2]*(2*TBsp[Global`p2, Global`p3] + 
        TBsp[Global`p3, Global`p3])) + TBsp[Global`p1, Global`p2]*
     (TBsp[Global`p1, Global`p3]^2*(2*TBsp[Global`p2, Global`p2] + 
        5*TBsp[Global`p2, Global`p3]) + TBsp[Global`p1, Global`p1]*
       (2*TBsp[Global`p2, Global`p3]^2 + (23*TBsp[Global`p2, Global`p2] + 
          3*TBsp[Global`p2, Global`p3])*TBsp[Global`p3, Global`p3]) + 
      TBsp[Global`p1, Global`p3]*(TBsp[Global`p2, Global`p3]*
         (4*(TBsp[Global`p1, Global`p1] + TBsp[Global`p2, Global`p2]) + 
          5*TBsp[Global`p2, Global`p3]) + (3*TBsp[Global`p2, Global`p2] + 
          4*TBsp[Global`p2, Global`p3])*TBsp[Global`p3, Global`p3])) + 
    TBsp[Global`p1, Global`p1]*(TBsp[Global`p1, Global`p3]^2*
       TBsp[Global`p2, Global`p2] + 11*TBsp[Global`p2, Global`p2]^2*
       TBsp[Global`p3, Global`p3] + TBsp[Global`p2, Global`p3]^2*
       (TBsp[Global`p2, Global`p3] + TBsp[Global`p3, Global`p3]) + 
      TBsp[Global`p2, Global`p2]*(TBsp[Global`p2, Global`p3]^2 + 
        23*TBsp[Global`p2, Global`p3]*TBsp[Global`p3, Global`p3] + 
        11*TBsp[Global`p3, Global`p3]^2) + TBsp[Global`p1, Global`p3]*
       (2*TBsp[Global`p2, Global`p3]^2 + TBsp[Global`p2, Global`p2]*
         (3*TBsp[Global`p2, Global`p3] + 23*TBsp[Global`p3, Global`p3]))))), 
 (Global`longProj[-Global`p1 - Global`p2 - Global`p3, Global`sig, 
    Global`v4$5050]*Global`longProj[Global`p3, Global`rho, Global`v3$5047]*
   ((-(TBdeltaLorentz[Global`v1$5041, Global`v4$5050]*
        TBdeltaLorentz[Global`v2$5044, Global`v3$5047]) + 
      TBdeltaLorentz[Global`v1$5041, Global`v3$5047]*
       TBdeltaLorentz[Global`v2$5044, Global`v4$5050])*
     TBF[Global`color, Global`i$5053, Global`a1, Global`a2]*
     TBF[Global`color, Global`i$5053, Global`a3, Global`a4] + 
    (-(TBdeltaLorentz[Global`v1$5041, Global`v4$5050]*
        TBdeltaLorentz[Global`v2$5044, Global`v3$5047]) + 
      TBdeltaLorentz[Global`v1$5041, Global`v2$5044]*
       TBdeltaLorentz[Global`v3$5047, Global`v4$5050])*
     TBF[Global`color, Global`i$5056, Global`a1, Global`a3]*
     TBF[Global`color, Global`i$5056, Global`a2, Global`a4] + 
    (-(TBdeltaLorentz[Global`v1$5041, Global`v3$5047]*
        TBdeltaLorentz[Global`v2$5044, Global`v4$5050]) + 
      TBdeltaLorentz[Global`v1$5041, Global`v2$5044]*
       TBdeltaLorentz[Global`v3$5047, Global`v4$5050])*
     TBF[Global`color, Global`i$5059, Global`a1, Global`a4]*
     TBF[Global`color, Global`i$5059, Global`a2, Global`a3])*
   TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
   TBsp[Global`p3, Global`p3]*(TBsp[Global`p1, Global`p1] + 
    2*TBsp[Global`p1, Global`p2] + 2*TBsp[Global`p1, Global`p3] + 
    TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
    TBsp[Global`p3, Global`p3])*Global`transProj[Global`p1, Global`mu, 
    Global`v1$5041]*Global`transProj[Global`p2, Global`nu, Global`v2$5044])/
  (3*Global`Nc^2*(-1 + Global`Nc^2)*
   (TBsp[Global`p1, Global`p2]*(TBsp[Global`p1, Global`p3]^2*
       (2*TBsp[Global`p2, Global`p2] - TBsp[Global`p2, Global`p3]) + 
      2*TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p3]^2 + 
      TBsp[Global`p1, Global`p3]*TBsp[Global`p2, Global`p3]*
       (TBsp[Global`p1, Global`p1] + TBsp[Global`p2, Global`p2] - 
        TBsp[Global`p2, Global`p3] - 2*TBsp[Global`p3, Global`p3])) + 
    TBsp[Global`p1, Global`p1]^2*TBsp[Global`p2, Global`p2]*
     TBsp[Global`p3, Global`p3] + TBsp[Global`p1, Global`p2]^2*
     (TBsp[Global`p1, Global`p3]^2 - TBsp[Global`p1, Global`p3]*
       TBsp[Global`p2, Global`p3] + TBsp[Global`p2, Global`p3]^2 + 
      (-TBsp[Global`p1, Global`p1] + TBsp[Global`p1, Global`p3] - 
        TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p3])*
       TBsp[Global`p3, Global`p3] + TBsp[Global`p3, Global`p3]^2) + 
    TBsp[Global`p1, Global`p3]^2*(TBsp[Global`p1, Global`p3]*
       TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p3]^2 + 
      TBsp[Global`p2, Global`p2]*(2*TBsp[Global`p2, Global`p3] + 
        TBsp[Global`p3, Global`p3])) + TBsp[Global`p1, Global`p1]*
     (TBsp[Global`p1, Global`p3]^2*TBsp[Global`p2, Global`p2] + 
      TBsp[Global`p2, Global`p2]^2*TBsp[Global`p3, Global`p3] + 
      TBsp[Global`p2, Global`p3]^2*(TBsp[Global`p2, Global`p3] + 
        TBsp[Global`p3, Global`p3]) + TBsp[Global`p2, Global`p2]*
       (TBsp[Global`p2, Global`p3]^2 + 3*TBsp[Global`p2, Global`p3]*
         TBsp[Global`p3, Global`p3] + TBsp[Global`p3, Global`p3]^2) + 
      TBsp[Global`p1, Global`p3]*(2*TBsp[Global`p2, Global`p3]^2 + 
        3*TBsp[Global`p2, Global`p2]*(TBsp[Global`p2, Global`p3] + 
          TBsp[Global`p3, Global`p3]))))), 
 -1/3*(Global`longProj[-Global`p1 - Global`p2 - Global`p3, Global`sig, 
     Global`v4$6000]*((-(TBdeltaLorentz[Global`v1$5991, Global`v4$6000]*
         TBdeltaLorentz[Global`v2$5994, Global`v3$5997]) + 
       TBdeltaLorentz[Global`v1$5991, Global`v3$5997]*
        TBdeltaLorentz[Global`v2$5994, Global`v4$6000])*
      TBF[Global`color, Global`i$6003, Global`a1, Global`a2]*
      TBF[Global`color, Global`i$6003, Global`a3, Global`a4] + 
     (-(TBdeltaLorentz[Global`v1$5991, Global`v4$6000]*
         TBdeltaLorentz[Global`v2$5994, Global`v3$5997]) + 
       TBdeltaLorentz[Global`v1$5991, Global`v2$5994]*
        TBdeltaLorentz[Global`v3$5997, Global`v4$6000])*
      TBF[Global`color, Global`i$6006, Global`a1, Global`a3]*
      TBF[Global`color, Global`i$6006, Global`a2, Global`a4] + 
     (-(TBdeltaLorentz[Global`v1$5991, Global`v3$5997]*
         TBdeltaLorentz[Global`v2$5994, Global`v4$6000]) + 
       TBdeltaLorentz[Global`v1$5991, Global`v2$5994]*
        TBdeltaLorentz[Global`v3$5997, Global`v4$6000])*
      TBF[Global`color, Global`i$6009, Global`a1, Global`a4]*
      TBF[Global`color, Global`i$6009, Global`a2, Global`a3])*
    TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
    TBsp[Global`p3, Global`p3]*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2] + 2*TBsp[Global`p1, Global`p3] + 
     TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
     TBsp[Global`p3, Global`p3])*Global`transProj[Global`p1, Global`mu, 
     Global`v1$5991]*Global`transProj[Global`p2, Global`nu, Global`v2$5994]*
    Global`transProj[Global`p3, Global`rho, Global`v3$5997])/
   (Global`Nc^2*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p2]^3*
      TBsp[Global`p3, Global`p3] - 4*TBsp[Global`p1, Global`p1]^2*
      TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3] + 
     TBsp[Global`p1, Global`p2]^2*(TBsp[Global`p1, Global`p3]^2 - 
       TBsp[Global`p1, Global`p3]*TBsp[Global`p2, Global`p3] + 
       TBsp[Global`p2, Global`p3]^2 + (TBsp[Global`p1, Global`p1] + 
         2*TBsp[Global`p1, Global`p3] + TBsp[Global`p2, Global`p2] + 
         2*TBsp[Global`p2, Global`p3])*TBsp[Global`p3, Global`p3]) + 
     TBsp[Global`p1, Global`p3]^2*(TBsp[Global`p1, Global`p3]*
        TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p3]^2 + 
       TBsp[Global`p2, Global`p2]*(2*TBsp[Global`p2, Global`p3] + 
         TBsp[Global`p3, Global`p3])) + TBsp[Global`p1, Global`p2]*
      (TBsp[Global`p1, Global`p3]^2*(2*TBsp[Global`p2, Global`p2] - 
         TBsp[Global`p2, Global`p3]) + TBsp[Global`p1, Global`p3]*
        ((TBsp[Global`p1, Global`p1] + TBsp[Global`p2, Global`p2] - 
           TBsp[Global`p2, Global`p3])*TBsp[Global`p2, Global`p3] + 
         (3*TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p3])*
          TBsp[Global`p3, Global`p3]) + TBsp[Global`p1, Global`p1]*
        (2*TBsp[Global`p2, Global`p3]^2 + (-7*TBsp[Global`p2, Global`p2] + 
           3*TBsp[Global`p2, Global`p3])*TBsp[Global`p3, Global`p3])) + 
     TBsp[Global`p1, Global`p1]*(TBsp[Global`p1, Global`p3]^2*
        TBsp[Global`p2, Global`p2] + TBsp[Global`p1, Global`p3]*
        (2*TBsp[Global`p2, Global`p3]^2 + TBsp[Global`p2, Global`p2]*
          (3*TBsp[Global`p2, Global`p3] - 7*TBsp[Global`p3, Global`p3])) - 
       4*TBsp[Global`p2, Global`p2]^2*TBsp[Global`p3, Global`p3] + 
       TBsp[Global`p2, Global`p3]^2*(TBsp[Global`p2, Global`p3] + 
         TBsp[Global`p3, Global`p3]) + TBsp[Global`p2, Global`p2]*
        (TBsp[Global`p2, Global`p3]^2 - 7*TBsp[Global`p2, Global`p3]*
          TBsp[Global`p3, Global`p3] - 4*TBsp[Global`p3, Global`p3]^2))))}
