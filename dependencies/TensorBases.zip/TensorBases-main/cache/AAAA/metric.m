(* Created with the Wolfram Language : www.wolfram.com *)
{{(3*Global`Nc^2*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p2]^3*
      TBsp[Global`p3, Global`p3] + 11*TBsp[Global`p1, Global`p1]^2*
      TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3] + 
     TBsp[Global`p1, Global`p2]^2*(TBsp[Global`p1, Global`p3]^2 + 
       5*TBsp[Global`p1, Global`p3]*TBsp[Global`p2, Global`p3] + 
       TBsp[Global`p2, Global`p3]^2 + (TBsp[Global`p1, Global`p1] + 
         2*TBsp[Global`p1, Global`p3] + TBsp[Global`p2, Global`p2] + 
         2*TBsp[Global`p2, Global`p3])*TBsp[Global`p3, Global`p3]) + 
     TBsp[Global`p1, Global`p3]^2*(TBsp[Global`p1, Global`p3]*
        TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p3]^2 + 
       TBsp[Global`p2, Global`p2]*(2*TBsp[Global`p2, Global`p3] + 
         TBsp[Global`p3, Global`p3])) + TBsp[Global`p1, Global`p2]*
      (TBsp[Global`p1, Global`p3]^2*(2*TBsp[Global`p2, Global`p2] + 
         5*TBsp[Global`p2, Global`p3]) + TBsp[Global`p1, Global`p1]*
        (2*TBsp[Global`p2, Global`p3]^2 + (23*TBsp[Global`p2, Global`p2] + 
           3*TBsp[Global`p2, Global`p3])*TBsp[Global`p3, Global`p3]) + 
       TBsp[Global`p1, Global`p3]*(TBsp[Global`p2, Global`p3]*
          (4*(TBsp[Global`p1, Global`p1] + TBsp[Global`p2, Global`p2]) + 
           5*TBsp[Global`p2, Global`p3]) + (3*TBsp[Global`p2, Global`p2] + 
           4*TBsp[Global`p2, Global`p3])*TBsp[Global`p3, Global`p3])) + 
     TBsp[Global`p1, Global`p1]*(TBsp[Global`p1, Global`p3]^2*
        TBsp[Global`p2, Global`p2] + 11*TBsp[Global`p2, Global`p2]^2*
        TBsp[Global`p3, Global`p3] + TBsp[Global`p2, Global`p3]^2*
        (TBsp[Global`p2, Global`p3] + TBsp[Global`p3, Global`p3]) + 
       TBsp[Global`p2, Global`p2]*(TBsp[Global`p2, Global`p3]^2 + 
         23*TBsp[Global`p2, Global`p3]*TBsp[Global`p3, Global`p3] + 
         11*TBsp[Global`p3, Global`p3]^2) + TBsp[Global`p1, Global`p3]*
        (2*TBsp[Global`p2, Global`p3]^2 + TBsp[Global`p2, Global`p2]*
          (3*TBsp[Global`p2, Global`p3] + 23*TBsp[Global`p3, Global`p3])))))/
   (TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
    TBsp[Global`p3, Global`p3]*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2] + 2*TBsp[Global`p1, Global`p3] + 
     TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
     TBsp[Global`p3, Global`p3])), 0, 0}, 
 {0, (3*Global`Nc^2*(-1 + Global`Nc^2)*
    (TBsp[Global`p1, Global`p2]*(TBsp[Global`p1, Global`p3]^2*
        (2*TBsp[Global`p2, Global`p2] - TBsp[Global`p2, Global`p3]) + 
       2*TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p3]^2 + 
       TBsp[Global`p1, Global`p3]*TBsp[Global`p2, Global`p3]*
        (TBsp[Global`p1, Global`p1] + TBsp[Global`p2, Global`p2] - 
         TBsp[Global`p2, Global`p3] - 2*TBsp[Global`p3, Global`p3])) + 
     TBsp[Global`p1, Global`p1]^2*TBsp[Global`p2, Global`p2]*
      TBsp[Global`p3, Global`p3] + TBsp[Global`p1, Global`p2]^2*
      (TBsp[Global`p1, Global`p3]^2 - TBsp[Global`p1, Global`p3]*
        TBsp[Global`p2, Global`p3] + TBsp[Global`p2, Global`p3]^2 + 
       (-TBsp[Global`p1, Global`p1] + TBsp[Global`p1, Global`p3] - 
         TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p3])*
        TBsp[Global`p3, Global`p3] + TBsp[Global`p3, Global`p3]^2) + 
     TBsp[Global`p1, Global`p3]^2*(TBsp[Global`p1, Global`p3]*
        TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p3]^2 + 
       TBsp[Global`p2, Global`p2]*(2*TBsp[Global`p2, Global`p3] + 
         TBsp[Global`p3, Global`p3])) + TBsp[Global`p1, Global`p1]*
      (TBsp[Global`p1, Global`p3]^2*TBsp[Global`p2, Global`p2] + 
       TBsp[Global`p2, Global`p2]^2*TBsp[Global`p3, Global`p3] + 
       TBsp[Global`p2, Global`p3]^2*(TBsp[Global`p2, Global`p3] + 
         TBsp[Global`p3, Global`p3]) + TBsp[Global`p2, Global`p2]*
        (TBsp[Global`p2, Global`p3]^2 + 3*TBsp[Global`p2, Global`p3]*
          TBsp[Global`p3, Global`p3] + TBsp[Global`p3, Global`p3]^2) + 
       TBsp[Global`p1, Global`p3]*(2*TBsp[Global`p2, Global`p3]^2 + 
         3*TBsp[Global`p2, Global`p2]*(TBsp[Global`p2, Global`p3] + 
           TBsp[Global`p3, Global`p3])))))/(TBsp[Global`p1, Global`p1]*
    TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3]*
    (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
     2*TBsp[Global`p1, Global`p3] + TBsp[Global`p2, Global`p2] + 
     2*TBsp[Global`p2, Global`p3] + TBsp[Global`p3, Global`p3])), 0}, 
 {0, 0, (-3*Global`Nc^2*(-1 + Global`Nc^2)*
    (TBsp[Global`p1, Global`p2]^3*TBsp[Global`p3, Global`p3] - 
     4*TBsp[Global`p1, Global`p1]^2*TBsp[Global`p2, Global`p2]*
      TBsp[Global`p3, Global`p3] + TBsp[Global`p1, Global`p2]^2*
      (TBsp[Global`p1, Global`p3]^2 - TBsp[Global`p1, Global`p3]*
        TBsp[Global`p2, Global`p3] + TBsp[Global`p2, Global`p3]^2 + 
       (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p3] + 
         TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3])*
        TBsp[Global`p3, Global`p3]) + TBsp[Global`p1, Global`p3]^2*
      (TBsp[Global`p1, Global`p3]*TBsp[Global`p2, Global`p2] + 
       TBsp[Global`p2, Global`p3]^2 + TBsp[Global`p2, Global`p2]*
        (2*TBsp[Global`p2, Global`p3] + TBsp[Global`p3, Global`p3])) + 
     TBsp[Global`p1, Global`p2]*(TBsp[Global`p1, Global`p3]^2*
        (2*TBsp[Global`p2, Global`p2] - TBsp[Global`p2, Global`p3]) + 
       TBsp[Global`p1, Global`p3]*((TBsp[Global`p1, Global`p1] + 
           TBsp[Global`p2, Global`p2] - TBsp[Global`p2, Global`p3])*
          TBsp[Global`p2, Global`p3] + (3*TBsp[Global`p2, Global`p2] + 
           TBsp[Global`p2, Global`p3])*TBsp[Global`p3, Global`p3]) + 
       TBsp[Global`p1, Global`p1]*(2*TBsp[Global`p2, Global`p3]^2 + 
         (-7*TBsp[Global`p2, Global`p2] + 3*TBsp[Global`p2, Global`p3])*
          TBsp[Global`p3, Global`p3])) + TBsp[Global`p1, Global`p1]*
      (TBsp[Global`p1, Global`p3]^2*TBsp[Global`p2, Global`p2] + 
       TBsp[Global`p1, Global`p3]*(2*TBsp[Global`p2, Global`p3]^2 + 
         TBsp[Global`p2, Global`p2]*(3*TBsp[Global`p2, Global`p3] - 
           7*TBsp[Global`p3, Global`p3])) - 4*TBsp[Global`p2, Global`p2]^2*
        TBsp[Global`p3, Global`p3] + TBsp[Global`p2, Global`p3]^2*
        (TBsp[Global`p2, Global`p3] + TBsp[Global`p3, Global`p3]) + 
       TBsp[Global`p2, Global`p2]*(TBsp[Global`p2, Global`p3]^2 - 
         7*TBsp[Global`p2, Global`p3]*TBsp[Global`p3, Global`p3] - 
         4*TBsp[Global`p3, Global`p3]^2))))/(TBsp[Global`p1, Global`p1]*
    TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3]*
    (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
     2*TBsp[Global`p1, Global`p3] + TBsp[Global`p2, Global`p2] + 
     2*TBsp[Global`p2, Global`p3] + TBsp[Global`p3, Global`p3]))}}
