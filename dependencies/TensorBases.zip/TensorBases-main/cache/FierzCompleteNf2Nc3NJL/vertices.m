(* Created with the Wolfram Language : www.wolfram.com *)
{(TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$16369]*TBgamma[0, Global`d3, 
       Global`dc$16372]*TBgamma5[Global`dc$16369, Global`d2]*
      TBgamma5[Global`dc$16372, Global`d4]) + 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    (-(TBgamma[0, Global`d1, Global`d4]*TBgamma[0, Global`d3, Global`d2]) + 
     TBgamma[0, Global`d1, Global`dc$16391]*TBgamma[0, Global`d3, 
       Global`dc$16388]*TBgamma5[Global`dc$16388, Global`d2]*
      TBgamma5[Global`dc$16391, Global`d4]))/Global`Nf, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$8580, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$8580, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$8580, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$8580, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$8580, 0]*TBgamma[0, Global`d1, 
          Global`dc$8583]) + TBgamma[Global`i$8580, Global`d1, 
        Global`dc$8583])*(-(TBdeltaLorentz[Global`i$8580, 0]*
         TBgamma[0, Global`d3, Global`dc$8586]) + TBgamma[Global`i$8580, 
        Global`d3, Global`dc$8586])*TBgamma5[Global`dc$8583, Global`d2]*
      TBgamma5[Global`dc$8586, Global`d4]) - 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    ((-(TBdeltaLorentz[Global`i$8602, 0]*TBgamma[0, Global`d1, Global`d4]) + 
       TBgamma[Global`i$8602, Global`d1, Global`d4])*
      (-(TBdeltaLorentz[Global`i$8602, 0]*TBgamma[0, Global`d3, Global`d2]) + 
       TBgamma[Global`i$8602, Global`d3, Global`d2]) - 
     (-(TBdeltaLorentz[Global`i$8602, 0]*TBgamma[0, Global`d1, 
          Global`dc$8608]) + TBgamma[Global`i$8602, Global`d1, 
        Global`dc$8608])*(-(TBdeltaLorentz[Global`i$8602, 0]*
         TBgamma[0, Global`d3, Global`dc$8605]) + TBgamma[Global`i$8602, 
        Global`d3, Global`dc$8605])*TBgamma5[Global`dc$8605, Global`d2]*
      TBgamma5[Global`dc$8608, Global`d4]))/Global`Nf, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
     TBgamma[0, Global`d1, Global`dc$5881]*TBgamma[0, Global`d3, 
       Global`dc$5884]*TBgamma5[Global`dc$5881, Global`d2]*
      TBgamma5[Global`dc$5884, Global`d4]) - 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    (TBgamma[0, Global`d1, Global`d4]*TBgamma[0, Global`d3, Global`d2] + 
     TBgamma[0, Global`d1, Global`dc$5903]*TBgamma[0, Global`d3, 
       Global`dc$5900]*TBgamma5[Global`dc$5900, Global`d2]*
      TBgamma5[Global`dc$5903, Global`d4]))/Global`Nf, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$5052, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$5052, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$5052, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$5052, Global`d3, Global`d4]) + 
     (-(TBdeltaLorentz[Global`i$5052, 0]*TBgamma[0, Global`d1, 
          Global`dc$5055]) + TBgamma[Global`i$5052, Global`d1, 
        Global`dc$5055])*(-(TBdeltaLorentz[Global`i$5052, 0]*
         TBgamma[0, Global`d3, Global`dc$5058]) + TBgamma[Global`i$5052, 
        Global`d3, Global`dc$5058])*TBgamma5[Global`dc$5055, Global`d2]*
      TBgamma5[Global`dc$5058, Global`d4]) - 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    ((-(TBdeltaLorentz[Global`i$5074, 0]*TBgamma[0, Global`d1, Global`d4]) + 
       TBgamma[Global`i$5074, Global`d1, Global`d4])*
      (-(TBdeltaLorentz[Global`i$5074, 0]*TBgamma[0, Global`d3, Global`d2]) + 
       TBgamma[Global`i$5074, Global`d3, Global`d2]) + 
     (-(TBdeltaLorentz[Global`i$5074, 0]*TBgamma[0, Global`d1, 
          Global`dc$5080]) + TBgamma[Global`i$5074, Global`d1, 
        Global`dc$5080])*(-(TBdeltaLorentz[Global`i$5074, 0]*
         TBgamma[0, Global`d3, Global`dc$5077]) + TBgamma[Global`i$5074, 
        Global`d3, Global`dc$5077])*TBgamma5[Global`dc$5077, Global`d2]*
      TBgamma5[Global`dc$5080, Global`d4]))/Global`Nf, 
 (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$5914]*TBgamma[0, Global`d3, 
       Global`dc$5917]*TBgamma5[Global`dc$5914, Global`d2]*
      TBgamma5[Global`dc$5917, Global`d4])*TBT[Global`color, Global`a$5920, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$5920, Global`A3, 
     Global`A4] + TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    (-(TBgamma[0, Global`d1, Global`d4]*TBgamma[0, Global`d3, Global`d2]) + 
     TBgamma[0, Global`d1, Global`dc$5939]*TBgamma[0, Global`d3, 
       Global`dc$5936]*TBgamma5[Global`dc$5936, Global`d2]*
      TBgamma5[Global`dc$5939, Global`d4])*TBT[Global`color, Global`a$5942, 
     Global`A1, Global`A4]*TBT[Global`color, Global`a$5942, Global`A3, 
     Global`A2])/Global`Nf, 
 (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$5072, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$5072, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$5072, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$5072, Global`d3, Global`d4]) + 
     (-(TBdeltaLorentz[Global`i$5072, 0]*TBgamma[0, Global`d1, 
          Global`dc$5075]) + TBgamma[Global`i$5072, Global`d1, 
        Global`dc$5075])*(-(TBdeltaLorentz[Global`i$5072, 0]*
         TBgamma[0, Global`d3, Global`dc$5078]) + TBgamma[Global`i$5072, 
        Global`d3, Global`dc$5078])*TBgamma5[Global`dc$5075, Global`d2]*
      TBgamma5[Global`dc$5078, Global`d4])*TBT[Global`color, Global`a$5081, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$5081, Global`A3, 
     Global`A4] - TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    ((-(TBdeltaLorentz[Global`i$5097, 0]*TBgamma[0, Global`d1, Global`d4]) + 
       TBgamma[Global`i$5097, Global`d1, Global`d4])*
      (-(TBdeltaLorentz[Global`i$5097, 0]*TBgamma[0, Global`d3, Global`d2]) + 
       TBgamma[Global`i$5097, Global`d3, Global`d2]) + 
     (-(TBdeltaLorentz[Global`i$5097, 0]*TBgamma[0, Global`d1, 
          Global`dc$5103]) + TBgamma[Global`i$5097, Global`d1, 
        Global`dc$5103])*(-(TBdeltaLorentz[Global`i$5097, 0]*
         TBgamma[0, Global`d3, Global`dc$5100]) + TBgamma[Global`i$5097, 
        Global`d3, Global`dc$5100])*TBgamma5[Global`dc$5100, Global`d2]*
      TBgamma5[Global`dc$5103, Global`d4])*TBT[Global`color, Global`a$5106, 
     Global`A1, Global`A4]*TBT[Global`color, Global`a$5106, Global`A3, 
     Global`A2])/Global`Nf, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*(TBdeltaDirac[Global`d1, Global`d2]*
      TBdeltaDirac[Global`d3, Global`d4]*TBdeltaFund[Global`flavor, 
       Global`F1, Global`F2]*TBdeltaFund[Global`flavor, Global`F3, 
       Global`F4] - 2*Global`Nf*TBgamma5[Global`d1, Global`d2]*
      TBgamma5[Global`d3, Global`d4]*TBT[Global`flavor, Global`f$6097, 
       Global`F1, Global`F2]*TBT[Global`flavor, Global`f$6097, Global`F3, 
       Global`F4]) + TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    (-(TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, Global`d2]*
       TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F2]) + 
     2*Global`Nf*TBgamma5[Global`d1, Global`d4]*TBgamma5[Global`d3, 
       Global`d2]*TBT[Global`flavor, Global`f$6113, Global`F1, Global`F4]*
      TBT[Global`flavor, Global`f$6113, Global`F3, Global`F2]))/Global`Nf, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*(TBdeltaDirac[Global`d1, Global`d2]*
      TBdeltaDirac[Global`d3, Global`d4] + TBgamma5[Global`d1, Global`d2]*
      TBgamma5[Global`d3, Global`d4])*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     2*Global`Nf*TBT[Global`flavor, Global`f$6495, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$6495, Global`F3, Global`F4]) + 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    (TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, Global`d2] + 
     TBgamma5[Global`d1, Global`d4]*TBgamma5[Global`d3, Global`d2])*
    (-(TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F2]) + 
     2*Global`Nf*TBT[Global`flavor, Global`f$6511, Global`F1, Global`F4]*
      TBT[Global`flavor, Global`f$6511, Global`F3, Global`F2]))/Global`Nf, 
 (TBepsFund[Global`flavor, Global`F2, Global`F4]*
   TBepsFund[Global`color, Global`a$81552, Global`A2, Global`A4]*
   (TBepsFund[Global`flavor, Global`F1, Global`F3]*TBepsFund[Global`color, 
      Global`a$81552, Global`A1, Global`A3]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] + 
      TBgamma[Global`vi1$4454, Global`d1, Global`d2]*TBgamma[Global`vi1$4454, 
        Global`d3, Global`d4] + 
      ((TBgamma[Global`vi2$4457, Global`dint2$4478, Global`d2]*
          TBgamma[Global`vi3$4460, Global`d1, Global`dint2$4478] - 
         TBgamma[Global`vi2$4457, Global`d1, Global`dint1$4472]*
          TBgamma[Global`vi3$4460, Global`dint1$4472, Global`d2])*
        (TBgamma[Global`vi2$4457, Global`dint2$4481, Global`d4]*
          TBgamma[Global`vi3$4460, Global`d3, Global`dint2$4481] - 
         TBgamma[Global`vi2$4457, Global`d3, Global`dint1$4475]*
          TBgamma[Global`vi3$4460, Global`dint1$4475, Global`d4]))/8 + 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] + 
      TBgamma[Global`vi4$4463, Global`d1, Global`di1$4466]*
       TBgamma[Global`vi4$4463, Global`d3, Global`di2$4469]*
       TBgamma5[Global`di1$4466, Global`d2]*TBgamma5[Global`di2$4469, 
        Global`d4]) - TBepsFund[Global`flavor, Global`F3, Global`F1]*
     TBepsFund[Global`color, Global`a$81552, Global`A3, Global`A1]*
     (TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, Global`d2] + 
      TBgamma[Global`vi1$4497, Global`d1, Global`d4]*TBgamma[Global`vi1$4497, 
        Global`d3, Global`d2] + 
      ((TBgamma[Global`vi2$4500, Global`dint2$4521, Global`d2]*
          TBgamma[Global`vi3$4503, Global`d3, Global`dint2$4521] - 
         TBgamma[Global`vi2$4500, Global`d3, Global`dint1$4515]*
          TBgamma[Global`vi3$4503, Global`dint1$4515, Global`d2])*
        (TBgamma[Global`vi2$4500, Global`dint2$4524, Global`d4]*
          TBgamma[Global`vi3$4503, Global`d1, Global`dint2$4524] - 
         TBgamma[Global`vi2$4500, Global`d1, Global`dint1$4518]*
          TBgamma[Global`vi3$4503, Global`dint1$4518, Global`d4]))/8 + 
      TBgamma5[Global`d1, Global`d4]*TBgamma5[Global`d3, Global`d2] + 
      TBgamma[Global`vi4$4506, Global`d1, Global`di2$4512]*
       TBgamma[Global`vi4$4506, Global`d3, Global`di1$4509]*
       TBgamma5[Global`di1$4509, Global`d2]*TBgamma5[Global`di2$4512, 
        Global`d4])))/8, 
 ((TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] + 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
    TBT[Global`color, Global`a$4576, Global`A1, Global`A2]*
    TBT[Global`color, Global`a$4576, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     2*Global`Nf*TBT[Global`flavor, Global`f$4579, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$4579, Global`F3, Global`F4]) - 
   (TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, Global`d2] + 
     TBgamma5[Global`d1, Global`d4]*TBgamma5[Global`d3, Global`d2])*
    TBT[Global`color, Global`a$4595, Global`A1, Global`A4]*
    TBT[Global`color, Global`a$4595, Global`A3, Global`A2]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F2] - 
     2*Global`Nf*TBT[Global`flavor, Global`f$4598, Global`F1, Global`F4]*
      TBT[Global`flavor, Global`f$4598, Global`F3, Global`F2]))/Global`Nf}
