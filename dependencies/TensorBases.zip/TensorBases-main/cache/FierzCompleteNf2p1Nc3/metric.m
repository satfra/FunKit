(* Created with the Wolfram Language : www.wolfram.com *)
{{(16*Global`Nc^2*(-1 + Global`Nf)^2)/9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, (16*Global`Nc^2*(-1 + Global`Nf)^2)/9, 0, 0, 0, 0, 0, 0, 0, 
  (Global`Nc*(-9 + Global`Nf*(8 + (10 - 9*Global`Nf)*Global`Nf)))/
   (9*Global`Nf), -1/18*((-1 + Global`Nc^2)*(-1 + Global`Nf)*
     (-9 + Global`Nf*(-1 + 9*Global`Nf)))/Global`Nf, 
  (2*Global`Nc*(-9 + Global`Nf*(8 + (10 - 9*Global`Nf)*Global`Nf)))/
   (3*Global`Nf), -1/3*((-1 + Global`Nc^2)*(-1 + Global`Nf)*
     (-9 + Global`Nf*(-1 + 9*Global`Nf)))/Global`Nf}, 
 {0, (16*Global`Nc^2*(-1 + Global`Nf)^2)/3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, (16*Global`Nc^2*(-1 + Global`Nf)^2)/3, 0, 0, 0, 0, 0, 0, 
  (Global`Nc*(-9 + Global`Nf*(8 + (10 - 9*Global`Nf)*Global`Nf)))/
   (3*Global`Nf), -1/6*((-1 + Global`Nc^2)*(-1 + Global`Nf)*
     (-9 + Global`Nf*(-1 + 9*Global`Nf)))/Global`Nf, 
  (2*Global`Nc*(-1 + Global`Nf)*(-9 + Global`Nf*(-1 + 9*Global`Nf)))/
   (3*Global`Nf), ((-1 + Global`Nc^2)*(-1 + Global`Nf)*
    (-9 + Global`Nf*(-1 + 9*Global`Nf)))/(3*Global`Nf)}, 
 {0, 0, (8*Global`Nc*(-1 + 2*Global`Nc*(-1 + Global`Nf))*(-1 + Global`Nf))/9, 
  (8*Global`Nc*(-1 + Global`Nf))/3, 0, 0, 
  (-4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/9, 
  (4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/3, 0, 0, 0, 0, 0, 0, 0, 0, 
  (8*Global`Nc*(-1 + 2*Global`Nc*(-1 + Global`Nf))*(-1 + Global`Nf))/9, 
  (8*Global`Nc*(-1 + Global`Nf))/3, 0, 0, 
  (-4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/9, 
  (4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/3, 0, 0, 0, 0}, 
 {0, 0, (8*Global`Nc*(-1 + Global`Nf))/3, 
  (8*Global`Nc*(1 + 2*Global`Nc*(-1 + Global`Nf))*(-1 + Global`Nf))/3, 0, 0, 
  (4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/3, 
  (4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/3, 0, 0, 0, 0, 0, 0, 0, 0, 
  (8*Global`Nc*(-1 + Global`Nf))/3, 
  (8*Global`Nc*(1 + 2*Global`Nc*(-1 + Global`Nf))*(-1 + Global`Nf))/3, 0, 0, 
  (4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/3, 
  (4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/3, 0, 0, 0, 0}, 
 {0, 0, 0, 0, (4*(-1 + Global`Nc^2)*(-1 + Global`Nf)^2)/9, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, (4*(-1 + Global`Nc^2)*(-1 + Global`Nf)^2)/9, 0, 0, 0, 
  -1/18*((-1 + Global`Nc^2)*(-1 + Global`Nf)*
     (-9 + Global`Nf*(-1 + 9*Global`Nf)))/Global`Nf, 
  ((-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + Global`Nf*(-1 + 9*Global`Nf)))/
   (36*Global`Nc*Global`Nf), 
  -1/3*((-1 + Global`Nc^2)*(-1 + Global`Nf)*
     (-9 + Global`Nf*(-1 + 9*Global`Nf)))/Global`Nf, 
  ((-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + Global`Nf*(-1 + 9*Global`Nf)))/
   (6*Global`Nc*Global`Nf)}, {0, 0, 0, 0, 0, 
  (4*(-1 + Global`Nc^2)*(-1 + Global`Nf)^2)/3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, (4*(-1 + Global`Nc^2)*(-1 + Global`Nf)^2)/3, 0, 0, 
  -1/6*((-1 + Global`Nc^2)*(-1 + Global`Nf)*
     (-9 + Global`Nf*(-1 + 9*Global`Nf)))/Global`Nf, 
  ((-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + Global`Nf*(-1 + 9*Global`Nf)))/
   (12*Global`Nc*Global`Nf), ((-1 + Global`Nc^2)*(-1 + Global`Nf)*
    (-9 + Global`Nf*(-1 + 9*Global`Nf)))/(3*Global`Nf), 
  -1/6*((-1 + Global`Nc^2)*(-1 + Global`Nf)*
     (-9 + Global`Nf*(-1 + 9*Global`Nf)))/(Global`Nc*Global`Nf)}, 
 {0, 0, (-4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/9, 
  (4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/3, 0, 0, 
  (2*(-1 + Global`Nc^2)*(1 + 2*Global`Nc*(-1 + Global`Nf))*(-1 + Global`Nf))/
   (9*Global`Nc), (-2*(-1 + Global`Nc^2)*(-1 + Global`Nf))/(3*Global`Nc), 0, 
  0, 0, 0, 0, 0, 0, 0, (-4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/9, 
  (4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/3, 0, 0, 
  (2*(-1 + Global`Nc^2)*(1 + 2*Global`Nc*(-1 + Global`Nf))*(-1 + Global`Nf))/
   (9*Global`Nc), (-2*(-1 + Global`Nc^2)*(-1 + Global`Nf))/(3*Global`Nc), 0, 
  0, 0, 0}, {0, 0, (4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/3, 
  (4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/3, 0, 0, 
  (-2*(-1 + Global`Nc^2)*(-1 + Global`Nf))/(3*Global`Nc), 
  (2*(-1 + Global`Nc^2)*(-1 + 2*Global`Nc*(-1 + Global`Nf))*(-1 + Global`Nf))/
   (3*Global`Nc), 0, 0, 0, 0, 0, 0, 0, 0, 
  (4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/3, 
  (4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/3, 0, 0, 
  (-2*(-1 + Global`Nc^2)*(-1 + Global`Nf))/(3*Global`Nc), 
  (2*(-1 + Global`Nc^2)*(-1 + 2*Global`Nc*(-1 + Global`Nf))*(-1 + Global`Nf))/
   (3*Global`Nc), 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, (16*Global`Nc^2)/9, 
  0, 0, 0, (-8*Global`Nc)/9, (-4*(-1 + Global`Nc^2))/9, (16*Global`Nc^2)/9, 
  0, 0, 0, 0, 0, 0, 0, Global`Nc*(-17/9 + Global`Nf^(-1)), 
  -1/18*((-1 + Global`Nc^2)*(-9 + 17*Global`Nf))/Global`Nf, 
  Global`Nc*(-34/3 + 6/Global`Nf), 
  -1/3*((-1 + Global`Nc^2)*(-9 + 17*Global`Nf))/Global`Nf}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, (8*Global`Nc*(-1 + 2*Global`Nc))/9, 0, 
  (4*(-1 + Global`Nc^2))/3, 0, 0, 0, 0, (8*Global`Nc*(-1 + 2*Global`Nc))/9, 
  (8*Global`Nc)/3, 0, 0, (-4*(-1 + Global`Nc^2))/9, (4*(-1 + Global`Nc^2))/3, 
  0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, (4*(-1 + Global`Nc^2))/3, 0, 
  (-4*(-1 + Global`Nc^2))/3, (2*(-1 + Global`Nc^2))/(3*Global`Nc), 0, 0, 0, 
  0, 0, (4*(-1 + Global`Nc^2))/3, 0, 0, 
  -1/6*((-1 + Global`Nc^2)*(-9 + 17*Global`Nf))/Global`Nf, 
  ((-1 + Global`Nc^2)*(-9 + 17*Global`Nf))/(12*Global`Nc*Global`Nf), 
  ((-1 + Global`Nc^2)*(-9 + 17*Global`Nf))/(3*Global`Nf), 
  -1/6*((-1 + Global`Nc^2)*(-9 + 17*Global`Nf))/(Global`Nc*Global`Nf)}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, (4*(-1 + Global`Nc^2))/3, 0, 
  (2*(-1 + Global`Nc)*(1 + Global`Nc)*(-1 + 2*Global`Nc))/(3*Global`Nc), 0, 
  0, 0, 0, (4*(-1 + Global`Nc^2))/3, (4*(-1 + Global`Nc^2))/3, 0, 0, 
  (-2*(-1 + Global`Nc^2))/(3*Global`Nc), 
  (2*(-1 + Global`Nc)*(1 + Global`Nc)*(-1 + 2*Global`Nc))/(3*Global`Nc), 0, 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, (-8*Global`Nc)/9, 0, 
  (-4*(-1 + Global`Nc^2))/3, 0, (16*Global`Nc^2)/9, 0, (-8*Global`Nc)/9, 
  (-8*Global`Nc)/3, 0, 0, (-4*(-1 + Global`Nc^2))/9, 
  (-4*(-1 + Global`Nc^2))/3, 0, 0, (2*Global`Nc^2*(-9 + 17*Global`Nf))/
   (9*Global`Nf), 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 
  (-4*(-1 + Global`Nc^2))/9, 0, (2*(-1 + Global`Nc^2))/(3*Global`Nc), 0, 0, 
  (4*(-1 + Global`Nc^2))/9, (-4*(-1 + Global`Nc^2))/9, 
  (-4*(-1 + Global`Nc^2))/3, 0, 0, (2*(-1 + Global`Nc^2))/(9*Global`Nc), 
  (2*(-1 + Global`Nc^2))/(3*Global`Nc), 0, 0, 0, 
  ((-1 + Global`Nc^2)*(-9 + 17*Global`Nf))/(18*Global`Nf), 0, 0}, 
 {(16*Global`Nc^2*(-1 + Global`Nf)^2)/9, 0, 0, 0, 0, 0, 0, 0, 
  (16*Global`Nc^2)/9, 0, 0, 0, (-8*Global`Nc)/9, (-4*(-1 + Global`Nc^2))/9, 
  (16*Global`Nc^2*Global`Nf^2)/9, 0, 0, 0, 0, 0, 0, 0, 
  Global`Nc - (Global`Nc*Global`Nf*(8 + 9*Global`Nf))/9, 
  -1/18*((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf))), 
  (-2*Global`Nc*(-9 + Global`Nf*(8 + 9*Global`Nf)))/3, 
  -1/3*((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf)))}, 
 {0, (16*Global`Nc^2*(-1 + Global`Nf)^2)/3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  (-8*Global`Nc)/3, (-4*(-1 + Global`Nc^2))/3, 0, 
  (16*Global`Nc^2*Global`Nf^2)/3, 0, 0, 0, 0, 0, 0, 
  -1/3*(Global`Nc*(-9 + Global`Nf*(8 + 9*Global`Nf))), 
  -1/6*((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf))), 
  (2*Global`Nc*(-9 + Global`Nf*(8 + 9*Global`Nf)))/3, 
  ((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf)))/3}, 
 {0, 0, (8*Global`Nc*(-1 + 2*Global`Nc*(-1 + Global`Nf))*(-1 + Global`Nf))/9, 
  (8*Global`Nc*(-1 + Global`Nf))/3, 0, 0, 
  (-4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/9, 
  (4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/3, 0, 
  (8*Global`Nc*(-1 + 2*Global`Nc))/9, 0, (4*(-1 + Global`Nc^2))/3, 0, 0, 0, 
  0, (8*Global`Nc*Global`Nf*(-1 + 2*Global`Nc*Global`Nf))/9, 
  (8*Global`Nc*Global`Nf)/3, 0, 0, (-4*(-1 + Global`Nc^2)*Global`Nf)/9, 
  (4*(-1 + Global`Nc^2)*Global`Nf)/3, 0, 0, 0, 0}, 
 {0, 0, (8*Global`Nc*(-1 + Global`Nf))/3, 
  (8*Global`Nc*(1 + 2*Global`Nc*(-1 + Global`Nf))*(-1 + Global`Nf))/3, 0, 0, 
  (4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/3, 
  (4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/3, 0, (8*Global`Nc)/3, 0, 
  (4*(-1 + Global`Nc^2))/3, 0, 0, 0, 0, (8*Global`Nc*Global`Nf)/3, 
  (8*Global`Nc*Global`Nf*(1 + 2*Global`Nc*Global`Nf))/3, 0, 0, 
  (4*(-1 + Global`Nc^2)*Global`Nf)/3, (4*(-1 + Global`Nc^2)*Global`Nf)/3, 0, 
  0, 0, 0}, {0, 0, 0, 0, (4*(-1 + Global`Nc^2)*(-1 + Global`Nf)^2)/9, 0, 0, 
  0, 0, 0, 0, 0, (-4*(-1 + Global`Nc^2))/9, (2*(-1 + Global`Nc^2))/
   (9*Global`Nc), 0, 0, 0, 0, (4*(-1 + Global`Nc^2)*Global`Nf^2)/9, 0, 0, 0, 
  -1/18*((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf))), 
  ((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf)))/(36*Global`Nc), 
  -1/3*((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf))), 
  ((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf)))/(6*Global`Nc)}, 
 {0, 0, 0, 0, 0, (4*(-1 + Global`Nc^2)*(-1 + Global`Nf)^2)/3, 0, 0, 0, 0, 
  (4*(-1 + Global`Nc^2))/3, 0, (-4*(-1 + Global`Nc^2))/3, 
  (2*(-1 + Global`Nc^2))/(3*Global`Nc), 0, 0, 0, 0, 0, 
  (4*(-1 + Global`Nc^2)*Global`Nf^2)/3, 0, 0, 
  -1/6*((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf))), 
  ((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf)))/(12*Global`Nc), 
  ((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf)))/3, 
  -1/6*((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf)))/Global`Nc}, 
 {0, 0, (-4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/9, 
  (4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/3, 0, 0, 
  (2*(-1 + Global`Nc^2)*(1 + 2*Global`Nc*(-1 + Global`Nf))*(-1 + Global`Nf))/
   (9*Global`Nc), (-2*(-1 + Global`Nc^2)*(-1 + Global`Nf))/(3*Global`Nc), 0, 
  (-4*(-1 + Global`Nc^2))/9, 0, (-2*(-1 + Global`Nc^2))/(3*Global`Nc), 0, 0, 
  0, 0, (-4*(-1 + Global`Nc^2)*Global`Nf)/9, (4*(-1 + Global`Nc^2)*Global`Nf)/
   3, 0, 0, (2*(-1 + Global`Nc^2)*Global`Nf*(1 + 2*Global`Nc*Global`Nf))/
   (9*Global`Nc), (-2*(-1 + Global`Nc^2)*Global`Nf)/(3*Global`Nc), 0, 0, 0, 
  0}, {0, 0, (4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/3, 
  (4*(-1 + Global`Nc^2)*(-1 + Global`Nf))/3, 0, 0, 
  (-2*(-1 + Global`Nc^2)*(-1 + Global`Nf))/(3*Global`Nc), 
  (2*(-1 + Global`Nc^2)*(-1 + 2*Global`Nc*(-1 + Global`Nf))*(-1 + Global`Nf))/
   (3*Global`Nc), 0, (4*(-1 + Global`Nc^2))/3, 0, 
  (2*(-1 + Global`Nc)*(1 + Global`Nc)*(-1 + 2*Global`Nc))/(3*Global`Nc), 0, 
  0, 0, 0, (4*(-1 + Global`Nc^2)*Global`Nf)/3, 
  (4*(-1 + Global`Nc^2)*Global`Nf)/3, 0, 0, (-2*(-1 + Global`Nc^2)*Global`Nf)/
   (3*Global`Nc), (2*(-1 + Global`Nc^2)*Global`Nf*
    (-1 + 2*Global`Nc*Global`Nf))/(3*Global`Nc), 0, 0, 0, 0}, 
 {(Global`Nc*(-9 + Global`Nf*(8 + (10 - 9*Global`Nf)*Global`Nf)))/
   (9*Global`Nf), 
  (Global`Nc*(-9 + Global`Nf*(8 + (10 - 9*Global`Nf)*Global`Nf)))/
   (3*Global`Nf), 0, 0, -1/18*((-1 + Global`Nc^2)*(-1 + Global`Nf)*
     (-9 + Global`Nf*(-1 + 9*Global`Nf)))/Global`Nf, 
  -1/6*((-1 + Global`Nc^2)*(-1 + Global`Nf)*
     (-9 + Global`Nf*(-1 + 9*Global`Nf)))/Global`Nf, 0, 0, 
  Global`Nc*(-17/9 + Global`Nf^(-1)), 0, 
  -1/6*((-1 + Global`Nc^2)*(-9 + 17*Global`Nf))/Global`Nf, 0, 
  (2*Global`Nc^2*(-9 + 17*Global`Nf))/(9*Global`Nf), 0, 
  Global`Nc - (Global`Nc*Global`Nf*(8 + 9*Global`Nf))/9, 
  -1/3*(Global`Nc*(-9 + Global`Nf*(8 + 9*Global`Nf))), 0, 0, 
  -1/18*((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf))), 
  -1/6*((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf))), 0, 0, 
  (Global`Nc^2*(-81 + 145*Global`Nf^2))/36, 0, 0, 0}, 
 {-1/18*((-1 + Global`Nc^2)*(-1 + Global`Nf)*
     (-9 + Global`Nf*(-1 + 9*Global`Nf)))/Global`Nf, 
  -1/6*((-1 + Global`Nc^2)*(-1 + Global`Nf)*
     (-9 + Global`Nf*(-1 + 9*Global`Nf)))/Global`Nf, 0, 0, 
  ((-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + Global`Nf*(-1 + 9*Global`Nf)))/
   (36*Global`Nc*Global`Nf), ((-1 + Global`Nc^2)*(-1 + Global`Nf)*
    (-9 + Global`Nf*(-1 + 9*Global`Nf)))/(12*Global`Nc*Global`Nf), 0, 0, 
  -1/18*((-1 + Global`Nc^2)*(-9 + 17*Global`Nf))/Global`Nf, 0, 
  ((-1 + Global`Nc^2)*(-9 + 17*Global`Nf))/(12*Global`Nc*Global`Nf), 0, 0, 
  ((-1 + Global`Nc^2)*(-9 + 17*Global`Nf))/(18*Global`Nf), 
  -1/18*((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf))), 
  -1/6*((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf))), 0, 0, 
  ((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf)))/(36*Global`Nc), 
  ((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf)))/(12*Global`Nc), 0, 
  0, 0, ((-1 + Global`Nc^2)*(-81 + 145*Global`Nf^2))/144, 0, 0}, 
 {(2*Global`Nc*(-9 + Global`Nf*(8 + (10 - 9*Global`Nf)*Global`Nf)))/
   (3*Global`Nf), (2*Global`Nc*(-1 + Global`Nf)*
    (-9 + Global`Nf*(-1 + 9*Global`Nf)))/(3*Global`Nf), 0, 0, 
  -1/3*((-1 + Global`Nc^2)*(-1 + Global`Nf)*
     (-9 + Global`Nf*(-1 + 9*Global`Nf)))/Global`Nf, 
  ((-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + Global`Nf*(-1 + 9*Global`Nf)))/
   (3*Global`Nf), 0, 0, Global`Nc*(-34/3 + 6/Global`Nf), 0, 
  ((-1 + Global`Nc^2)*(-9 + 17*Global`Nf))/(3*Global`Nf), 0, 0, 0, 
  (-2*Global`Nc*(-9 + Global`Nf*(8 + 9*Global`Nf)))/3, 
  (2*Global`Nc*(-9 + Global`Nf*(8 + 9*Global`Nf)))/3, 0, 0, 
  -1/3*((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf))), 
  ((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf)))/3, 0, 0, 0, 0, 
  (Global`Nc^2*(-81 + 145*Global`Nf^2))/3, 0}, 
 {-1/3*((-1 + Global`Nc^2)*(-1 + Global`Nf)*
     (-9 + Global`Nf*(-1 + 9*Global`Nf)))/Global`Nf, 
  ((-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + Global`Nf*(-1 + 9*Global`Nf)))/
   (3*Global`Nf), 0, 0, ((-1 + Global`Nc^2)*(-1 + Global`Nf)*
    (-9 + Global`Nf*(-1 + 9*Global`Nf)))/(6*Global`Nc*Global`Nf), 
  -1/6*((-1 + Global`Nc^2)*(-1 + Global`Nf)*
     (-9 + Global`Nf*(-1 + 9*Global`Nf)))/(Global`Nc*Global`Nf), 0, 0, 
  -1/3*((-1 + Global`Nc^2)*(-9 + 17*Global`Nf))/Global`Nf, 0, 
  -1/6*((-1 + Global`Nc^2)*(-9 + 17*Global`Nf))/(Global`Nc*Global`Nf), 0, 0, 
  0, -1/3*((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf))), 
  ((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf)))/3, 0, 0, 
  ((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf)))/(6*Global`Nc), 
  -1/6*((-1 + Global`Nc^2)*(-9 + Global`Nf*(8 + 9*Global`Nf)))/Global`Nc, 0, 
  0, 0, 0, 0, ((-1 + Global`Nc^2)*(-81 + 145*Global`Nf^2))/12}}
