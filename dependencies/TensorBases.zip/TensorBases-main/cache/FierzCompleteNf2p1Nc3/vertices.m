(* Created with the Wolfram Language : www.wolfram.com *)
{(TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*(TBdeltaFund[Global`flavor, Global`F1, 
      Global`F2] - TBdeltaFund[Global`flavor, Global`F1, 3]*
      TBdeltaFund[Global`flavor, Global`F2, 3])*
    (TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
      TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$1310]*TBgamma[0, Global`d3, 
       Global`dc$1313]*TBgamma5[Global`dc$1310, Global`d2]*
      TBgamma5[Global`dc$1313, Global`d4]) + 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    (TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
       Global`F3, 3] - TBdeltaFund[Global`flavor, Global`F3, Global`F2])*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*(TBgamma[0, Global`d1, Global`d4]*
      TBgamma[0, Global`d3, Global`d2] - 
     TBgamma[0, Global`d1, Global`dc$1332]*TBgamma[0, Global`d3, 
       Global`dc$1329]*TBgamma5[Global`dc$1329, Global`d2]*
      TBgamma5[Global`dc$1332, Global`d4]))/3, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*(TBdeltaFund[Global`flavor, Global`F1, 
      Global`F2] - TBdeltaFund[Global`flavor, Global`F1, 3]*
      TBdeltaFund[Global`flavor, Global`F2, 3])*
    (TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*
    ((-(TBdeltaLorentz[Global`i$2141, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$2141, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$2141, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$2141, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$2141, 0]*TBgamma[0, Global`d1, 
          Global`dc$2144]) + TBgamma[Global`i$2141, Global`d1, 
        Global`dc$2144])*(-(TBdeltaLorentz[Global`i$2141, 0]*
         TBgamma[0, Global`d3, Global`dc$2147]) + TBgamma[Global`i$2141, 
        Global`d3, Global`dc$2147])*TBgamma5[Global`dc$2144, Global`d2]*
      TBgamma5[Global`dc$2147, Global`d4]) - 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    (-(TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
        Global`F3, 3]) + TBdeltaFund[Global`flavor, Global`F3, Global`F2])*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*
    ((-(TBdeltaLorentz[Global`i$2163, 0]*TBgamma[0, Global`d1, Global`d4]) + 
       TBgamma[Global`i$2163, Global`d1, Global`d4])*
      (-(TBdeltaLorentz[Global`i$2163, 0]*TBgamma[0, Global`d3, Global`d2]) + 
       TBgamma[Global`i$2163, Global`d3, Global`d2]) - 
     (-(TBdeltaLorentz[Global`i$2163, 0]*TBgamma[0, Global`d1, 
          Global`dc$2169]) + TBgamma[Global`i$2163, Global`d1, 
        Global`dc$2169])*(-(TBdeltaLorentz[Global`i$2163, 0]*
         TBgamma[0, Global`d3, Global`dc$2166]) + TBgamma[Global`i$2163, 
        Global`d3, Global`dc$2166])*TBgamma5[Global`dc$2166, Global`d2]*
      TBgamma5[Global`dc$2169, Global`d4]))/3, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*(TBdeltaFund[Global`flavor, Global`F1, 
      Global`F2] - TBdeltaFund[Global`flavor, Global`F1, 3]*
      TBdeltaFund[Global`flavor, Global`F2, 3])*
    (TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
      TBgamma[0, Global`d3, Global`d4] + 
     TBgamma[0, Global`d1, Global`dc$1310]*TBgamma[0, Global`d3, 
       Global`dc$1313]*TBgamma5[Global`dc$1310, Global`d2]*
      TBgamma5[Global`dc$1313, Global`d4]) + 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    (TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
       Global`F3, 3] - TBdeltaFund[Global`flavor, Global`F3, Global`F2])*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*(TBgamma[0, Global`d1, Global`d4]*
      TBgamma[0, Global`d3, Global`d2] + 
     TBgamma[0, Global`d1, Global`dc$1332]*TBgamma[0, Global`d3, 
       Global`dc$1329]*TBgamma5[Global`dc$1329, Global`d2]*
      TBgamma5[Global`dc$1332, Global`d4]))/3, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*(TBdeltaFund[Global`flavor, Global`F1, 
      Global`F2] - TBdeltaFund[Global`flavor, Global`F1, 3]*
      TBdeltaFund[Global`flavor, Global`F2, 3])*
    (TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*
    ((-(TBdeltaLorentz[Global`i$2097, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$2097, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$2097, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$2097, Global`d3, Global`d4]) + 
     (-(TBdeltaLorentz[Global`i$2097, 0]*TBgamma[0, Global`d1, 
          Global`dc$2100]) + TBgamma[Global`i$2097, Global`d1, 
        Global`dc$2100])*(-(TBdeltaLorentz[Global`i$2097, 0]*
         TBgamma[0, Global`d3, Global`dc$2103]) + TBgamma[Global`i$2097, 
        Global`d3, Global`dc$2103])*TBgamma5[Global`dc$2100, Global`d2]*
      TBgamma5[Global`dc$2103, Global`d4]) - 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    (-(TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
        Global`F3, 3]) + TBdeltaFund[Global`flavor, Global`F3, Global`F2])*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*
    ((-(TBdeltaLorentz[Global`i$2119, 0]*TBgamma[0, Global`d1, Global`d4]) + 
       TBgamma[Global`i$2119, Global`d1, Global`d4])*
      (-(TBdeltaLorentz[Global`i$2119, 0]*TBgamma[0, Global`d3, Global`d2]) + 
       TBgamma[Global`i$2119, Global`d3, Global`d2]) + 
     (-(TBdeltaLorentz[Global`i$2119, 0]*TBgamma[0, Global`d1, 
          Global`dc$2125]) + TBgamma[Global`i$2119, Global`d1, 
        Global`dc$2125])*(-(TBdeltaLorentz[Global`i$2119, 0]*
         TBgamma[0, Global`d3, Global`dc$2122]) + TBgamma[Global`i$2119, 
        Global`d3, Global`dc$2122])*TBgamma5[Global`dc$2122, Global`d2]*
      TBgamma5[Global`dc$2125, Global`d4]))/3, 
 ((TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
      TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$1310]*TBgamma[0, Global`d3, 
       Global`dc$1313]*TBgamma5[Global`dc$1310, Global`d2]*
      TBgamma5[Global`dc$1313, Global`d4])*TBT[Global`color, Global`a$1316, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$1316, Global`A3, 
     Global`A4] + (TBdeltaFund[Global`flavor, Global`F2, 3]*
      TBdeltaFund[Global`flavor, Global`F3, 3] - TBdeltaFund[Global`flavor, 
      Global`F3, Global`F2])*(TBdeltaFund[Global`flavor, Global`F1, 
      Global`F4] - TBdeltaFund[Global`flavor, Global`F1, 3]*
      TBdeltaFund[Global`flavor, Global`F4, 3])*
    (TBgamma[0, Global`d1, Global`d4]*TBgamma[0, Global`d3, Global`d2] - 
     TBgamma[0, Global`d1, Global`dc$1335]*TBgamma[0, Global`d3, 
       Global`dc$1332]*TBgamma5[Global`dc$1332, Global`d2]*
      TBgamma5[Global`dc$1335, Global`d4])*TBT[Global`color, Global`a$1338, 
     Global`A1, Global`A4]*TBT[Global`color, Global`a$1338, Global`A3, 
     Global`A2])/3, 
 ((TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*
    ((-(TBdeltaLorentz[Global`i$1879, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$1879, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$1879, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$1879, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$1879, 0]*TBgamma[0, Global`d1, 
          Global`dc$1882]) + TBgamma[Global`i$1879, Global`d1, 
        Global`dc$1882])*(-(TBdeltaLorentz[Global`i$1879, 0]*
         TBgamma[0, Global`d3, Global`dc$1885]) + TBgamma[Global`i$1879, 
        Global`d3, Global`dc$1885])*TBgamma5[Global`dc$1882, Global`d2]*
      TBgamma5[Global`dc$1885, Global`d4])*TBT[Global`color, Global`a$1888, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$1888, Global`A3, 
     Global`A4] - (-(TBdeltaFund[Global`flavor, Global`F2, 3]*
       TBdeltaFund[Global`flavor, Global`F3, 3]) + TBdeltaFund[Global`flavor, 
      Global`F3, Global`F2])*(TBdeltaFund[Global`flavor, Global`F1, 
      Global`F4] - TBdeltaFund[Global`flavor, Global`F1, 3]*
      TBdeltaFund[Global`flavor, Global`F4, 3])*
    ((-(TBdeltaLorentz[Global`i$1904, 0]*TBgamma[0, Global`d1, Global`d4]) + 
       TBgamma[Global`i$1904, Global`d1, Global`d4])*
      (-(TBdeltaLorentz[Global`i$1904, 0]*TBgamma[0, Global`d3, Global`d2]) + 
       TBgamma[Global`i$1904, Global`d3, Global`d2]) - 
     (-(TBdeltaLorentz[Global`i$1904, 0]*TBgamma[0, Global`d1, 
          Global`dc$1910]) + TBgamma[Global`i$1904, Global`d1, 
        Global`dc$1910])*(-(TBdeltaLorentz[Global`i$1904, 0]*
         TBgamma[0, Global`d3, Global`dc$1907]) + TBgamma[Global`i$1904, 
        Global`d3, Global`dc$1907])*TBgamma5[Global`dc$1907, Global`d2]*
      TBgamma5[Global`dc$1910, Global`d4])*TBT[Global`color, Global`a$1913, 
     Global`A1, Global`A4]*TBT[Global`color, Global`a$1913, Global`A3, 
     Global`A2])/3, 
 ((TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
      TBgamma[0, Global`d3, Global`d4] + 
     TBgamma[0, Global`d1, Global`dc$1310]*TBgamma[0, Global`d3, 
       Global`dc$1313]*TBgamma5[Global`dc$1310, Global`d2]*
      TBgamma5[Global`dc$1313, Global`d4])*TBT[Global`color, Global`a$1316, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$1316, Global`A3, 
     Global`A4] + (TBdeltaFund[Global`flavor, Global`F2, 3]*
      TBdeltaFund[Global`flavor, Global`F3, 3] - TBdeltaFund[Global`flavor, 
      Global`F3, Global`F2])*(TBdeltaFund[Global`flavor, Global`F1, 
      Global`F4] - TBdeltaFund[Global`flavor, Global`F1, 3]*
      TBdeltaFund[Global`flavor, Global`F4, 3])*
    (TBgamma[0, Global`d1, Global`d4]*TBgamma[0, Global`d3, Global`d2] + 
     TBgamma[0, Global`d1, Global`dc$1335]*TBgamma[0, Global`d3, 
       Global`dc$1332]*TBgamma5[Global`dc$1332, Global`d2]*
      TBgamma5[Global`dc$1335, Global`d4])*TBT[Global`color, Global`a$1338, 
     Global`A1, Global`A4]*TBT[Global`color, Global`a$1338, Global`A3, 
     Global`A2])/3, 
 ((TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*
    ((-(TBdeltaLorentz[Global`i$1879, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$1879, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$1879, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$1879, Global`d3, Global`d4]) + 
     (-(TBdeltaLorentz[Global`i$1879, 0]*TBgamma[0, Global`d1, 
          Global`dc$1882]) + TBgamma[Global`i$1879, Global`d1, 
        Global`dc$1882])*(-(TBdeltaLorentz[Global`i$1879, 0]*
         TBgamma[0, Global`d3, Global`dc$1885]) + TBgamma[Global`i$1879, 
        Global`d3, Global`dc$1885])*TBgamma5[Global`dc$1882, Global`d2]*
      TBgamma5[Global`dc$1885, Global`d4])*TBT[Global`color, Global`a$1888, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$1888, Global`A3, 
     Global`A4] - (-(TBdeltaFund[Global`flavor, Global`F2, 3]*
       TBdeltaFund[Global`flavor, Global`F3, 3]) + TBdeltaFund[Global`flavor, 
      Global`F3, Global`F2])*(TBdeltaFund[Global`flavor, Global`F1, 
      Global`F4] - TBdeltaFund[Global`flavor, Global`F1, 3]*
      TBdeltaFund[Global`flavor, Global`F4, 3])*
    ((-(TBdeltaLorentz[Global`i$1904, 0]*TBgamma[0, Global`d1, Global`d4]) + 
       TBgamma[Global`i$1904, Global`d1, Global`d4])*
      (-(TBdeltaLorentz[Global`i$1904, 0]*TBgamma[0, Global`d3, Global`d2]) + 
       TBgamma[Global`i$1904, Global`d3, Global`d2]) + 
     (-(TBdeltaLorentz[Global`i$1904, 0]*TBgamma[0, Global`d1, 
          Global`dc$1910]) + TBgamma[Global`i$1904, Global`d1, 
        Global`dc$1910])*(-(TBdeltaLorentz[Global`i$1904, 0]*
         TBgamma[0, Global`d3, Global`dc$1907]) + TBgamma[Global`i$1904, 
        Global`d3, Global`dc$1907])*TBgamma5[Global`dc$1907, Global`d2]*
      TBgamma5[Global`dc$1910, Global`d4])*TBT[Global`color, Global`a$1913, 
     Global`A1, Global`A4]*TBT[Global`color, Global`a$1913, Global`A3, 
     Global`A2])/3, (TBdeltaFund[Global`flavor, Global`F1, 3]*
   TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
    Global`F3, 3]*TBdeltaFund[Global`flavor, Global`F4, 3]*
   (TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$1310]*TBgamma[0, Global`d3, 
        Global`dc$1313]*TBgamma5[Global`dc$1310, Global`d2]*
       TBgamma5[Global`dc$1313, Global`d4]) + 
    TBdeltaFund[Global`color, Global`A1, Global`A4]*
     TBdeltaFund[Global`color, Global`A3, Global`A2]*
     (-(TBgamma[0, Global`d1, Global`d4]*TBgamma[0, Global`d3, Global`d2]) + 
      TBgamma[0, Global`d1, Global`dc$1332]*TBgamma[0, Global`d3, 
        Global`dc$1329]*TBgamma5[Global`dc$1329, Global`d2]*
       TBgamma5[Global`dc$1332, Global`d4])))/3, 
 (TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
    Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
   TBdeltaFund[Global`flavor, Global`F4, 3]*
   (TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
      TBgamma[0, Global`d1, Global`dc$1685]*TBgamma[0, Global`d3, 
        Global`dc$1688]*TBgamma5[Global`dc$1685, Global`d2]*
       TBgamma5[Global`dc$1688, Global`d4]) - 
    TBdeltaFund[Global`color, Global`A1, Global`A4]*
     TBdeltaFund[Global`color, Global`A3, Global`A2]*
     (TBgamma[0, Global`d1, Global`d4]*TBgamma[0, Global`d3, Global`d2] + 
      TBgamma[0, Global`d1, Global`dc$1707]*TBgamma[0, Global`d3, 
        Global`dc$1704]*TBgamma5[Global`dc$1704, Global`d2]*
       TBgamma5[Global`dc$1707, Global`d4])))/3, 
 (TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
    Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
   TBdeltaFund[Global`flavor, Global`F4, 3]*
   (((-(TBdeltaLorentz[Global`i$1310, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$1310, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$1310, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$1310, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$1310, 0]*TBgamma[0, Global`d1, 
           Global`dc$1313]) + TBgamma[Global`i$1310, Global`d1, 
         Global`dc$1313])*(-(TBdeltaLorentz[Global`i$1310, 0]*
          TBgamma[0, Global`d3, Global`dc$1316]) + TBgamma[Global`i$1310, 
         Global`d3, Global`dc$1316])*TBgamma5[Global`dc$1313, Global`d2]*
       TBgamma5[Global`dc$1316, Global`d4])*TBT[Global`color, Global`a$1319, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$1319, Global`A3, 
      Global`A4] - 
    ((-(TBdeltaLorentz[Global`i$1335, 0]*TBgamma[0, Global`d1, Global`d4]) + 
        TBgamma[Global`i$1335, Global`d1, Global`d4])*
       (-(TBdeltaLorentz[Global`i$1335, 0]*TBgamma[0, Global`d3, 
           Global`d2]) + TBgamma[Global`i$1335, Global`d3, Global`d2]) - 
      (-(TBdeltaLorentz[Global`i$1335, 0]*TBgamma[0, Global`d1, 
           Global`dc$1341]) + TBgamma[Global`i$1335, Global`d1, 
         Global`dc$1341])*(-(TBdeltaLorentz[Global`i$1335, 0]*
          TBgamma[0, Global`d3, Global`dc$1338]) + TBgamma[Global`i$1335, 
         Global`d3, Global`dc$1338])*TBgamma5[Global`dc$1338, Global`d2]*
       TBgamma5[Global`dc$1341, Global`d4])*TBT[Global`color, Global`a$1344, 
      Global`A1, Global`A4]*TBT[Global`color, Global`a$1344, Global`A3, 
      Global`A2]))/3, (TBdeltaFund[Global`flavor, Global`F1, 3]*
   TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
    Global`F3, 3]*TBdeltaFund[Global`flavor, Global`F4, 3]*
   (((-(TBdeltaLorentz[Global`i$2609, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$2609, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$2609, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$2609, Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$2609, 0]*TBgamma[0, Global`d1, 
           Global`dc$2612]) + TBgamma[Global`i$2609, Global`d1, 
         Global`dc$2612])*(-(TBdeltaLorentz[Global`i$2609, 0]*
          TBgamma[0, Global`d3, Global`dc$2615]) + TBgamma[Global`i$2609, 
         Global`d3, Global`dc$2615])*TBgamma5[Global`dc$2612, Global`d2]*
       TBgamma5[Global`dc$2615, Global`d4])*TBT[Global`color, Global`a$2618, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$2618, Global`A3, 
      Global`A4] - 
    ((-(TBdeltaLorentz[Global`i$2634, 0]*TBgamma[0, Global`d1, Global`d4]) + 
        TBgamma[Global`i$2634, Global`d1, Global`d4])*
       (-(TBdeltaLorentz[Global`i$2634, 0]*TBgamma[0, Global`d3, 
           Global`d2]) + TBgamma[Global`i$2634, Global`d3, Global`d2]) + 
      (-(TBdeltaLorentz[Global`i$2634, 0]*TBgamma[0, Global`d1, 
           Global`dc$2640]) + TBgamma[Global`i$2634, Global`d1, 
         Global`dc$2640])*(-(TBdeltaLorentz[Global`i$2634, 0]*
          TBgamma[0, Global`d3, Global`dc$2637]) + TBgamma[Global`i$2634, 
         Global`d3, Global`dc$2637])*TBgamma5[Global`dc$2637, Global`d2]*
       TBgamma5[Global`dc$2640, Global`d4])*TBT[Global`color, Global`a$2643, 
      Global`A1, Global`A4]*TBT[Global`color, Global`a$2643, Global`A3, 
      Global`A2]))/3, (TBdeltaFund[Global`flavor, Global`F1, 3]*
   TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
    Global`F3, 3]*TBdeltaFund[Global`flavor, Global`F4, 3]*
   (TBdeltaFund[Global`color, Global`A1, Global`A4]*
     TBdeltaFund[Global`color, Global`A3, Global`A2]*
     (-(TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, 
         Global`d2]) + TBgamma5[Global`d1, Global`d4]*
       TBgamma5[Global`d3, Global`d2]) + 
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])))/3, 
 (TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
    Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
   TBdeltaFund[Global`flavor, Global`F4, 3]*
   ((TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$1665, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$1665, Global`A3, Global`A4] + 
    (-(TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, 
         Global`d2]) + TBgamma5[Global`d1, Global`d4]*
       TBgamma5[Global`d3, Global`d2])*TBT[Global`color, Global`a$1681, 
      Global`A1, Global`A4]*TBT[Global`color, Global`a$1681, Global`A3, 
      Global`A2]))/3, (TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$1310]*TBgamma[0, Global`d3, 
       Global`dc$1313]*TBgamma5[Global`dc$1310, Global`d2]*
      TBgamma5[Global`dc$1313, Global`d4]) + 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    (-(TBgamma[0, Global`d1, Global`d4]*TBgamma[0, Global`d3, Global`d2]) + 
     TBgamma[0, Global`d1, Global`dc$1332]*TBgamma[0, Global`d3, 
       Global`dc$1329]*TBgamma5[Global`dc$1329, Global`d2]*
      TBgamma5[Global`dc$1332, Global`d4]))/3, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$1693, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$1693, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$1693, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$1693, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$1693, 0]*TBgamma[0, Global`d1, 
          Global`dc$1696]) + TBgamma[Global`i$1693, Global`d1, 
        Global`dc$1696])*(-(TBdeltaLorentz[Global`i$1693, 0]*
         TBgamma[0, Global`d3, Global`dc$1699]) + TBgamma[Global`i$1693, 
        Global`d3, Global`dc$1699])*TBgamma5[Global`dc$1696, Global`d2]*
      TBgamma5[Global`dc$1699, Global`d4]) - 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    ((-(TBdeltaLorentz[Global`i$1715, 0]*TBgamma[0, Global`d1, Global`d4]) + 
       TBgamma[Global`i$1715, Global`d1, Global`d4])*
      (-(TBdeltaLorentz[Global`i$1715, 0]*TBgamma[0, Global`d3, Global`d2]) + 
       TBgamma[Global`i$1715, Global`d3, Global`d2]) - 
     (-(TBdeltaLorentz[Global`i$1715, 0]*TBgamma[0, Global`d1, 
          Global`dc$1721]) + TBgamma[Global`i$1715, Global`d1, 
        Global`dc$1721])*(-(TBdeltaLorentz[Global`i$1715, 0]*
         TBgamma[0, Global`d3, Global`dc$1718]) + TBgamma[Global`i$1715, 
        Global`d3, Global`dc$1718])*TBgamma5[Global`dc$1718, Global`d2]*
      TBgamma5[Global`dc$1721, Global`d4]))/3, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
     TBgamma[0, Global`d1, Global`dc$1929]*TBgamma[0, Global`d3, 
       Global`dc$1932]*TBgamma5[Global`dc$1929, Global`d2]*
      TBgamma5[Global`dc$1932, Global`d4]) - 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    (TBgamma[0, Global`d1, Global`d4]*TBgamma[0, Global`d3, Global`d2] + 
     TBgamma[0, Global`d1, Global`dc$1951]*TBgamma[0, Global`d3, 
       Global`dc$1948]*TBgamma5[Global`dc$1948, Global`d2]*
      TBgamma5[Global`dc$1951, Global`d4]))/3, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$2191, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$2191, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$2191, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$2191, Global`d3, Global`d4]) + 
     (-(TBdeltaLorentz[Global`i$2191, 0]*TBgamma[0, Global`d1, 
          Global`dc$2194]) + TBgamma[Global`i$2191, Global`d1, 
        Global`dc$2194])*(-(TBdeltaLorentz[Global`i$2191, 0]*
         TBgamma[0, Global`d3, Global`dc$2197]) + TBgamma[Global`i$2191, 
        Global`d3, Global`dc$2197])*TBgamma5[Global`dc$2194, Global`d2]*
      TBgamma5[Global`dc$2197, Global`d4]) - 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    ((-(TBdeltaLorentz[Global`i$2213, 0]*TBgamma[0, Global`d1, Global`d4]) + 
       TBgamma[Global`i$2213, Global`d1, Global`d4])*
      (-(TBdeltaLorentz[Global`i$2213, 0]*TBgamma[0, Global`d3, Global`d2]) + 
       TBgamma[Global`i$2213, Global`d3, Global`d2]) + 
     (-(TBdeltaLorentz[Global`i$2213, 0]*TBgamma[0, Global`d1, 
          Global`dc$2219]) + TBgamma[Global`i$2213, Global`d1, 
        Global`dc$2219])*(-(TBdeltaLorentz[Global`i$2213, 0]*
         TBgamma[0, Global`d3, Global`dc$2216]) + TBgamma[Global`i$2213, 
        Global`d3, Global`dc$2216])*TBgamma5[Global`dc$2216, Global`d2]*
      TBgamma5[Global`dc$2219, Global`d4]))/3, 
 (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$1851]*TBgamma[0, Global`d3, 
       Global`dc$1854]*TBgamma5[Global`dc$1851, Global`d2]*
      TBgamma5[Global`dc$1854, Global`d4])*TBT[Global`color, Global`a$1857, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$1857, Global`A3, 
     Global`A4] + TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    (-(TBgamma[0, Global`d1, Global`d4]*TBgamma[0, Global`d3, Global`d2]) + 
     TBgamma[0, Global`d1, Global`dc$1876]*TBgamma[0, Global`d3, 
       Global`dc$1873]*TBgamma5[Global`dc$1873, Global`d2]*
      TBgamma5[Global`dc$1876, Global`d4])*TBT[Global`color, Global`a$1879, 
     Global`A1, Global`A4]*TBT[Global`color, Global`a$1879, Global`A3, 
     Global`A2])/3, (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$2211, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$2211, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$2211, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$2211, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$2211, 0]*TBgamma[0, Global`d1, 
          Global`dc$2214]) + TBgamma[Global`i$2211, Global`d1, 
        Global`dc$2214])*(-(TBdeltaLorentz[Global`i$2211, 0]*
         TBgamma[0, Global`d3, Global`dc$2217]) + TBgamma[Global`i$2211, 
        Global`d3, Global`dc$2217])*TBgamma5[Global`dc$2214, Global`d2]*
      TBgamma5[Global`dc$2217, Global`d4])*TBT[Global`color, Global`a$2220, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$2220, Global`A3, 
     Global`A4] - TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    ((-(TBdeltaLorentz[Global`i$2236, 0]*TBgamma[0, Global`d1, Global`d4]) + 
       TBgamma[Global`i$2236, Global`d1, Global`d4])*
      (-(TBdeltaLorentz[Global`i$2236, 0]*TBgamma[0, Global`d3, Global`d2]) + 
       TBgamma[Global`i$2236, Global`d3, Global`d2]) - 
     (-(TBdeltaLorentz[Global`i$2236, 0]*TBgamma[0, Global`d1, 
          Global`dc$2242]) + TBgamma[Global`i$2236, Global`d1, 
        Global`dc$2242])*(-(TBdeltaLorentz[Global`i$2236, 0]*
         TBgamma[0, Global`d3, Global`dc$2239]) + TBgamma[Global`i$2236, 
        Global`d3, Global`dc$2239])*TBgamma5[Global`dc$2239, Global`d2]*
      TBgamma5[Global`dc$2242, Global`d4])*TBT[Global`color, Global`a$2245, 
     Global`A1, Global`A4]*TBT[Global`color, Global`a$2245, Global`A3, 
     Global`A2])/3, (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
     TBgamma[0, Global`d1, Global`dc$2784]*TBgamma[0, Global`d3, 
       Global`dc$2787]*TBgamma5[Global`dc$2784, Global`d2]*
      TBgamma5[Global`dc$2787, Global`d4])*TBT[Global`color, Global`a$2790, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$2790, Global`A3, 
     Global`A4] - TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    (TBgamma[0, Global`d1, Global`d4]*TBgamma[0, Global`d3, Global`d2] + 
     TBgamma[0, Global`d1, Global`dc$2809]*TBgamma[0, Global`d3, 
       Global`dc$2806]*TBgamma5[Global`dc$2806, Global`d2]*
      TBgamma5[Global`dc$2809, Global`d4])*TBT[Global`color, Global`a$2812, 
     Global`A1, Global`A4]*TBT[Global`color, Global`a$2812, Global`A3, 
     Global`A2])/3, (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$3038, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$3038, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$3038, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$3038, Global`d3, Global`d4]) + 
     (-(TBdeltaLorentz[Global`i$3038, 0]*TBgamma[0, Global`d1, 
          Global`dc$3041]) + TBgamma[Global`i$3038, Global`d1, 
        Global`dc$3041])*(-(TBdeltaLorentz[Global`i$3038, 0]*
         TBgamma[0, Global`d3, Global`dc$3044]) + TBgamma[Global`i$3038, 
        Global`d3, Global`dc$3044])*TBgamma5[Global`dc$3041, Global`d2]*
      TBgamma5[Global`dc$3044, Global`d4])*TBT[Global`color, Global`a$3047, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$3047, Global`A3, 
     Global`A4] - TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    ((-(TBdeltaLorentz[Global`i$3063, 0]*TBgamma[0, Global`d1, Global`d4]) + 
       TBgamma[Global`i$3063, Global`d1, Global`d4])*
      (-(TBdeltaLorentz[Global`i$3063, 0]*TBgamma[0, Global`d3, Global`d2]) + 
       TBgamma[Global`i$3063, Global`d3, Global`d2]) + 
     (-(TBdeltaLorentz[Global`i$3063, 0]*TBgamma[0, Global`d1, 
          Global`dc$3069]) + TBgamma[Global`i$3063, Global`d1, 
        Global`dc$3069])*(-(TBdeltaLorentz[Global`i$3063, 0]*
         TBgamma[0, Global`d3, Global`dc$3066]) + TBgamma[Global`i$3063, 
        Global`d3, Global`dc$3066])*TBgamma5[Global`dc$3066, Global`d2]*
      TBgamma5[Global`dc$3069, Global`d4])*TBT[Global`color, Global`a$3072, 
     Global`A1, Global`A4]*TBT[Global`color, Global`a$3072, Global`A3, 
     Global`A2])/3, (TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
     9*TBT[Global`flavor, Global`f$3254, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$3254, Global`F3, Global`F4]) - 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    (TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, Global`d2] - 
     TBgamma5[Global`d1, Global`d4]*TBgamma5[Global`d3, Global`d2])*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F2] + 
     9*TBT[Global`flavor, Global`f$3270, Global`F1, Global`F4]*
      TBT[Global`flavor, Global`f$3270, Global`F3, Global`F2]))/12, 
 ((TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
    TBT[Global`color, Global`a$3380, Global`A1, Global`A2]*
    TBT[Global`color, Global`a$3380, Global`A3, Global`A4]*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
     9*TBT[Global`flavor, Global`f$3383, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$3383, Global`F3, Global`F4]) - 
   (TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, Global`d2] - 
     TBgamma5[Global`d1, Global`d4]*TBgamma5[Global`d3, Global`d2])*
    TBT[Global`color, Global`a$3399, Global`A1, Global`A4]*
    TBT[Global`color, Global`a$3399, Global`A3, Global`A2]*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F2] + 
     9*TBT[Global`flavor, Global`f$3402, Global`F1, Global`F4]*
      TBT[Global`flavor, Global`f$3402, Global`F3, Global`F2]))/12, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*(4*TBdeltaFund[Global`flavor, Global`F1, 
       Global`F2]*TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (2*(TBgamma[0, Global`d1, Global`a$3788]*TBgamma[1, Global`a$3788, 
           Global`d2] - TBgamma[0, Global`a$3791, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3791])*
        (TBgamma[0, Global`d3, Global`a$3794]*TBgamma[1, Global`a$3794, 
           Global`d4] - TBgamma[0, Global`a$3797, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3797]) - 
       (TBgamma[1, Global`a$3824, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$3824] - TBgamma[1, Global`a$3827, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3827])*
        (TBgamma[1, Global`a$3830, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$3830] - TBgamma[1, Global`a$3833, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3833]) + 
       2*(TBgamma[0, Global`d1, Global`a$3800]*TBgamma[2, Global`a$3800, 
           Global`d2] - TBgamma[0, Global`a$3803, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3803])*
        (TBgamma[0, Global`d3, Global`a$3806]*TBgamma[2, Global`a$3806, 
           Global`d4] - TBgamma[0, Global`a$3809, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3809]) - 
       (TBgamma[1, Global`d1, Global`a$3836]*TBgamma[2, Global`a$3836, 
           Global`d2] - TBgamma[1, Global`a$3839, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3839])*
        (TBgamma[1, Global`d3, Global`a$3842]*TBgamma[2, Global`a$3842, 
           Global`d4] - TBgamma[1, Global`a$3845, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3845]) - 
       (TBgamma[1, Global`d1, Global`a$3863]*TBgamma[2, Global`a$3863, 
           Global`d2] - TBgamma[1, Global`a$3860, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3860])*
        (TBgamma[1, Global`d3, Global`a$3869]*TBgamma[2, Global`a$3869, 
           Global`d4] - TBgamma[1, Global`a$3866, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3866]) - 
       (TBgamma[2, Global`a$3872, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$3872] - TBgamma[2, Global`a$3875, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3875])*
        (TBgamma[2, Global`a$3878, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$3878] - TBgamma[2, Global`a$3881, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3881]) + 
       2*(TBgamma[0, Global`d1, Global`a$3812]*TBgamma[3, Global`a$3812, 
           Global`d2] - TBgamma[0, Global`a$3815, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3815])*
        (TBgamma[0, Global`d3, Global`a$3818]*TBgamma[3, Global`a$3818, 
           Global`d4] - TBgamma[0, Global`a$3821, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3821]) - 
       (TBgamma[1, Global`d1, Global`a$3848]*TBgamma[3, Global`a$3848, 
           Global`d2] - TBgamma[1, Global`a$3851, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3851])*
        (TBgamma[1, Global`d3, Global`a$3854]*TBgamma[3, Global`a$3854, 
           Global`d4] - TBgamma[1, Global`a$3857, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3857]) - 
       (TBgamma[2, Global`d1, Global`a$3884]*TBgamma[3, Global`a$3884, 
           Global`d2] - TBgamma[2, Global`a$3887, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3887])*
        (TBgamma[2, Global`d3, Global`a$3890]*TBgamma[3, Global`a$3890, 
           Global`d4] - TBgamma[2, Global`a$3893, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3893]) - 
       (TBgamma[1, Global`d1, Global`a$3899]*TBgamma[3, Global`a$3899, 
           Global`d2] - TBgamma[1, Global`a$3896, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3896])*
        (TBgamma[1, Global`d3, Global`a$3905]*TBgamma[3, Global`a$3905, 
           Global`d4] - TBgamma[1, Global`a$3902, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3902]) - 
       (TBgamma[2, Global`d1, Global`a$3911]*TBgamma[3, Global`a$3911, 
           Global`d2] - TBgamma[2, Global`a$3908, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3908])*
        (TBgamma[2, Global`d3, Global`a$3917]*TBgamma[3, Global`a$3917, 
           Global`d4] - TBgamma[2, Global`a$3914, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3914]) - 
       (TBgamma[3, Global`a$3920, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$3920] - TBgamma[3, Global`a$3923, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3923])*
        (TBgamma[3, Global`a$3926, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$3926] - TBgamma[3, Global`a$3929, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3929])) + 
     9*(2*(TBgamma[0, Global`d1, Global`a$3932]*TBgamma[1, Global`a$3932, 
           Global`d2] - TBgamma[0, Global`a$3935, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3935])*
        (TBgamma[0, Global`d3, Global`a$3938]*TBgamma[1, Global`a$3938, 
           Global`d4] - TBgamma[0, Global`a$3941, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3941]) - 
       (TBgamma[1, Global`a$3968, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$3968] - TBgamma[1, Global`a$3971, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3971])*
        (TBgamma[1, Global`a$3974, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$3974] - TBgamma[1, Global`a$3977, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3977]) + 
       2*(TBgamma[0, Global`d1, Global`a$3944]*TBgamma[2, Global`a$3944, 
           Global`d2] - TBgamma[0, Global`a$3947, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3947])*
        (TBgamma[0, Global`d3, Global`a$3950]*TBgamma[2, Global`a$3950, 
           Global`d4] - TBgamma[0, Global`a$3953, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3953]) - 
       (TBgamma[1, Global`d1, Global`a$3980]*TBgamma[2, Global`a$3980, 
           Global`d2] - TBgamma[1, Global`a$3983, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3983])*
        (TBgamma[1, Global`d3, Global`a$3986]*TBgamma[2, Global`a$3986, 
           Global`d4] - TBgamma[1, Global`a$3989, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3989]) - 
       (TBgamma[1, Global`d1, Global`a$4007]*TBgamma[2, Global`a$4007, 
           Global`d2] - TBgamma[1, Global`a$4004, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4004])*
        (TBgamma[1, Global`d3, Global`a$4013]*TBgamma[2, Global`a$4013, 
           Global`d4] - TBgamma[1, Global`a$4010, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4010]) - 
       (TBgamma[2, Global`a$4016, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$4016] - TBgamma[2, Global`a$4019, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4019])*
        (TBgamma[2, Global`a$4022, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$4022] - TBgamma[2, Global`a$4025, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4025]) + 
       2*(TBgamma[0, Global`d1, Global`a$3956]*TBgamma[3, Global`a$3956, 
           Global`d2] - TBgamma[0, Global`a$3959, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3959])*
        (TBgamma[0, Global`d3, Global`a$3962]*TBgamma[3, Global`a$3962, 
           Global`d4] - TBgamma[0, Global`a$3965, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3965]) - 
       (TBgamma[1, Global`d1, Global`a$3992]*TBgamma[3, Global`a$3992, 
           Global`d2] - TBgamma[1, Global`a$3995, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3995])*
        (TBgamma[1, Global`d3, Global`a$3998]*TBgamma[3, Global`a$3998, 
           Global`d4] - TBgamma[1, Global`a$4001, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4001]) - 
       (TBgamma[2, Global`d1, Global`a$4028]*TBgamma[3, Global`a$4028, 
           Global`d2] - TBgamma[2, Global`a$4031, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4031])*
        (TBgamma[2, Global`d3, Global`a$4034]*TBgamma[3, Global`a$4034, 
           Global`d4] - TBgamma[2, Global`a$4037, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4037]) - 
       (TBgamma[1, Global`d1, Global`a$4043]*TBgamma[3, Global`a$4043, 
           Global`d2] - TBgamma[1, Global`a$4040, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4040])*
        (TBgamma[1, Global`d3, Global`a$4049]*TBgamma[3, Global`a$4049, 
           Global`d4] - TBgamma[1, Global`a$4046, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4046]) - 
       (TBgamma[2, Global`d1, Global`a$4055]*TBgamma[3, Global`a$4055, 
           Global`d2] - TBgamma[2, Global`a$4052, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4052])*
        (TBgamma[2, Global`d3, Global`a$4061]*TBgamma[3, Global`a$4061, 
           Global`d4] - TBgamma[2, Global`a$4058, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4058]) - 
       (TBgamma[3, Global`a$4064, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$4064] - TBgamma[3, Global`a$4067, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4067])*
        (TBgamma[3, Global`a$4070, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$4070] - TBgamma[3, Global`a$4073, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4073]))*TBT[Global`flavor, 
       Global`af$4076, Global`F1, Global`F2]*TBT[Global`flavor, 
       Global`af$4076, Global`F3, Global`F4]) + 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    (-4*TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
      (2*(TBgamma[0, Global`d1, Global`a$4098]*TBgamma[1, Global`a$4098, 
           Global`d4] - TBgamma[0, Global`a$4101, Global`d4]*
          TBgamma[1, Global`d1, Global`a$4101])*
        (TBgamma[0, Global`d3, Global`a$4092]*TBgamma[1, Global`a$4092, 
           Global`d2] - TBgamma[0, Global`a$4095, Global`d2]*
          TBgamma[1, Global`d3, Global`a$4095]) - 
       (TBgamma[1, Global`a$4134, Global`d4]*TBgamma[1, Global`d1, 
           Global`a$4134] - TBgamma[1, Global`a$4137, Global`d4]*
          TBgamma[1, Global`d1, Global`a$4137])*
        (TBgamma[1, Global`a$4128, Global`d2]*TBgamma[1, Global`d3, 
           Global`a$4128] - TBgamma[1, Global`a$4131, Global`d2]*
          TBgamma[1, Global`d3, Global`a$4131]) + 
       2*(TBgamma[0, Global`d1, Global`a$4110]*TBgamma[2, Global`a$4110, 
           Global`d4] - TBgamma[0, Global`a$4113, Global`d4]*
          TBgamma[2, Global`d1, Global`a$4113])*
        (TBgamma[0, Global`d3, Global`a$4104]*TBgamma[2, Global`a$4104, 
           Global`d2] - TBgamma[0, Global`a$4107, Global`d2]*
          TBgamma[2, Global`d3, Global`a$4107]) - 
       (TBgamma[1, Global`d1, Global`a$4146]*TBgamma[2, Global`a$4146, 
           Global`d4] - TBgamma[1, Global`a$4149, Global`d4]*
          TBgamma[2, Global`d1, Global`a$4149])*
        (TBgamma[1, Global`d3, Global`a$4140]*TBgamma[2, Global`a$4140, 
           Global`d2] - TBgamma[1, Global`a$4143, Global`d2]*
          TBgamma[2, Global`d3, Global`a$4143]) - 
       (TBgamma[1, Global`d1, Global`a$4173]*TBgamma[2, Global`a$4173, 
           Global`d4] - TBgamma[1, Global`a$4170, Global`d4]*
          TBgamma[2, Global`d1, Global`a$4170])*
        (TBgamma[1, Global`d3, Global`a$4167]*TBgamma[2, Global`a$4167, 
           Global`d2] - TBgamma[1, Global`a$4164, Global`d2]*
          TBgamma[2, Global`d3, Global`a$4164]) - 
       (TBgamma[2, Global`a$4182, Global`d4]*TBgamma[2, Global`d1, 
           Global`a$4182] - TBgamma[2, Global`a$4185, Global`d4]*
          TBgamma[2, Global`d1, Global`a$4185])*
        (TBgamma[2, Global`a$4176, Global`d2]*TBgamma[2, Global`d3, 
           Global`a$4176] - TBgamma[2, Global`a$4179, Global`d2]*
          TBgamma[2, Global`d3, Global`a$4179]) + 
       2*(TBgamma[0, Global`d1, Global`a$4122]*TBgamma[3, Global`a$4122, 
           Global`d4] - TBgamma[0, Global`a$4125, Global`d4]*
          TBgamma[3, Global`d1, Global`a$4125])*
        (TBgamma[0, Global`d3, Global`a$4116]*TBgamma[3, Global`a$4116, 
           Global`d2] - TBgamma[0, Global`a$4119, Global`d2]*
          TBgamma[3, Global`d3, Global`a$4119]) - 
       (TBgamma[1, Global`d1, Global`a$4158]*TBgamma[3, Global`a$4158, 
           Global`d4] - TBgamma[1, Global`a$4161, Global`d4]*
          TBgamma[3, Global`d1, Global`a$4161])*
        (TBgamma[1, Global`d3, Global`a$4152]*TBgamma[3, Global`a$4152, 
           Global`d2] - TBgamma[1, Global`a$4155, Global`d2]*
          TBgamma[3, Global`d3, Global`a$4155]) - 
       (TBgamma[2, Global`d1, Global`a$4195]*TBgamma[3, Global`a$4195, 
           Global`d4] - TBgamma[2, Global`a$4198, Global`d4]*
          TBgamma[3, Global`d1, Global`a$4198])*
        (TBgamma[2, Global`d3, Global`a$4188]*TBgamma[3, Global`a$4188, 
           Global`d2] - TBgamma[2, Global`a$4191, Global`d2]*
          TBgamma[3, Global`d3, Global`a$4191]) - 
       (TBgamma[1, Global`d1, Global`a$4211]*TBgamma[3, Global`a$4211, 
           Global`d4] - TBgamma[1, Global`a$4208, Global`d4]*
          TBgamma[3, Global`d1, Global`a$4208])*
        (TBgamma[1, Global`d3, Global`a$4204]*TBgamma[3, Global`a$4204, 
           Global`d2] - TBgamma[1, Global`a$4201, Global`d2]*
          TBgamma[3, Global`d3, Global`a$4201]) - 
       (TBgamma[2, Global`d1, Global`a$4223]*TBgamma[3, Global`a$4223, 
           Global`d4] - TBgamma[2, Global`a$4220, Global`d4]*
          TBgamma[3, Global`d1, Global`a$4220])*
        (TBgamma[2, Global`d3, Global`a$4217]*TBgamma[3, Global`a$4217, 
           Global`d2] - TBgamma[2, Global`a$4214, Global`d2]*
          TBgamma[3, Global`d3, Global`a$4214]) - 
       (TBgamma[3, Global`a$4232, Global`d4]*TBgamma[3, Global`d1, 
           Global`a$4232] - TBgamma[3, Global`a$4235, Global`d4]*
          TBgamma[3, Global`d1, Global`a$4235])*
        (TBgamma[3, Global`a$4226, Global`d2]*TBgamma[3, Global`d3, 
           Global`a$4226] - TBgamma[3, Global`a$4229, Global`d2]*
          TBgamma[3, Global`d3, Global`a$4229])) - 
     9*(2*(TBgamma[0, Global`d1, Global`a$4244]*TBgamma[1, Global`a$4244, 
           Global`d4] - TBgamma[0, Global`a$4247, Global`d4]*
          TBgamma[1, Global`d1, Global`a$4247])*
        (TBgamma[0, Global`d3, Global`a$4238]*TBgamma[1, Global`a$4238, 
           Global`d2] - TBgamma[0, Global`a$4241, Global`d2]*
          TBgamma[1, Global`d3, Global`a$4241]) - 
       (TBgamma[1, Global`a$4281, Global`d4]*TBgamma[1, Global`d1, 
           Global`a$4281] - TBgamma[1, Global`a$4284, Global`d4]*
          TBgamma[1, Global`d1, Global`a$4284])*
        (TBgamma[1, Global`a$4275, Global`d2]*TBgamma[1, Global`d3, 
           Global`a$4275] - TBgamma[1, Global`a$4278, Global`d2]*
          TBgamma[1, Global`d3, Global`a$4278]) + 
       2*(TBgamma[0, Global`d1, Global`a$4256]*TBgamma[2, Global`a$4256, 
           Global`d4] - TBgamma[0, Global`a$4259, Global`d4]*
          TBgamma[2, Global`d1, Global`a$4259])*
        (TBgamma[0, Global`d3, Global`a$4250]*TBgamma[2, Global`a$4250, 
           Global`d2] - TBgamma[0, Global`a$4253, Global`d2]*
          TBgamma[2, Global`d3, Global`a$4253]) - 
       (TBgamma[1, Global`d1, Global`a$4293]*TBgamma[2, Global`a$4293, 
           Global`d4] - TBgamma[1, Global`a$4296, Global`d4]*
          TBgamma[2, Global`d1, Global`a$4296])*
        (TBgamma[1, Global`d3, Global`a$4287]*TBgamma[2, Global`a$4287, 
           Global`d2] - TBgamma[1, Global`a$4290, Global`d2]*
          TBgamma[2, Global`d3, Global`a$4290]) - 
       (TBgamma[1, Global`d1, Global`a$4321]*TBgamma[2, Global`a$4321, 
           Global`d4] - TBgamma[1, Global`a$4318, Global`d4]*
          TBgamma[2, Global`d1, Global`a$4318])*
        (TBgamma[1, Global`d3, Global`a$4315]*TBgamma[2, Global`a$4315, 
           Global`d2] - TBgamma[1, Global`a$4312, Global`d2]*
          TBgamma[2, Global`d3, Global`a$4312]) - 
       (TBgamma[2, Global`a$4330, Global`d4]*TBgamma[2, Global`d1, 
           Global`a$4330] - TBgamma[2, Global`a$4333, Global`d4]*
          TBgamma[2, Global`d1, Global`a$4333])*
        (TBgamma[2, Global`a$4324, Global`d2]*TBgamma[2, Global`d3, 
           Global`a$4324] - TBgamma[2, Global`a$4327, Global`d2]*
          TBgamma[2, Global`d3, Global`a$4327]) + 
       2*(TBgamma[0, Global`d1, Global`a$4268]*TBgamma[3, Global`a$4268, 
           Global`d4] - TBgamma[0, Global`a$4272, Global`d4]*
          TBgamma[3, Global`d1, Global`a$4272])*
        (TBgamma[0, Global`d3, Global`a$4262]*TBgamma[3, Global`a$4262, 
           Global`d2] - TBgamma[0, Global`a$4265, Global`d2]*
          TBgamma[3, Global`d3, Global`a$4265]) - 
       (TBgamma[1, Global`d1, Global`a$4305]*TBgamma[3, Global`a$4305, 
           Global`d4] - TBgamma[1, Global`a$4308, Global`d4]*
          TBgamma[3, Global`d1, Global`a$4308])*
        (TBgamma[1, Global`d3, Global`a$4299]*TBgamma[3, Global`a$4299, 
           Global`d2] - TBgamma[1, Global`a$4302, Global`d2]*
          TBgamma[3, Global`d3, Global`a$4302]) - 
       (TBgamma[2, Global`d1, Global`a$4342]*TBgamma[3, Global`a$4342, 
           Global`d4] - TBgamma[2, Global`a$4345, Global`d4]*
          TBgamma[3, Global`d1, Global`a$4345])*
        (TBgamma[2, Global`d3, Global`a$4336]*TBgamma[3, Global`a$4336, 
           Global`d2] - TBgamma[2, Global`a$4339, Global`d2]*
          TBgamma[3, Global`d3, Global`a$4339]) - 
       (TBgamma[1, Global`d1, Global`a$4357]*TBgamma[3, Global`a$4357, 
           Global`d4] - TBgamma[1, Global`a$4354, Global`d4]*
          TBgamma[3, Global`d1, Global`a$4354])*
        (TBgamma[1, Global`d3, Global`a$4351]*TBgamma[3, Global`a$4351, 
           Global`d2] - TBgamma[1, Global`a$4348, Global`d2]*
          TBgamma[3, Global`d3, Global`a$4348]) - 
       (TBgamma[2, Global`d1, Global`a$4369]*TBgamma[3, Global`a$4369, 
           Global`d4] - TBgamma[2, Global`a$4366, Global`d4]*
          TBgamma[3, Global`d1, Global`a$4366])*
        (TBgamma[2, Global`d3, Global`a$4363]*TBgamma[3, Global`a$4363, 
           Global`d2] - TBgamma[2, Global`a$4360, Global`d2]*
          TBgamma[3, Global`d3, Global`a$4360]) - 
       (TBgamma[3, Global`a$4379, Global`d4]*TBgamma[3, Global`d1, 
           Global`a$4379] - TBgamma[3, Global`a$4382, Global`d4]*
          TBgamma[3, Global`d1, Global`a$4382])*
        (TBgamma[3, Global`a$4372, Global`d2]*TBgamma[3, Global`d3, 
           Global`a$4372] - TBgamma[3, Global`a$4376, Global`d2]*
          TBgamma[3, Global`d3, Global`a$4376]))*TBT[Global`flavor, 
       Global`af$4385, Global`F1, Global`F4]*TBT[Global`flavor, 
       Global`af$4385, Global`F3, Global`F2]))/48, 
 (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (2*(TBgamma[0, Global`d1, Global`a$4179]*TBgamma[1, Global`a$4179, 
         Global`d2] - TBgamma[0, Global`a$4182, Global`d2]*
        TBgamma[1, Global`d1, Global`a$4182])*
      (TBgamma[0, Global`d3, Global`a$4185]*TBgamma[1, Global`a$4185, 
         Global`d4] - TBgamma[0, Global`a$4188, Global`d4]*
        TBgamma[1, Global`d3, Global`a$4188]) - 
     (TBgamma[1, Global`a$4217, Global`d2]*TBgamma[1, Global`d1, 
         Global`a$4217] - TBgamma[1, Global`a$4220, Global`d2]*
        TBgamma[1, Global`d1, Global`a$4220])*
      (TBgamma[1, Global`a$4223, Global`d4]*TBgamma[1, Global`d3, 
         Global`a$4223] - TBgamma[1, Global`a$4226, Global`d4]*
        TBgamma[1, Global`d3, Global`a$4226]) + 
     2*(TBgamma[0, Global`d1, Global`a$4191]*TBgamma[2, Global`a$4191, 
         Global`d2] - TBgamma[0, Global`a$4195, Global`d2]*
        TBgamma[2, Global`d1, Global`a$4195])*
      (TBgamma[0, Global`d3, Global`a$4198]*TBgamma[2, Global`a$4198, 
         Global`d4] - TBgamma[0, Global`a$4201, Global`d4]*
        TBgamma[2, Global`d3, Global`a$4201]) - 
     (TBgamma[1, Global`d1, Global`a$4229]*TBgamma[2, Global`a$4229, 
         Global`d2] - TBgamma[1, Global`a$4232, Global`d2]*
        TBgamma[2, Global`d1, Global`a$4232])*
      (TBgamma[1, Global`d3, Global`a$4235]*TBgamma[2, Global`a$4235, 
         Global`d4] - TBgamma[1, Global`a$4238, Global`d4]*
        TBgamma[2, Global`d3, Global`a$4238]) - 
     (TBgamma[1, Global`d1, Global`a$4256]*TBgamma[2, Global`a$4256, 
         Global`d2] - TBgamma[1, Global`a$4253, Global`d2]*
        TBgamma[2, Global`d1, Global`a$4253])*
      (TBgamma[1, Global`d3, Global`a$4262]*TBgamma[2, Global`a$4262, 
         Global`d4] - TBgamma[1, Global`a$4259, Global`d4]*
        TBgamma[2, Global`d3, Global`a$4259]) - 
     (TBgamma[2, Global`a$4265, Global`d2]*TBgamma[2, Global`d1, 
         Global`a$4265] - TBgamma[2, Global`a$4268, Global`d2]*
        TBgamma[2, Global`d1, Global`a$4268])*
      (TBgamma[2, Global`a$4272, Global`d4]*TBgamma[2, Global`d3, 
         Global`a$4272] - TBgamma[2, Global`a$4275, Global`d4]*
        TBgamma[2, Global`d3, Global`a$4275]) + 
     2*(TBgamma[0, Global`d1, Global`a$4204]*TBgamma[3, Global`a$4204, 
         Global`d2] - TBgamma[0, Global`a$4208, Global`d2]*
        TBgamma[3, Global`d1, Global`a$4208])*
      (TBgamma[0, Global`d3, Global`a$4211]*TBgamma[3, Global`a$4211, 
         Global`d4] - TBgamma[0, Global`a$4214, Global`d4]*
        TBgamma[3, Global`d3, Global`a$4214]) - 
     (TBgamma[1, Global`d1, Global`a$4241]*TBgamma[3, Global`a$4241, 
         Global`d2] - TBgamma[1, Global`a$4244, Global`d2]*
        TBgamma[3, Global`d1, Global`a$4244])*
      (TBgamma[1, Global`d3, Global`a$4247]*TBgamma[3, Global`a$4247, 
         Global`d4] - TBgamma[1, Global`a$4250, Global`d4]*
        TBgamma[3, Global`d3, Global`a$4250]) - 
     (TBgamma[2, Global`d1, Global`a$4278]*TBgamma[3, Global`a$4278, 
         Global`d2] - TBgamma[2, Global`a$4281, Global`d2]*
        TBgamma[3, Global`d1, Global`a$4281])*
      (TBgamma[2, Global`d3, Global`a$4284]*TBgamma[3, Global`a$4284, 
         Global`d4] - TBgamma[2, Global`a$4287, Global`d4]*
        TBgamma[3, Global`d3, Global`a$4287]) - 
     (TBgamma[1, Global`d1, Global`a$4293]*TBgamma[3, Global`a$4293, 
         Global`d2] - TBgamma[1, Global`a$4290, Global`d2]*
        TBgamma[3, Global`d1, Global`a$4290])*
      (TBgamma[1, Global`d3, Global`a$4299]*TBgamma[3, Global`a$4299, 
         Global`d4] - TBgamma[1, Global`a$4296, Global`d4]*
        TBgamma[3, Global`d3, Global`a$4296]) - 
     (TBgamma[2, Global`d1, Global`a$4305]*TBgamma[3, Global`a$4305, 
         Global`d2] - TBgamma[2, Global`a$4302, Global`d2]*
        TBgamma[3, Global`d1, Global`a$4302])*
      (TBgamma[2, Global`d3, Global`a$4312]*TBgamma[3, Global`a$4312, 
         Global`d4] - TBgamma[2, Global`a$4308, Global`d4]*
        TBgamma[3, Global`d3, Global`a$4308]) - 
     (TBgamma[3, Global`a$4315, Global`d2]*TBgamma[3, Global`d1, 
         Global`a$4315] - TBgamma[3, Global`a$4318, Global`d2]*
        TBgamma[3, Global`d1, Global`a$4318])*
      (TBgamma[3, Global`a$4321, Global`d4]*TBgamma[3, Global`d3, 
         Global`a$4321] - TBgamma[3, Global`a$4324, Global`d4]*
        TBgamma[3, Global`d3, Global`a$4324]))*TBT[Global`color, 
     Global`ac$4472, Global`A1, Global`A2]*TBT[Global`color, Global`ac$4472, 
     Global`A3, Global`A4] - 4*TBdeltaFund[Global`flavor, Global`F1, 
     Global`F4]*TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    (2*(TBgamma[0, Global`d1, Global`a$4497]*TBgamma[1, Global`a$4497, 
         Global`d4] - TBgamma[0, Global`a$4500, Global`d4]*
        TBgamma[1, Global`d1, Global`a$4500])*
      (TBgamma[0, Global`d3, Global`a$4491]*TBgamma[1, Global`a$4491, 
         Global`d2] - TBgamma[0, Global`a$4494, Global`d2]*
        TBgamma[1, Global`d3, Global`a$4494]) - 
     (TBgamma[1, Global`a$4533, Global`d4]*TBgamma[1, Global`d1, 
         Global`a$4533] - TBgamma[1, Global`a$4536, Global`d4]*
        TBgamma[1, Global`d1, Global`a$4536])*
      (TBgamma[1, Global`a$4527, Global`d2]*TBgamma[1, Global`d3, 
         Global`a$4527] - TBgamma[1, Global`a$4530, Global`d2]*
        TBgamma[1, Global`d3, Global`a$4530]) + 
     2*(TBgamma[0, Global`d1, Global`a$4509]*TBgamma[2, Global`a$4509, 
         Global`d4] - TBgamma[0, Global`a$4512, Global`d4]*
        TBgamma[2, Global`d1, Global`a$4512])*
      (TBgamma[0, Global`d3, Global`a$4503]*TBgamma[2, Global`a$4503, 
         Global`d2] - TBgamma[0, Global`a$4506, Global`d2]*
        TBgamma[2, Global`d3, Global`a$4506]) - 
     (TBgamma[1, Global`d1, Global`a$4545]*TBgamma[2, Global`a$4545, 
         Global`d4] - TBgamma[1, Global`a$4548, Global`d4]*
        TBgamma[2, Global`d1, Global`a$4548])*
      (TBgamma[1, Global`d3, Global`a$4539]*TBgamma[2, Global`a$4539, 
         Global`d2] - TBgamma[1, Global`a$4542, Global`d2]*
        TBgamma[2, Global`d3, Global`a$4542]) - 
     (TBgamma[1, Global`d1, Global`a$4572]*TBgamma[2, Global`a$4572, 
         Global`d4] - TBgamma[1, Global`a$4569, Global`d4]*
        TBgamma[2, Global`d1, Global`a$4569])*
      (TBgamma[1, Global`d3, Global`a$4566]*TBgamma[2, Global`a$4566, 
         Global`d2] - TBgamma[1, Global`a$4563, Global`d2]*
        TBgamma[2, Global`d3, Global`a$4563]) - 
     (TBgamma[2, Global`a$4581, Global`d4]*TBgamma[2, Global`d1, 
         Global`a$4581] - TBgamma[2, Global`a$4584, Global`d4]*
        TBgamma[2, Global`d1, Global`a$4584])*
      (TBgamma[2, Global`a$4575, Global`d2]*TBgamma[2, Global`d3, 
         Global`a$4575] - TBgamma[2, Global`a$4578, Global`d2]*
        TBgamma[2, Global`d3, Global`a$4578]) + 
     2*(TBgamma[0, Global`d1, Global`a$4521]*TBgamma[3, Global`a$4521, 
         Global`d4] - TBgamma[0, Global`a$4524, Global`d4]*
        TBgamma[3, Global`d1, Global`a$4524])*
      (TBgamma[0, Global`d3, Global`a$4515]*TBgamma[3, Global`a$4515, 
         Global`d2] - TBgamma[0, Global`a$4518, Global`d2]*
        TBgamma[3, Global`d3, Global`a$4518]) - 
     (TBgamma[1, Global`d1, Global`a$4557]*TBgamma[3, Global`a$4557, 
         Global`d4] - TBgamma[1, Global`a$4560, Global`d4]*
        TBgamma[3, Global`d1, Global`a$4560])*
      (TBgamma[1, Global`d3, Global`a$4551]*TBgamma[3, Global`a$4551, 
         Global`d2] - TBgamma[1, Global`a$4554, Global`d2]*
        TBgamma[3, Global`d3, Global`a$4554]) - 
     (TBgamma[2, Global`d1, Global`a$4593]*TBgamma[3, Global`a$4593, 
         Global`d4] - TBgamma[2, Global`a$4596, Global`d4]*
        TBgamma[3, Global`d1, Global`a$4596])*
      (TBgamma[2, Global`d3, Global`a$4587]*TBgamma[3, Global`a$4587, 
         Global`d2] - TBgamma[2, Global`a$4590, Global`d2]*
        TBgamma[3, Global`d3, Global`a$4590]) - 
     (TBgamma[1, Global`d1, Global`a$4608]*TBgamma[3, Global`a$4608, 
         Global`d4] - TBgamma[1, Global`a$4605, Global`d4]*
        TBgamma[3, Global`d1, Global`a$4605])*
      (TBgamma[1, Global`d3, Global`a$4602]*TBgamma[3, Global`a$4602, 
         Global`d2] - TBgamma[1, Global`a$4599, Global`d2]*
        TBgamma[3, Global`d3, Global`a$4599]) - 
     (TBgamma[2, Global`d1, Global`a$4620]*TBgamma[3, Global`a$4620, 
         Global`d4] - TBgamma[2, Global`a$4617, Global`d4]*
        TBgamma[3, Global`d1, Global`a$4617])*
      (TBgamma[2, Global`d3, Global`a$4614]*TBgamma[3, Global`a$4614, 
         Global`d2] - TBgamma[2, Global`a$4611, Global`d2]*
        TBgamma[3, Global`d3, Global`a$4611]) - 
     (TBgamma[3, Global`a$4629, Global`d4]*TBgamma[3, Global`d1, 
         Global`a$4629] - TBgamma[3, Global`a$4632, Global`d4]*
        TBgamma[3, Global`d1, Global`a$4632])*
      (TBgamma[3, Global`a$4623, Global`d2]*TBgamma[3, Global`d3, 
         Global`a$4623] - TBgamma[3, Global`a$4626, Global`d2]*
        TBgamma[3, Global`d3, Global`a$4626]))*TBT[Global`color, 
     Global`ac$4779, Global`A1, Global`A4]*TBT[Global`color, Global`ac$4779, 
     Global`A3, Global`A2] + 
   9*((2*(TBgamma[0, Global`d1, Global`a$4327]*TBgamma[1, Global`a$4327, 
           Global`d2] - TBgamma[0, Global`a$4330, Global`d2]*
          TBgamma[1, Global`d1, Global`a$4330])*
        (TBgamma[0, Global`d3, Global`a$4333]*TBgamma[1, Global`a$4333, 
           Global`d4] - TBgamma[0, Global`a$4336, Global`d4]*
          TBgamma[1, Global`d3, Global`a$4336]) - 
       (TBgamma[1, Global`a$4363, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$4363] - TBgamma[1, Global`a$4366, Global`d2]*
          TBgamma[1, Global`d1, Global`a$4366])*
        (TBgamma[1, Global`a$4369, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$4369] - TBgamma[1, Global`a$4372, Global`d4]*
          TBgamma[1, Global`d3, Global`a$4372]) + 
       2*(TBgamma[0, Global`d1, Global`a$4339]*TBgamma[2, Global`a$4339, 
           Global`d2] - TBgamma[0, Global`a$4342, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4342])*
        (TBgamma[0, Global`d3, Global`a$4345]*TBgamma[2, Global`a$4345, 
           Global`d4] - TBgamma[0, Global`a$4348, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4348]) - 
       (TBgamma[1, Global`d1, Global`a$4376]*TBgamma[2, Global`a$4376, 
           Global`d2] - TBgamma[1, Global`a$4379, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4379])*
        (TBgamma[1, Global`d3, Global`a$4382]*TBgamma[2, Global`a$4382, 
           Global`d4] - TBgamma[1, Global`a$4385, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4385]) - 
       (TBgamma[1, Global`d1, Global`a$4403]*TBgamma[2, Global`a$4403, 
           Global`d2] - TBgamma[1, Global`a$4400, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4400])*
        (TBgamma[1, Global`d3, Global`a$4409]*TBgamma[2, Global`a$4409, 
           Global`d4] - TBgamma[1, Global`a$4406, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4406]) - 
       (TBgamma[2, Global`a$4412, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$4412] - TBgamma[2, Global`a$4415, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4415])*
        (TBgamma[2, Global`a$4418, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$4418] - TBgamma[2, Global`a$4421, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4421]) + 
       2*(TBgamma[0, Global`d1, Global`a$4351]*TBgamma[3, Global`a$4351, 
           Global`d2] - TBgamma[0, Global`a$4354, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4354])*
        (TBgamma[0, Global`d3, Global`a$4357]*TBgamma[3, Global`a$4357, 
           Global`d4] - TBgamma[0, Global`a$4360, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4360]) - 
       (TBgamma[1, Global`d1, Global`a$4388]*TBgamma[3, Global`a$4388, 
           Global`d2] - TBgamma[1, Global`a$4391, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4391])*
        (TBgamma[1, Global`d3, Global`a$4394]*TBgamma[3, Global`a$4394, 
           Global`d4] - TBgamma[1, Global`a$4397, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4397]) - 
       (TBgamma[2, Global`d1, Global`a$4424]*TBgamma[3, Global`a$4424, 
           Global`d2] - TBgamma[2, Global`a$4427, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4427])*
        (TBgamma[2, Global`d3, Global`a$4430]*TBgamma[3, Global`a$4430, 
           Global`d4] - TBgamma[2, Global`a$4433, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4433]) - 
       (TBgamma[1, Global`d1, Global`a$4439]*TBgamma[3, Global`a$4439, 
           Global`d2] - TBgamma[1, Global`a$4436, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4436])*
        (TBgamma[1, Global`d3, Global`a$4445]*TBgamma[3, Global`a$4445, 
           Global`d4] - TBgamma[1, Global`a$4442, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4442]) - 
       (TBgamma[2, Global`d1, Global`a$4451]*TBgamma[3, Global`a$4451, 
           Global`d2] - TBgamma[2, Global`a$4448, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4448])*
        (TBgamma[2, Global`d3, Global`a$4457]*TBgamma[3, Global`a$4457, 
           Global`d4] - TBgamma[2, Global`a$4454, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4454]) - 
       (TBgamma[3, Global`a$4460, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$4460] - TBgamma[3, Global`a$4463, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4463])*
        (TBgamma[3, Global`a$4466, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$4466] - TBgamma[3, Global`a$4469, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4469]))*TBT[Global`color, 
       Global`ac$4472, Global`A1, Global`A2]*TBT[Global`color, 
       Global`ac$4472, Global`A3, Global`A4]*TBT[Global`flavor, 
       Global`af$4475, Global`F1, Global`F2]*TBT[Global`flavor, 
       Global`af$4475, Global`F3, Global`F4] + 
     (-2*(TBgamma[0, Global`d1, Global`a$4641]*TBgamma[1, Global`a$4641, 
           Global`d4] - TBgamma[0, Global`a$4644, Global`d4]*
          TBgamma[1, Global`d1, Global`a$4644])*
        (TBgamma[0, Global`d3, Global`a$4635]*TBgamma[1, Global`a$4635, 
           Global`d2] - TBgamma[0, Global`a$4638, Global`d2]*
          TBgamma[1, Global`d3, Global`a$4638]) + 
       (TBgamma[1, Global`a$4677, Global`d4]*TBgamma[1, Global`d1, 
           Global`a$4677] - TBgamma[1, Global`a$4680, Global`d4]*
          TBgamma[1, Global`d1, Global`a$4680])*
        (TBgamma[1, Global`a$4671, Global`d2]*TBgamma[1, Global`d3, 
           Global`a$4671] - TBgamma[1, Global`a$4674, Global`d2]*
          TBgamma[1, Global`d3, Global`a$4674]) - 
       2*(TBgamma[0, Global`d1, Global`a$4653]*TBgamma[2, Global`a$4653, 
           Global`d4] - TBgamma[0, Global`a$4656, Global`d4]*
          TBgamma[2, Global`d1, Global`a$4656])*
        (TBgamma[0, Global`d3, Global`a$4647]*TBgamma[2, Global`a$4647, 
           Global`d2] - TBgamma[0, Global`a$4650, Global`d2]*
          TBgamma[2, Global`d3, Global`a$4650]) + 
       (TBgamma[1, Global`d1, Global`a$4689]*TBgamma[2, Global`a$4689, 
           Global`d4] - TBgamma[1, Global`a$4692, Global`d4]*
          TBgamma[2, Global`d1, Global`a$4692])*
        (TBgamma[1, Global`d3, Global`a$4683]*TBgamma[2, Global`a$4683, 
           Global`d2] - TBgamma[1, Global`a$4686, Global`d2]*
          TBgamma[2, Global`d3, Global`a$4686]) + 
       (TBgamma[1, Global`d1, Global`a$4716]*TBgamma[2, Global`a$4716, 
           Global`d4] - TBgamma[1, Global`a$4713, Global`d4]*
          TBgamma[2, Global`d1, Global`a$4713])*
        (TBgamma[1, Global`d3, Global`a$4710]*TBgamma[2, Global`a$4710, 
           Global`d2] - TBgamma[1, Global`a$4707, Global`d2]*
          TBgamma[2, Global`d3, Global`a$4707]) + 
       (TBgamma[2, Global`a$4725, Global`d4]*TBgamma[2, Global`d1, 
           Global`a$4725] - TBgamma[2, Global`a$4728, Global`d4]*
          TBgamma[2, Global`d1, Global`a$4728])*
        (TBgamma[2, Global`a$4719, Global`d2]*TBgamma[2, Global`d3, 
           Global`a$4719] - TBgamma[2, Global`a$4722, Global`d2]*
          TBgamma[2, Global`d3, Global`a$4722]) - 
       2*(TBgamma[0, Global`d1, Global`a$4665]*TBgamma[3, Global`a$4665, 
           Global`d4] - TBgamma[0, Global`a$4668, Global`d4]*
          TBgamma[3, Global`d1, Global`a$4668])*
        (TBgamma[0, Global`d3, Global`a$4659]*TBgamma[3, Global`a$4659, 
           Global`d2] - TBgamma[0, Global`a$4662, Global`d2]*
          TBgamma[3, Global`d3, Global`a$4662]) + 
       (TBgamma[1, Global`d1, Global`a$4701]*TBgamma[3, Global`a$4701, 
           Global`d4] - TBgamma[1, Global`a$4704, Global`d4]*
          TBgamma[3, Global`d1, Global`a$4704])*
        (TBgamma[1, Global`d3, Global`a$4695]*TBgamma[3, Global`a$4695, 
           Global`d2] - TBgamma[1, Global`a$4698, Global`d2]*
          TBgamma[3, Global`d3, Global`a$4698]) + 
       (TBgamma[2, Global`d1, Global`a$4737]*TBgamma[3, Global`a$4737, 
           Global`d4] - TBgamma[2, Global`a$4740, Global`d4]*
          TBgamma[3, Global`d1, Global`a$4740])*
        (TBgamma[2, Global`d3, Global`a$4731]*TBgamma[3, Global`a$4731, 
           Global`d2] - TBgamma[2, Global`a$4734, Global`d2]*
          TBgamma[3, Global`d3, Global`a$4734]) + 
       (TBgamma[1, Global`d1, Global`a$4752]*TBgamma[3, Global`a$4752, 
           Global`d4] - TBgamma[1, Global`a$4749, Global`d4]*
          TBgamma[3, Global`d1, Global`a$4749])*
        (TBgamma[1, Global`d3, Global`a$4746]*TBgamma[3, Global`a$4746, 
           Global`d2] - TBgamma[1, Global`a$4743, Global`d2]*
          TBgamma[3, Global`d3, Global`a$4743]) + 
       (TBgamma[2, Global`d1, Global`a$4764]*TBgamma[3, Global`a$4764, 
           Global`d4] - TBgamma[2, Global`a$4761, Global`d4]*
          TBgamma[3, Global`d1, Global`a$4761])*
        (TBgamma[2, Global`d3, Global`a$4758]*TBgamma[3, Global`a$4758, 
           Global`d2] - TBgamma[2, Global`a$4755, Global`d2]*
          TBgamma[3, Global`d3, Global`a$4755]) + 
       (TBgamma[3, Global`a$4773, Global`d4]*TBgamma[3, Global`d1, 
           Global`a$4773] - TBgamma[3, Global`a$4776, Global`d4]*
          TBgamma[3, Global`d1, Global`a$4776])*
        (TBgamma[3, Global`a$4767, Global`d2]*TBgamma[3, Global`d3, 
           Global`a$4767] - TBgamma[3, Global`a$4770, Global`d2]*
          TBgamma[3, Global`d3, Global`a$4770]))*TBT[Global`color, 
       Global`ac$4779, Global`A1, Global`A4]*TBT[Global`color, 
       Global`ac$4779, Global`A3, Global`A2]*TBT[Global`flavor, 
       Global`af$4782, Global`F1, Global`F4]*TBT[Global`flavor, 
       Global`af$4782, Global`F3, Global`F2]))/48}
