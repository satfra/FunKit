(* Created with the Wolfram Language : www.wolfram.com *)
{{(9*Global`Nf*(2 + Global`Nf))/(32*Global`Nc^2*(-1 + Global`Nf)*
    (-2 + Global`Nf^2)), 0, 0, 0, 0, 0, 0, 0, 
  (9*Global`Nf^2)/(32*Global`Nc^2*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 
  0, 0, 0, (-9*(18 - 34*Global`Nf - 9*Global`Nf^2 + 8*Global`Nf^3))/
   (32*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  0, 0, 0, 0, 0, 0, 0, (9*Global`Nf)/(4*Global`Nc^3*(-1 + Global`Nf)*
    (-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  (9*Global`Nf)/(2*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), (9*Global`Nf)/(8*Global`Nc^3*(-1 + Global`Nf)*
    (-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  (9*Global`Nf)/(4*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2))}, {0, (3*Global`Nf*(2 + Global`Nf))/
   (32*Global`Nc^2*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 0, 0, 0, 0, 
  (-3*Global`Nf^2)/(32*Global`Nc^2*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 
  0, 0, (-3*Global`Nf^2)/(16*Global`Nc^3*(-1 + Global`Nf)*
    (-2 + Global`Nf^2)), (-3*Global`Nf^2)/(8*Global`Nc^2*(-1 + Global`Nf)*
    (-2 + Global`Nf^2)), 0, 
  (-3*(18 - 34*Global`Nf - 9*Global`Nf^2 + 8*Global`Nf^3))/
   (32*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  0, 0, 0, 0, 0, 0, (9*Global`Nf)/(4*Global`Nc^3*(-1 + Global`Nf)*
    (-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  (9*Global`Nf)/(2*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), (-3*Global`Nf)/(8*Global`Nc^3*(-1 + Global`Nf)*
    (-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  (-3*Global`Nf)/(4*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2))}, {0, 0, (9*(1 + Global`Nc*(-2 + Global`Nf^2)))/
   (32*Global`Nc^3*(-2 + Global`Nf)*(-1 + Global`Nf)*Global`Nf), 
  -9/(32*Global`Nc^3*(-2 + Global`Nf)*(-1 + Global`Nf)*Global`Nf), 0, 0, 
  9/(16*Global`Nc^2*(-2 + Global`Nf)*(-1 + Global`Nf)*Global`Nf), 
  -9/(16*Global`Nc^2*(-2 + Global`Nf)*(-1 + Global`Nf)*Global`Nf), 0, 
  9/(32*Global`Nc^2*(-1 + Global`Nf)), 0, 0, 0, 0, 0, 0, 
  -9/(32*Global`Nc^2*(-1 + Global`Nf)), 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, -9/(32*Global`Nc^3*(-2 + Global`Nf)*(-1 + Global`Nf)*Global`Nf), 
  (3*(-1 + Global`Nc*(-2 + Global`Nf^2)))/(32*Global`Nc^3*(-2 + Global`Nf)*
    (-1 + Global`Nf)*Global`Nf), 0, 0, 
  -9/(16*Global`Nc^2*(-2 + Global`Nf)*(-1 + Global`Nf)*Global`Nf), 
  -3/(16*Global`Nc^2*(-2 + Global`Nf)*(-1 + Global`Nf)*Global`Nf), 0, 
  -9/(32*(-2 + Global`Nc)*Global`Nc*(-1 + Global`Nf)), 0, 
  3/(8*(-2 + Global`Nc)*Global`Nc*(-1 + Global`Nf)), 0, 0, 0, 0, 0, 
  -3/(32*Global`Nc^2*(-1 + Global`Nf)), 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, (9*Global`Nf*(2 + Global`Nf))/(8*(-1 + Global`Nc^2)*
    (-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 0, 0, 0, 
  (-9*Global`Nf^2)/(8*(-1 + Global`Nc^2)*(-1 + Global`Nf)*
    (-2 + Global`Nf^2)), 0, (-9*Global`Nf^2)/(8*Global`Nc^2*(-1 + Global`Nf)*
    (-2 + Global`Nf^2)), (9*Global`Nf^2)/(4*Global`Nc*(-1 + Global`Nc^2)*
    (-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 0, 0, 
  (-9*(18 - 34*Global`Nf - 9*Global`Nf^2 + 8*Global`Nf^3))/
   (8*(-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), 0, 0, 0, (9*Global`Nf)/
   (2*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  (-9*Global`Nf)/(Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf)*
    (-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  (9*Global`Nf)/(4*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), (-9*Global`Nf)/(2*Global`Nc*(-1 + Global`Nc^2)*
    (-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2))}, 
 {0, 0, 0, 0, 0, (3*Global`Nf*(2 + Global`Nf))/(8*(-1 + Global`Nc^2)*
    (-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 0, 0, 
  (3*Global`Nf^2)/(8*(-1 + Global`Nc^2)*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 
  0, 0, 0, 0, 0, 0, 0, 0, (-3*(18 - 34*Global`Nf - 9*Global`Nf^2 + 
     8*Global`Nf^3))/(8*(-1 + Global`Nc^2)*(-1 + Global`Nf)*
    (-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 
  (9*Global`Nf)/(2*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), (-9*Global`Nf)/(Global`Nc*(-1 + Global`Nc^2)*
    (-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  (-3*Global`Nf)/(4*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), (3*Global`Nf)/(2*Global`Nc*(-1 + Global`Nc^2)*
    (-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2))}, 
 {0, 0, 9/(16*Global`Nc^2*(-2 + Global`Nf)*(-1 + Global`Nf)*Global`Nf), 
  -9/(16*Global`Nc^2*(-2 + Global`Nf)*(-1 + Global`Nf)*Global`Nf), 0, 0, 
  (9*(-1 + Global`Nc*(-2 + Global`Nf^2)))/(8*Global`Nc*(-1 + Global`Nc^2)*
    (-2 + Global`Nf)*(-1 + Global`Nf)*Global`Nf), 
  9/(8*Global`Nc*(-1 + Global`Nc^2)*(-2 + Global`Nf)*(-1 + Global`Nf)*
    Global`Nf), 0, -9/(8*(-2 + Global`Nc)*Global`Nc*(-1 + Global`Nf)), 0, 
  (9*Global`Nc)/(8*(-2 + Global`Nc)*(-1 + Global`Nc^2)*(-1 + Global`Nf)), 0, 
  0, 0, 0, 0, 0, 0, 0, -9/(8*(-1 + Global`Nc^2)*(-1 + Global`Nf)), 0, 0, 0, 
  0, 0}, {0, 0, -9/(16*Global`Nc^2*(-2 + Global`Nf)*(-1 + Global`Nf)*
    Global`Nf), -3/(16*Global`Nc^2*(-2 + Global`Nf)*(-1 + Global`Nf)*
    Global`Nf), 0, 0, 9/(8*Global`Nc*(-1 + Global`Nc^2)*(-2 + Global`Nf)*
    (-1 + Global`Nf)*Global`Nf), (3*(1 + Global`Nc*(-2 + Global`Nf^2)))/
   (8*Global`Nc*(-1 + Global`Nc^2)*(-2 + Global`Nf)*(-1 + Global`Nf)*
    Global`Nf), 0, 0, 0, 3/(8*(-1 + Global`Nc^2)*(-1 + Global`Nf)), 0, 0, 0, 
  0, 0, 0, 0, 0, 0, -3/(8*(-1 + Global`Nc^2)*(-1 + Global`Nf)), 0, 0, 0, 0}, 
 {(9*Global`Nf^2)/(32*Global`Nc^2*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 
  (-3*Global`Nf^2)/(32*Global`Nc^2*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 
  0, 0, 0, 0, 0, (3*Global`Nf*(-2 - Global`Nf + 2*Global`Nf^2))/
   (8*Global`Nc^2*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 0, 
  (3*Global`Nf*(-2 - Global`Nf + 2*Global`Nf^2))/
   (16*Global`Nc^3*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 
  (3*Global`Nf*(-2 - Global`Nf + 2*Global`Nf^2))/
   (8*Global`Nc^2*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 
  (-9*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3))/
   (32*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  (3*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3))/
   (32*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  0, 0, 0, 0, 0, 0, 0, 0, (3*Global`Nf)/(2*Global`Nc^3*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), (3*Global`Nf)/(Global`Nc^2*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2))}, {0, 0, 9/(32*Global`Nc^2*(-1 + Global`Nf)), 
  -9/(32*(-2 + Global`Nc)*Global`Nc*(-1 + Global`Nf)), 0, 0, 
  -9/(8*(-2 + Global`Nc)*Global`Nc*(-1 + Global`Nf)), 0, 0, 
  (9*(-1 + 2*Global`Nc)*Global`Nf)/(8*(-2 + Global`Nc)^2*Global`Nc*
    (-1 + Global`Nf)), 0, (-9*Global`Nf)/(4*(-2 + Global`Nc)^2*
    (-1 + Global`Nf)), 0, 0, 0, 0, -9/(32*Global`Nc^2*(-1 + Global`Nf)), 
  9/(32*(-2 + Global`Nc)*Global`Nc*(-1 + Global`Nf)), 0, 0, 
  9/(8*(-2 + Global`Nc)*Global`Nc*(-1 + Global`Nf)), 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, (-9*Global`Nf^2)/(8*(-1 + Global`Nc^2)*(-1 + Global`Nf)*
    (-2 + Global`Nf^2)), (3*Global`Nf^2)/(8*(-1 + Global`Nc^2)*
    (-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 0, 0, 
  (3*Global`Nf*(-2 - Global`Nf + 2*Global`Nf^2))/
   (2*(-1 + Global`Nc^2)*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 
  (9*Global`Nf*(-2 - Global`Nf + 2*Global`Nf^2))/
   (8*Global`Nc^2*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 
  (9*Global`Nf*(2 + Global`Nf - 2*Global`Nf^2))/
   (4*Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 
  0, 0, 0, (9*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3))/
   (8*(-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), (-3*(18 + 2*Global`Nf - 27*Global`Nf^2 + 
     8*Global`Nf^3))/(8*(-1 + Global`Nc^2)*(-1 + Global`Nf)*
    (-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 0, 0, 
  (-3*Global`Nf)/(Global`Nc^2*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  (6*Global`Nf)/(Global`Nc*(-1 + Global`Nc^2)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2))}, 
 {0, 0, 0, 3/(8*(-2 + Global`Nc)*Global`Nc*(-1 + Global`Nf)), 0, 0, 
  (9*Global`Nc)/(8*(-2 + Global`Nc)*(-1 + Global`Nc^2)*(-1 + Global`Nf)), 
  3/(8*(-1 + Global`Nc^2)*(-1 + Global`Nf)), 0, 
  (-9*Global`Nf)/(4*(-2 + Global`Nc)^2*(-1 + Global`Nf)), 0, 
  (3*Global`Nc*(-1 + 2*Global`Nc)*Global`Nf)/(2*(-2 + Global`Nc)^2*
    (-1 + Global`Nc^2)*(-1 + Global`Nf)), 0, 0, 0, 0, 0, 
  -3/(8*(-2 + Global`Nc)*Global`Nc*(-1 + Global`Nf)), 0, 0, 
  (-9*Global`Nc)/(8*(-2 + Global`Nc)*(-1 + Global`Nc^2)*(-1 + Global`Nf)), 
  -3/(8*(-1 + Global`Nc^2)*(-1 + Global`Nf)), 0, 0, 0, 0}, 
 {0, (-3*Global`Nf^2)/(16*Global`Nc^3*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 
  0, 0, (-9*Global`Nf^2)/(8*Global`Nc^2*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 
  0, 0, 0, (3*Global`Nf*(-2 - Global`Nf + 2*Global`Nf^2))/
   (16*Global`Nc^3*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 
  (9*Global`Nf*(-2 - Global`Nf + 2*Global`Nf^2))/
   (8*Global`Nc^2*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 
  (3*(-2 + 3*Global`Nc^2)*Global`Nf*(-2 - Global`Nf + 2*Global`Nf^2))/
   (8*Global`Nc^4*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 
  (3*Global`Nf*(2 + Global`Nf - 2*Global`Nf^2))/
   (2*Global`Nc^3*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 
  (3*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3))/
   (16*Global`Nc^3*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  0, 0, (9*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3))/
   (8*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 0, 
  0, 0, (-9*Global`Nf)/(2*Global`Nc^2*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  0, (-3*(-4 + 3*Global`Nc^2)*Global`Nf)/(4*Global`Nc^4*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), (6*Global`Nf)/(Global`Nc^3*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2))}, 
 {0, (-3*Global`Nf^2)/(8*Global`Nc^2*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 
  0, (9*Global`Nf^2)/(4*Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf)*
    (-2 + Global`Nf^2)), 0, 0, 0, 
  (3*Global`Nf*(-2 - Global`Nf + 2*Global`Nf^2))/
   (8*Global`Nc^2*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 
  (9*Global`Nf*(2 + Global`Nf - 2*Global`Nf^2))/
   (4*Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 
  (3*Global`Nf*(2 + Global`Nf - 2*Global`Nf^2))/
   (2*Global`Nc^3*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 
  (3*(2 + Global`Nc^2)*Global`Nf*(-2 - Global`Nf + 2*Global`Nf^2))/
   (2*Global`Nc^2*(-1 + Global`Nc^2)*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 
  (3*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3))/
   (8*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 0, 
  0, (-9*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3))/
   (4*Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), 0, 0, 0, 0, (-18*Global`Nf)/
   ((-1 + Global`Nc^2)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  (6*Global`Nf)/(Global`Nc^3*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  (3*(-4 + Global`Nc^2)*Global`Nf)/(Global`Nc^2*(-1 + Global`Nc^2)*
    (-9 + 8*Global`Nf)*(-2 + Global`Nf^2))}, 
 {(-9*(18 - 34*Global`Nf - 9*Global`Nf^2 + 8*Global`Nf^3))/
   (32*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  0, 0, 0, 0, 0, 0, 0, (-9*(18 + 2*Global`Nf - 27*Global`Nf^2 + 
     8*Global`Nf^3))/(32*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), 0, 0, 0, 0, 0, 
  (9*(-162 + 288*Global`Nf - 209*Global`Nf^2 + 18*Global`Nf^3 + 
     64*Global`Nf^4))/(32*Global`Nc^2*(9 - 8*Global`Nf)^2*(-1 + Global`Nf)*
    (-2 + Global`Nf^2)), 0, 0, 0, 0, 0, 0, 0, 
  (81*Global`Nf^2)/(4*Global`Nc^3*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 
  (81*Global`Nf^2)/(2*Global`Nc^2*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 
  (81*Global`Nf^2)/(8*Global`Nc^3*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 
  (81*Global`Nf^2)/(4*Global`Nc^2*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2))}, 
 {0, (-3*(18 - 34*Global`Nf - 9*Global`Nf^2 + 8*Global`Nf^3))/
   (32*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  0, 0, 0, 0, 0, 0, (3*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3))/
   (32*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  0, 0, 0, (3*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3))/
   (16*Global`Nc^3*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  (3*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3))/
   (8*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 0, 
  (3*(-162 + 288*Global`Nf - 209*Global`Nf^2 + 18*Global`Nf^3 + 
     64*Global`Nf^4))/(32*Global`Nc^2*(9 - 8*Global`Nf)^2*(-1 + Global`Nf)*
    (-2 + Global`Nf^2)), 0, 0, 0, 0, 0, 0, 
  (81*Global`Nf^2)/(4*Global`Nc^3*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 
  (81*Global`Nf^2)/(2*Global`Nc^2*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 
  (-27*Global`Nf^2)/(8*Global`Nc^3*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 
  (-27*Global`Nf^2)/(4*Global`Nc^2*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2))}, 
 {0, 0, -9/(32*Global`Nc^2*(-1 + Global`Nf)), 0, 0, 0, 0, 0, 0, 
  -9/(32*Global`Nc^2*(-1 + Global`Nf)), 0, 0, 0, 0, 0, 0, 
  9/(32*Global`Nc^2*(-1 + Global`Nf)), 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, -3/(32*Global`Nc^2*(-1 + Global`Nf)), 0, 0, 0, 0, 0, 
  9/(32*(-2 + Global`Nc)*Global`Nc*(-1 + Global`Nf)), 0, 
  -3/(8*(-2 + Global`Nc)*Global`Nc*(-1 + Global`Nf)), 0, 0, 0, 0, 0, 
  3/(32*Global`Nc^2*(-1 + Global`Nf)), 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, (-9*(18 - 34*Global`Nf - 9*Global`Nf^2 + 8*Global`Nf^3))/
   (8*(-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), 0, 0, 0, 0, 0, 
  (9*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3))/
   (8*(-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), 0, 
  (9*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3))/
   (8*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  (-9*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3))/
   (4*Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), 0, 0, 0, 0, 
  (9*(-162 + 288*Global`Nf - 209*Global`Nf^2 + 18*Global`Nf^3 + 
     64*Global`Nf^4))/(8*(-1 + Global`Nc^2)*(9 - 8*Global`Nf)^2*
    (-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 0, 
  (81*Global`Nf^2)/(2*Global`Nc^2*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 
  (-81*Global`Nf^2)/(Global`Nc*(-1 + Global`Nc^2)*(9 - 8*Global`Nf)^2*
    (-2 + Global`Nf^2)), (81*Global`Nf^2)/(4*Global`Nc^2*(9 - 8*Global`Nf)^2*
    (-2 + Global`Nf^2)), (-81*Global`Nf^2)/(2*Global`Nc*(-1 + Global`Nc^2)*
    (9 - 8*Global`Nf)^2*(-2 + Global`Nf^2))}, 
 {0, 0, 0, 0, 0, (-3*(18 - 34*Global`Nf - 9*Global`Nf^2 + 8*Global`Nf^3))/
   (8*(-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), 0, 0, 0, 0, 
  (-3*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3))/
   (8*(-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), 0, 0, 0, 0, 0, 0, 0, 0, 
  (3*(-162 + 288*Global`Nf - 209*Global`Nf^2 + 18*Global`Nf^3 + 
     64*Global`Nf^4))/(8*(-1 + Global`Nc^2)*(9 - 8*Global`Nf)^2*
    (-1 + Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 
  (81*Global`Nf^2)/(2*Global`Nc^2*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 
  (-81*Global`Nf^2)/(Global`Nc*(-1 + Global`Nc^2)*(9 - 8*Global`Nf)^2*
    (-2 + Global`Nf^2)), (-27*Global`Nf^2)/(4*Global`Nc^2*(9 - 8*Global`Nf)^2*
    (-2 + Global`Nf^2)), (27*Global`Nf^2)/(2*Global`Nc*(-1 + Global`Nc^2)*
    (9 - 8*Global`Nf)^2*(-2 + Global`Nf^2))}, 
 {0, 0, 0, 0, 0, 0, -9/(8*(-1 + Global`Nc^2)*(-1 + Global`Nf)), 0, 0, 
  9/(8*(-2 + Global`Nc)*Global`Nc*(-1 + Global`Nf)), 0, 
  (-9*Global`Nc)/(8*(-2 + Global`Nc)*(-1 + Global`Nc^2)*(-1 + Global`Nf)), 0, 
  0, 0, 0, 0, 0, 0, 0, 9/(8*(-1 + Global`Nc^2)*(-1 + Global`Nf)), 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, -3/(8*(-1 + Global`Nc^2)*(-1 + Global`Nf)), 0, 0, 
  0, -3/(8*(-1 + Global`Nc^2)*(-1 + Global`Nf)), 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  3/(8*(-1 + Global`Nc^2)*(-1 + Global`Nf)), 0, 0, 0, 0}, 
 {(9*Global`Nf)/(4*Global`Nc^3*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), (9*Global`Nf)/(4*Global`Nc^3*(-1 + Global`Nf)*
    (-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 
  (9*Global`Nf)/(2*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), (9*Global`Nf)/(2*Global`Nc^2*(-1 + Global`Nf)*
    (-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 0, 0, 0, 0, 
  (-9*Global`Nf)/(2*Global`Nc^2*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 0, 
  (81*Global`Nf^2)/(4*Global`Nc^3*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 
  (81*Global`Nf^2)/(4*Global`Nc^3*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 0, 
  0, (81*Global`Nf^2)/(2*Global`Nc^2*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 
  (81*Global`Nf^2)/(2*Global`Nc^2*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 0, 
  0, (36*Global`Nf^2)/(Global`Nc^2*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 
  0, 0, 0}, {(9*Global`Nf)/(2*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), (9*Global`Nf)/(2*Global`Nc^2*(-1 + Global`Nf)*
    (-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 
  (-9*Global`Nf)/(Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf)*
    (-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  (-9*Global`Nf)/(Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf)*
    (-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 0, 0, 0, 0, 0, 
  (-18*Global`Nf)/((-1 + Global`Nc^2)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  (81*Global`Nf^2)/(2*Global`Nc^2*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 
  (81*Global`Nf^2)/(2*Global`Nc^2*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 0, 
  0, (-81*Global`Nf^2)/(Global`Nc*(-1 + Global`Nc^2)*(9 - 8*Global`Nf)^2*
    (-2 + Global`Nf^2)), (-81*Global`Nf^2)/(Global`Nc*(-1 + Global`Nc^2)*
    (9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 0, 0, 0, 
  (144*Global`Nf^2)/((-1 + Global`Nc^2)*(9 - 8*Global`Nf)^2*
    (-2 + Global`Nf^2)), 0, 0}, 
 {(9*Global`Nf)/(8*Global`Nc^3*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), (-3*Global`Nf)/(8*Global`Nc^3*(-1 + Global`Nf)*
    (-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 
  (9*Global`Nf)/(4*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), (-3*Global`Nf)/(4*Global`Nc^2*(-1 + Global`Nf)*
    (-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 
  (3*Global`Nf)/(2*Global`Nc^3*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 0, 
  (-3*Global`Nf)/(Global`Nc^2*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 0, 
  (-3*(-4 + 3*Global`Nc^2)*Global`Nf)/(4*Global`Nc^4*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), (6*Global`Nf)/(Global`Nc^3*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), (81*Global`Nf^2)/(8*Global`Nc^3*(9 - 8*Global`Nf)^2*
    (-2 + Global`Nf^2)), (-27*Global`Nf^2)/(8*Global`Nc^3*(9 - 8*Global`Nf)^2*
    (-2 + Global`Nf^2)), 0, 0, (81*Global`Nf^2)/
   (4*Global`Nc^2*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 
  (-27*Global`Nf^2)/(4*Global`Nc^2*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 
  0, 0, 0, 0, (3*Global`Nf^2)/(Global`Nc^2*(9 - 8*Global`Nf)^2*
    (-2 + Global`Nf^2)), 0}, 
 {(9*Global`Nf)/(4*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), (-3*Global`Nf)/(4*Global`Nc^2*(-1 + Global`Nf)*
    (-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 
  (-9*Global`Nf)/(2*Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf)*
    (-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  (3*Global`Nf)/(2*Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf)*
    (-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 0, 0, 
  (3*Global`Nf)/(Global`Nc^2*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 0, 
  (6*Global`Nf)/(Global`Nc*(-1 + Global`Nc^2)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), 0, (6*Global`Nf)/(Global`Nc^3*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), (3*(-4 + Global`Nc^2)*Global`Nf)/
   (Global`Nc^2*(-1 + Global`Nc^2)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
  (81*Global`Nf^2)/(4*Global`Nc^2*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 
  (-27*Global`Nf^2)/(4*Global`Nc^2*(9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 
  0, 0, (-81*Global`Nf^2)/(2*Global`Nc*(-1 + Global`Nc^2)*(9 - 8*Global`Nf)^2*
    (-2 + Global`Nf^2)), (27*Global`Nf^2)/(2*Global`Nc*(-1 + Global`Nc^2)*
    (9 - 8*Global`Nf)^2*(-2 + Global`Nf^2)), 0, 0, 0, 0, 0, 
  (12*Global`Nf^2)/((-1 + Global`Nc^2)*(9 - 8*Global`Nf)^2*
    (-2 + Global`Nf^2))}}
