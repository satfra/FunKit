(* Created with the Wolfram Language : www.wolfram.com *)
{(TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`color, Global`A3, Global`A4]*
   (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
    TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
    TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
      Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
     TBgamma[0, Global`d3, Global`d4] - TBgamma[0, Global`d1, Global`dc$8961]*
     TBgamma[0, Global`d3, Global`dc$8962]*TBgamma5[Global`dc$8961, 
      Global`d2]*TBgamma5[Global`dc$8962, Global`d4]))/6, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`color, Global`A3, Global`A4]*
   (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
    TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
    TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
      Global`F4, 3])*
   ((-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`d2]) + 
      TBgamma[Global`i, Global`d1, Global`d2])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`d4]) + 
      TBgamma[Global`i, Global`d3, Global`d4]) - 
    (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`dc$8963]) + 
      TBgamma[Global`i, Global`d1, Global`dc$8963])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`dc$8964]) + 
      TBgamma[Global`i, Global`d3, Global`dc$8964])*
     TBgamma5[Global`dc$8963, Global`d2]*TBgamma5[Global`dc$8964, 
      Global`d4]))/6, (TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`color, Global`A3, Global`A4]*
   (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
    TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
    TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
      Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
     TBgamma[0, Global`d3, Global`d4] + TBgamma[0, Global`d1, Global`dc$8965]*
     TBgamma[0, Global`d3, Global`dc$8966]*TBgamma5[Global`dc$8965, 
      Global`d2]*TBgamma5[Global`dc$8966, Global`d4]))/6, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`color, Global`A3, Global`A4]*
   (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
    TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
    TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
      Global`F4, 3])*
   ((-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`d2]) + 
      TBgamma[Global`i, Global`d1, Global`d2])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`d4]) + 
      TBgamma[Global`i, Global`d3, Global`d4]) + 
    (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`dc$8967]) + 
      TBgamma[Global`i, Global`d1, Global`dc$8967])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`dc$8968]) + 
      TBgamma[Global`i, Global`d3, Global`dc$8968])*
     TBgamma5[Global`dc$8967, Global`d2]*TBgamma5[Global`dc$8968, 
      Global`d4]))/6, ((TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
    TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
    TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
      Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
     TBgamma[0, Global`d3, Global`d4] - TBgamma[0, Global`d1, Global`dc$8969]*
     TBgamma[0, Global`d3, Global`dc$8970]*TBgamma5[Global`dc$8969, 
      Global`d2]*TBgamma5[Global`dc$8970, Global`d4])*
   TBT[Global`color, Global`a, Global`A1, Global`A2]*
   TBT[Global`color, Global`a, Global`A3, Global`A4])/6, 
 ((TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
    TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
    TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
      Global`F4, 3])*
   ((-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`d2]) + 
      TBgamma[Global`i, Global`d1, Global`d2])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`d4]) + 
      TBgamma[Global`i, Global`d3, Global`d4]) - 
    (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`dc$8971]) + 
      TBgamma[Global`i, Global`d1, Global`dc$8971])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`dc$8972]) + 
      TBgamma[Global`i, Global`d3, Global`dc$8972])*
     TBgamma5[Global`dc$8971, Global`d2]*TBgamma5[Global`dc$8972, Global`d4])*
   TBT[Global`color, Global`a, Global`A1, Global`A2]*
   TBT[Global`color, Global`a, Global`A3, Global`A4])/6, 
 ((TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
    TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
    TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
      Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
     TBgamma[0, Global`d3, Global`d4] + TBgamma[0, Global`d1, Global`dc$8973]*
     TBgamma[0, Global`d3, Global`dc$8974]*TBgamma5[Global`dc$8973, 
      Global`d2]*TBgamma5[Global`dc$8974, Global`d4])*
   TBT[Global`color, Global`a, Global`A1, Global`A2]*
   TBT[Global`color, Global`a, Global`A3, Global`A4])/6, 
 ((TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
    TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
    TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
      Global`F4, 3])*
   ((-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`d2]) + 
      TBgamma[Global`i, Global`d1, Global`d2])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`d4]) + 
      TBgamma[Global`i, Global`d3, Global`d4]) + 
    (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`dc$8975]) + 
      TBgamma[Global`i, Global`d1, Global`dc$8975])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`dc$8976]) + 
      TBgamma[Global`i, Global`d3, Global`dc$8976])*
     TBgamma5[Global`dc$8975, Global`d2]*TBgamma5[Global`dc$8976, Global`d4])*
   TBT[Global`color, Global`a, Global`A1, Global`A2]*
   TBT[Global`color, Global`a, Global`A3, Global`A4])/6, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`color, Global`A3, Global`A4]*
   TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
    Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
   TBdeltaFund[Global`flavor, Global`F4, 3]*
   (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
    TBgamma[0, Global`d1, Global`dc$8977]*TBgamma[0, Global`d3, 
      Global`dc$8978]*TBgamma5[Global`dc$8977, Global`d2]*
     TBgamma5[Global`dc$8978, Global`d4]))/6, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`color, Global`A3, Global`A4]*
   TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
    Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
   TBdeltaFund[Global`flavor, Global`F4, 3]*
   (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
    TBgamma[0, Global`d1, Global`dc$8979]*TBgamma[0, Global`d3, 
      Global`dc$8980]*TBgamma5[Global`dc$8979, Global`d2]*
     TBgamma5[Global`dc$8980, Global`d4]))/6, 
 (TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
    Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
   TBdeltaFund[Global`flavor, Global`F4, 3]*
   ((-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`d2]) + 
      TBgamma[Global`i, Global`d1, Global`d2])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`d4]) + 
      TBgamma[Global`i, Global`d3, Global`d4]) - 
    (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`dc$8981]) + 
      TBgamma[Global`i, Global`d1, Global`dc$8981])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`dc$8982]) + 
      TBgamma[Global`i, Global`d3, Global`dc$8982])*
     TBgamma5[Global`dc$8981, Global`d2]*TBgamma5[Global`dc$8982, Global`d4])*
   TBT[Global`color, Global`a, Global`A1, Global`A2]*
   TBT[Global`color, Global`a, Global`A3, Global`A4])/6, 
 (TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
    Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
   TBdeltaFund[Global`flavor, Global`F4, 3]*
   ((-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`d2]) + 
      TBgamma[Global`i, Global`d1, Global`d2])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`d4]) + 
      TBgamma[Global`i, Global`d3, Global`d4]) + 
    (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`dc$8983]) + 
      TBgamma[Global`i, Global`d1, Global`dc$8983])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`dc$8984]) + 
      TBgamma[Global`i, Global`d3, Global`dc$8984])*
     TBgamma5[Global`dc$8983, Global`d2]*TBgamma5[Global`dc$8984, Global`d4])*
   TBT[Global`color, Global`a, Global`A1, Global`A2]*
   TBT[Global`color, Global`a, Global`A3, Global`A4])/6, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`color, Global`A3, Global`A4]*
   TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
    Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
   TBdeltaFund[Global`flavor, Global`F4, 3]*
   (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
    TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]))/6, 
 (TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
    Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
   TBdeltaFund[Global`flavor, Global`F4, 3]*
   (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
    TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
   TBT[Global`color, Global`a, Global`A1, Global`A2]*
   TBT[Global`color, Global`a, Global`A3, Global`A4])/6, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`color, Global`A3, Global`A4]*
   TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
   TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
   (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
    TBgamma[0, Global`d1, Global`dc$8985]*TBgamma[0, Global`d3, 
      Global`dc$8986]*TBgamma5[Global`dc$8985, Global`d2]*
     TBgamma5[Global`dc$8986, Global`d4]))/6, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`color, Global`A3, Global`A4]*
   TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
   TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
   ((-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`d2]) + 
      TBgamma[Global`i, Global`d1, Global`d2])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`d4]) + 
      TBgamma[Global`i, Global`d3, Global`d4]) - 
    (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`dc$8987]) + 
      TBgamma[Global`i, Global`d1, Global`dc$8987])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`dc$8988]) + 
      TBgamma[Global`i, Global`d3, Global`dc$8988])*
     TBgamma5[Global`dc$8987, Global`d2]*TBgamma5[Global`dc$8988, 
      Global`d4]))/6, (TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`color, Global`A3, Global`A4]*
   TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
   TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
   (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
    TBgamma[0, Global`d1, Global`dc$8989]*TBgamma[0, Global`d3, 
      Global`dc$8990]*TBgamma5[Global`dc$8989, Global`d2]*
     TBgamma5[Global`dc$8990, Global`d4]))/6, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`color, Global`A3, Global`A4]*
   TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
   TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
   ((-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`d2]) + 
      TBgamma[Global`i, Global`d1, Global`d2])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`d4]) + 
      TBgamma[Global`i, Global`d3, Global`d4]) + 
    (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`dc$8991]) + 
      TBgamma[Global`i, Global`d1, Global`dc$8991])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`dc$8992]) + 
      TBgamma[Global`i, Global`d3, Global`dc$8992])*
     TBgamma5[Global`dc$8991, Global`d2]*TBgamma5[Global`dc$8992, 
      Global`d4]))/6, (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
   TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
   (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
    TBgamma[0, Global`d1, Global`dc$8993]*TBgamma[0, Global`d3, 
      Global`dc$8994]*TBgamma5[Global`dc$8993, Global`d2]*
     TBgamma5[Global`dc$8994, Global`d4])*TBT[Global`color, Global`a, 
    Global`A1, Global`A2]*TBT[Global`color, Global`a, Global`A3, Global`A4])/
  6, (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
   TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
   ((-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`d2]) + 
      TBgamma[Global`i, Global`d1, Global`d2])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`d4]) + 
      TBgamma[Global`i, Global`d3, Global`d4]) - 
    (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`dc$8995]) + 
      TBgamma[Global`i, Global`d1, Global`dc$8995])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`dc$8996]) + 
      TBgamma[Global`i, Global`d3, Global`dc$8996])*
     TBgamma5[Global`dc$8995, Global`d2]*TBgamma5[Global`dc$8996, Global`d4])*
   TBT[Global`color, Global`a, Global`A1, Global`A2]*
   TBT[Global`color, Global`a, Global`A3, Global`A4])/6, 
 (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
   TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
   (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
    TBgamma[0, Global`d1, Global`dc$8997]*TBgamma[0, Global`d3, 
      Global`dc$8998]*TBgamma5[Global`dc$8997, Global`d2]*
     TBgamma5[Global`dc$8998, Global`d4])*TBT[Global`color, Global`a, 
    Global`A1, Global`A2]*TBT[Global`color, Global`a, Global`A3, Global`A4])/
  6, (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
   TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
   ((-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`d2]) + 
      TBgamma[Global`i, Global`d1, Global`d2])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`d4]) + 
      TBgamma[Global`i, Global`d3, Global`d4]) + 
    (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d1, Global`dc$8999]) + 
      TBgamma[Global`i, Global`d1, Global`dc$8999])*
     (-(TBdeltaLorentz[Global`i, 0]*TBgamma[0, Global`d3, Global`dc$9000]) + 
      TBgamma[Global`i, Global`d3, Global`dc$9000])*
     TBgamma5[Global`dc$8999, Global`d2]*TBgamma5[Global`dc$9000, Global`d4])*
   TBT[Global`color, Global`a, Global`A1, Global`A2]*
   TBT[Global`color, Global`a, Global`A3, Global`A4])/6, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`color, Global`A3, Global`A4]*
   (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
    TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
   (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
    9*TBT[Global`flavor, Global`f, Global`F1, Global`F2]*
     TBT[Global`flavor, Global`f, Global`F3, Global`F4]))/24, 
 ((TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
    TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
   TBT[Global`color, Global`a, Global`A1, Global`A2]*
   TBT[Global`color, Global`a, Global`A3, Global`A4]*
   (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
    9*TBT[Global`flavor, Global`f, Global`F1, Global`F2]*
     TBT[Global`flavor, Global`f, Global`F3, Global`F4]))/24, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`color, Global`A3, Global`A4]*
   (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (2*(TBgamma[0, Global`d1, Global`a$9001]*TBgamma[1, Global`a$9001, 
          Global`d2] - TBgamma[0, Global`a$9002, Global`d2]*
         TBgamma[1, Global`d1, Global`a$9002])*
       (TBgamma[0, Global`d3, Global`a$9003]*TBgamma[1, Global`a$9003, 
          Global`d4] - TBgamma[0, Global`a$9004, Global`d4]*
         TBgamma[1, Global`d3, Global`a$9004]) - 
      (TBgamma[1, Global`a$9013, Global`d2]*TBgamma[1, Global`d1, 
          Global`a$9013] - TBgamma[1, Global`a$9014, Global`d2]*
         TBgamma[1, Global`d1, Global`a$9014])*
       (TBgamma[1, Global`a$9015, Global`d4]*TBgamma[1, Global`d3, 
          Global`a$9015] - TBgamma[1, Global`a$9016, Global`d4]*
         TBgamma[1, Global`d3, Global`a$9016]) + 
      2*(TBgamma[0, Global`d1, Global`a$9005]*TBgamma[2, Global`a$9005, 
          Global`d2] - TBgamma[0, Global`a$9006, Global`d2]*
         TBgamma[2, Global`d1, Global`a$9006])*
       (TBgamma[0, Global`d3, Global`a$9007]*TBgamma[2, Global`a$9007, 
          Global`d4] - TBgamma[0, Global`a$9008, Global`d4]*
         TBgamma[2, Global`d3, Global`a$9008]) - 
      (TBgamma[1, Global`d1, Global`a$9017]*TBgamma[2, Global`a$9017, 
          Global`d2] - TBgamma[1, Global`a$9018, Global`d2]*
         TBgamma[2, Global`d1, Global`a$9018])*
       (TBgamma[1, Global`d3, Global`a$9019]*TBgamma[2, Global`a$9019, 
          Global`d4] - TBgamma[1, Global`a$9020, Global`d4]*
         TBgamma[2, Global`d3, Global`a$9020]) - 
      (TBgamma[1, Global`d1, Global`a$9026]*TBgamma[2, Global`a$9026, 
          Global`d2] - TBgamma[1, Global`a$9025, Global`d2]*
         TBgamma[2, Global`d1, Global`a$9025])*
       (TBgamma[1, Global`d3, Global`a$9028]*TBgamma[2, Global`a$9028, 
          Global`d4] - TBgamma[1, Global`a$9027, Global`d4]*
         TBgamma[2, Global`d3, Global`a$9027]) - 
      (TBgamma[2, Global`a$9029, Global`d2]*TBgamma[2, Global`d1, 
          Global`a$9029] - TBgamma[2, Global`a$9030, Global`d2]*
         TBgamma[2, Global`d1, Global`a$9030])*
       (TBgamma[2, Global`a$9031, Global`d4]*TBgamma[2, Global`d3, 
          Global`a$9031] - TBgamma[2, Global`a$9032, Global`d4]*
         TBgamma[2, Global`d3, Global`a$9032]) + 
      2*(TBgamma[0, Global`d1, Global`a$9009]*TBgamma[3, Global`a$9009, 
          Global`d2] - TBgamma[0, Global`a$9010, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9010])*
       (TBgamma[0, Global`d3, Global`a$9011]*TBgamma[3, Global`a$9011, 
          Global`d4] - TBgamma[0, Global`a$9012, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9012]) - 
      (TBgamma[1, Global`d1, Global`a$9021]*TBgamma[3, Global`a$9021, 
          Global`d2] - TBgamma[1, Global`a$9022, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9022])*
       (TBgamma[1, Global`d3, Global`a$9023]*TBgamma[3, Global`a$9023, 
          Global`d4] - TBgamma[1, Global`a$9024, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9024]) - 
      (TBgamma[2, Global`d1, Global`a$9033]*TBgamma[3, Global`a$9033, 
          Global`d2] - TBgamma[2, Global`a$9034, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9034])*
       (TBgamma[2, Global`d3, Global`a$9035]*TBgamma[3, Global`a$9035, 
          Global`d4] - TBgamma[2, Global`a$9036, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9036]) - 
      (TBgamma[1, Global`d1, Global`a$9038]*TBgamma[3, Global`a$9038, 
          Global`d2] - TBgamma[1, Global`a$9037, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9037])*
       (TBgamma[1, Global`d3, Global`a$9040]*TBgamma[3, Global`a$9040, 
          Global`d4] - TBgamma[1, Global`a$9039, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9039]) - 
      (TBgamma[2, Global`d1, Global`a$9042]*TBgamma[3, Global`a$9042, 
          Global`d2] - TBgamma[2, Global`a$9041, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9041])*
       (TBgamma[2, Global`d3, Global`a$9044]*TBgamma[3, Global`a$9044, 
          Global`d4] - TBgamma[2, Global`a$9043, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9043]) - 
      (TBgamma[3, Global`a$9045, Global`d2]*TBgamma[3, Global`d1, 
          Global`a$9045] - TBgamma[3, Global`a$9046, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9046])*
       (TBgamma[3, Global`a$9047, Global`d4]*TBgamma[3, Global`d3, 
          Global`a$9047] - TBgamma[3, Global`a$9048, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9048])) + 
    9*(2*(TBgamma[0, Global`d1, Global`a$9049]*TBgamma[1, Global`a$9049, 
          Global`d2] - TBgamma[0, Global`a$9050, Global`d2]*
         TBgamma[1, Global`d1, Global`a$9050])*
       (TBgamma[0, Global`d3, Global`a$9051]*TBgamma[1, Global`a$9051, 
          Global`d4] - TBgamma[0, Global`a$9052, Global`d4]*
         TBgamma[1, Global`d3, Global`a$9052]) - 
      (TBgamma[1, Global`a$9061, Global`d2]*TBgamma[1, Global`d1, 
          Global`a$9061] - TBgamma[1, Global`a$9062, Global`d2]*
         TBgamma[1, Global`d1, Global`a$9062])*
       (TBgamma[1, Global`a$9063, Global`d4]*TBgamma[1, Global`d3, 
          Global`a$9063] - TBgamma[1, Global`a$9064, Global`d4]*
         TBgamma[1, Global`d3, Global`a$9064]) + 
      2*(TBgamma[0, Global`d1, Global`a$9053]*TBgamma[2, Global`a$9053, 
          Global`d2] - TBgamma[0, Global`a$9054, Global`d2]*
         TBgamma[2, Global`d1, Global`a$9054])*
       (TBgamma[0, Global`d3, Global`a$9055]*TBgamma[2, Global`a$9055, 
          Global`d4] - TBgamma[0, Global`a$9056, Global`d4]*
         TBgamma[2, Global`d3, Global`a$9056]) - 
      (TBgamma[1, Global`d1, Global`a$9065]*TBgamma[2, Global`a$9065, 
          Global`d2] - TBgamma[1, Global`a$9066, Global`d2]*
         TBgamma[2, Global`d1, Global`a$9066])*
       (TBgamma[1, Global`d3, Global`a$9067]*TBgamma[2, Global`a$9067, 
          Global`d4] - TBgamma[1, Global`a$9068, Global`d4]*
         TBgamma[2, Global`d3, Global`a$9068]) - 
      (TBgamma[1, Global`d1, Global`a$9074]*TBgamma[2, Global`a$9074, 
          Global`d2] - TBgamma[1, Global`a$9073, Global`d2]*
         TBgamma[2, Global`d1, Global`a$9073])*
       (TBgamma[1, Global`d3, Global`a$9076]*TBgamma[2, Global`a$9076, 
          Global`d4] - TBgamma[1, Global`a$9075, Global`d4]*
         TBgamma[2, Global`d3, Global`a$9075]) - 
      (TBgamma[2, Global`a$9077, Global`d2]*TBgamma[2, Global`d1, 
          Global`a$9077] - TBgamma[2, Global`a$9078, Global`d2]*
         TBgamma[2, Global`d1, Global`a$9078])*
       (TBgamma[2, Global`a$9079, Global`d4]*TBgamma[2, Global`d3, 
          Global`a$9079] - TBgamma[2, Global`a$9080, Global`d4]*
         TBgamma[2, Global`d3, Global`a$9080]) + 
      2*(TBgamma[0, Global`d1, Global`a$9057]*TBgamma[3, Global`a$9057, 
          Global`d2] - TBgamma[0, Global`a$9058, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9058])*
       (TBgamma[0, Global`d3, Global`a$9059]*TBgamma[3, Global`a$9059, 
          Global`d4] - TBgamma[0, Global`a$9060, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9060]) - 
      (TBgamma[1, Global`d1, Global`a$9069]*TBgamma[3, Global`a$9069, 
          Global`d2] - TBgamma[1, Global`a$9070, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9070])*
       (TBgamma[1, Global`d3, Global`a$9071]*TBgamma[3, Global`a$9071, 
          Global`d4] - TBgamma[1, Global`a$9072, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9072]) - 
      (TBgamma[2, Global`d1, Global`a$9081]*TBgamma[3, Global`a$9081, 
          Global`d2] - TBgamma[2, Global`a$9082, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9082])*
       (TBgamma[2, Global`d3, Global`a$9083]*TBgamma[3, Global`a$9083, 
          Global`d4] - TBgamma[2, Global`a$9084, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9084]) - 
      (TBgamma[1, Global`d1, Global`a$9086]*TBgamma[3, Global`a$9086, 
          Global`d2] - TBgamma[1, Global`a$9085, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9085])*
       (TBgamma[1, Global`d3, Global`a$9088]*TBgamma[3, Global`a$9088, 
          Global`d4] - TBgamma[1, Global`a$9087, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9087]) - 
      (TBgamma[2, Global`d1, Global`a$9090]*TBgamma[3, Global`a$9090, 
          Global`d2] - TBgamma[2, Global`a$9089, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9089])*
       (TBgamma[2, Global`d3, Global`a$9092]*TBgamma[3, Global`a$9092, 
          Global`d4] - TBgamma[2, Global`a$9091, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9091]) - 
      (TBgamma[3, Global`a$9093, Global`d2]*TBgamma[3, Global`d1, 
          Global`a$9093] - TBgamma[3, Global`a$9094, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9094])*
       (TBgamma[3, Global`a$9095, Global`d4]*TBgamma[3, Global`d3, 
          Global`a$9095] - TBgamma[3, Global`a$9096, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9096]))*TBT[Global`flavor, Global`af, 
      Global`F1, Global`F2]*TBT[Global`flavor, Global`af, Global`F3, 
      Global`F4]))/96, (TBT[Global`color, Global`ac, Global`A1, Global`A2]*
   TBT[Global`color, Global`ac, Global`A3, Global`A4]*
   (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (2*(TBgamma[0, Global`d1, Global`a$9097]*TBgamma[1, Global`a$9097, 
          Global`d2] - TBgamma[0, Global`a$9098, Global`d2]*
         TBgamma[1, Global`d1, Global`a$9098])*
       (TBgamma[0, Global`d3, Global`a$9099]*TBgamma[1, Global`a$9099, 
          Global`d4] - TBgamma[0, Global`a$9100, Global`d4]*
         TBgamma[1, Global`d3, Global`a$9100]) - 
      (TBgamma[1, Global`a$9109, Global`d2]*TBgamma[1, Global`d1, 
          Global`a$9109] - TBgamma[1, Global`a$9110, Global`d2]*
         TBgamma[1, Global`d1, Global`a$9110])*
       (TBgamma[1, Global`a$9111, Global`d4]*TBgamma[1, Global`d3, 
          Global`a$9111] - TBgamma[1, Global`a$9112, Global`d4]*
         TBgamma[1, Global`d3, Global`a$9112]) + 
      2*(TBgamma[0, Global`d1, Global`a$9101]*TBgamma[2, Global`a$9101, 
          Global`d2] - TBgamma[0, Global`a$9102, Global`d2]*
         TBgamma[2, Global`d1, Global`a$9102])*
       (TBgamma[0, Global`d3, Global`a$9103]*TBgamma[2, Global`a$9103, 
          Global`d4] - TBgamma[0, Global`a$9104, Global`d4]*
         TBgamma[2, Global`d3, Global`a$9104]) - 
      (TBgamma[1, Global`d1, Global`a$9113]*TBgamma[2, Global`a$9113, 
          Global`d2] - TBgamma[1, Global`a$9114, Global`d2]*
         TBgamma[2, Global`d1, Global`a$9114])*
       (TBgamma[1, Global`d3, Global`a$9115]*TBgamma[2, Global`a$9115, 
          Global`d4] - TBgamma[1, Global`a$9116, Global`d4]*
         TBgamma[2, Global`d3, Global`a$9116]) - 
      (TBgamma[1, Global`d1, Global`a$9122]*TBgamma[2, Global`a$9122, 
          Global`d2] - TBgamma[1, Global`a$9121, Global`d2]*
         TBgamma[2, Global`d1, Global`a$9121])*
       (TBgamma[1, Global`d3, Global`a$9124]*TBgamma[2, Global`a$9124, 
          Global`d4] - TBgamma[1, Global`a$9123, Global`d4]*
         TBgamma[2, Global`d3, Global`a$9123]) - 
      (TBgamma[2, Global`a$9125, Global`d2]*TBgamma[2, Global`d1, 
          Global`a$9125] - TBgamma[2, Global`a$9126, Global`d2]*
         TBgamma[2, Global`d1, Global`a$9126])*
       (TBgamma[2, Global`a$9127, Global`d4]*TBgamma[2, Global`d3, 
          Global`a$9127] - TBgamma[2, Global`a$9128, Global`d4]*
         TBgamma[2, Global`d3, Global`a$9128]) + 
      2*(TBgamma[0, Global`d1, Global`a$9105]*TBgamma[3, Global`a$9105, 
          Global`d2] - TBgamma[0, Global`a$9106, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9106])*
       (TBgamma[0, Global`d3, Global`a$9107]*TBgamma[3, Global`a$9107, 
          Global`d4] - TBgamma[0, Global`a$9108, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9108]) - 
      (TBgamma[1, Global`d1, Global`a$9117]*TBgamma[3, Global`a$9117, 
          Global`d2] - TBgamma[1, Global`a$9118, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9118])*
       (TBgamma[1, Global`d3, Global`a$9119]*TBgamma[3, Global`a$9119, 
          Global`d4] - TBgamma[1, Global`a$9120, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9120]) - 
      (TBgamma[2, Global`d1, Global`a$9129]*TBgamma[3, Global`a$9129, 
          Global`d2] - TBgamma[2, Global`a$9130, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9130])*
       (TBgamma[2, Global`d3, Global`a$9131]*TBgamma[3, Global`a$9131, 
          Global`d4] - TBgamma[2, Global`a$9132, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9132]) - 
      (TBgamma[1, Global`d1, Global`a$9134]*TBgamma[3, Global`a$9134, 
          Global`d2] - TBgamma[1, Global`a$9133, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9133])*
       (TBgamma[1, Global`d3, Global`a$9136]*TBgamma[3, Global`a$9136, 
          Global`d4] - TBgamma[1, Global`a$9135, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9135]) - 
      (TBgamma[2, Global`d1, Global`a$9138]*TBgamma[3, Global`a$9138, 
          Global`d2] - TBgamma[2, Global`a$9137, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9137])*
       (TBgamma[2, Global`d3, Global`a$9140]*TBgamma[3, Global`a$9140, 
          Global`d4] - TBgamma[2, Global`a$9139, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9139]) - 
      (TBgamma[3, Global`a$9141, Global`d2]*TBgamma[3, Global`d1, 
          Global`a$9141] - TBgamma[3, Global`a$9142, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9142])*
       (TBgamma[3, Global`a$9143, Global`d4]*TBgamma[3, Global`d3, 
          Global`a$9143] - TBgamma[3, Global`a$9144, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9144])) + 
    9*(2*(TBgamma[0, Global`d1, Global`a$9145]*TBgamma[1, Global`a$9145, 
          Global`d2] - TBgamma[0, Global`a$9146, Global`d2]*
         TBgamma[1, Global`d1, Global`a$9146])*
       (TBgamma[0, Global`d3, Global`a$9147]*TBgamma[1, Global`a$9147, 
          Global`d4] - TBgamma[0, Global`a$9148, Global`d4]*
         TBgamma[1, Global`d3, Global`a$9148]) - 
      (TBgamma[1, Global`a$9157, Global`d2]*TBgamma[1, Global`d1, 
          Global`a$9157] - TBgamma[1, Global`a$9158, Global`d2]*
         TBgamma[1, Global`d1, Global`a$9158])*
       (TBgamma[1, Global`a$9159, Global`d4]*TBgamma[1, Global`d3, 
          Global`a$9159] - TBgamma[1, Global`a$9160, Global`d4]*
         TBgamma[1, Global`d3, Global`a$9160]) + 
      2*(TBgamma[0, Global`d1, Global`a$9149]*TBgamma[2, Global`a$9149, 
          Global`d2] - TBgamma[0, Global`a$9150, Global`d2]*
         TBgamma[2, Global`d1, Global`a$9150])*
       (TBgamma[0, Global`d3, Global`a$9151]*TBgamma[2, Global`a$9151, 
          Global`d4] - TBgamma[0, Global`a$9152, Global`d4]*
         TBgamma[2, Global`d3, Global`a$9152]) - 
      (TBgamma[1, Global`d1, Global`a$9161]*TBgamma[2, Global`a$9161, 
          Global`d2] - TBgamma[1, Global`a$9162, Global`d2]*
         TBgamma[2, Global`d1, Global`a$9162])*
       (TBgamma[1, Global`d3, Global`a$9163]*TBgamma[2, Global`a$9163, 
          Global`d4] - TBgamma[1, Global`a$9164, Global`d4]*
         TBgamma[2, Global`d3, Global`a$9164]) - 
      (TBgamma[1, Global`d1, Global`a$9170]*TBgamma[2, Global`a$9170, 
          Global`d2] - TBgamma[1, Global`a$9169, Global`d2]*
         TBgamma[2, Global`d1, Global`a$9169])*
       (TBgamma[1, Global`d3, Global`a$9172]*TBgamma[2, Global`a$9172, 
          Global`d4] - TBgamma[1, Global`a$9171, Global`d4]*
         TBgamma[2, Global`d3, Global`a$9171]) - 
      (TBgamma[2, Global`a$9173, Global`d2]*TBgamma[2, Global`d1, 
          Global`a$9173] - TBgamma[2, Global`a$9174, Global`d2]*
         TBgamma[2, Global`d1, Global`a$9174])*
       (TBgamma[2, Global`a$9175, Global`d4]*TBgamma[2, Global`d3, 
          Global`a$9175] - TBgamma[2, Global`a$9176, Global`d4]*
         TBgamma[2, Global`d3, Global`a$9176]) + 
      2*(TBgamma[0, Global`d1, Global`a$9153]*TBgamma[3, Global`a$9153, 
          Global`d2] - TBgamma[0, Global`a$9154, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9154])*
       (TBgamma[0, Global`d3, Global`a$9155]*TBgamma[3, Global`a$9155, 
          Global`d4] - TBgamma[0, Global`a$9156, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9156]) - 
      (TBgamma[1, Global`d1, Global`a$9165]*TBgamma[3, Global`a$9165, 
          Global`d2] - TBgamma[1, Global`a$9166, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9166])*
       (TBgamma[1, Global`d3, Global`a$9167]*TBgamma[3, Global`a$9167, 
          Global`d4] - TBgamma[1, Global`a$9168, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9168]) - 
      (TBgamma[2, Global`d1, Global`a$9177]*TBgamma[3, Global`a$9177, 
          Global`d2] - TBgamma[2, Global`a$9178, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9178])*
       (TBgamma[2, Global`d3, Global`a$9179]*TBgamma[3, Global`a$9179, 
          Global`d4] - TBgamma[2, Global`a$9180, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9180]) - 
      (TBgamma[1, Global`d1, Global`a$9182]*TBgamma[3, Global`a$9182, 
          Global`d2] - TBgamma[1, Global`a$9181, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9181])*
       (TBgamma[1, Global`d3, Global`a$9184]*TBgamma[3, Global`a$9184, 
          Global`d4] - TBgamma[1, Global`a$9183, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9183]) - 
      (TBgamma[2, Global`d1, Global`a$9186]*TBgamma[3, Global`a$9186, 
          Global`d2] - TBgamma[2, Global`a$9185, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9185])*
       (TBgamma[2, Global`d3, Global`a$9188]*TBgamma[3, Global`a$9188, 
          Global`d4] - TBgamma[2, Global`a$9187, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9187]) - 
      (TBgamma[3, Global`a$9189, Global`d2]*TBgamma[3, Global`d1, 
          Global`a$9189] - TBgamma[3, Global`a$9190, Global`d2]*
         TBgamma[3, Global`d1, Global`a$9190])*
       (TBgamma[3, Global`a$9191, Global`d4]*TBgamma[3, Global`d3, 
          Global`a$9191] - TBgamma[3, Global`a$9192, Global`d4]*
         TBgamma[3, Global`d3, Global`a$9192]))*TBT[Global`flavor, Global`af, 
      Global`F1, Global`F2]*TBT[Global`flavor, Global`af, Global`F3, 
      Global`F4]))/96}
