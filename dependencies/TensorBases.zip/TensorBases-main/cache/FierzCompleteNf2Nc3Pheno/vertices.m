(* Created with the Wolfram Language : www.wolfram.com *)
{(TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*(TBdeltaDirac[Global`d1, Global`d2]*
      TBdeltaDirac[Global`d3, Global`d4]*TBdeltaFund[Global`flavor, 
       Global`F1, Global`F2]*TBdeltaFund[Global`flavor, Global`F3, 
       Global`F4] - 2*Global`Nf*TBgamma5[Global`d1, Global`d2]*
      TBgamma5[Global`d3, Global`d4]*TBT[Global`flavor, Global`f$18674, 
       Global`F1, Global`F2]*TBT[Global`flavor, Global`f$18674, Global`F3, 
       Global`F4]) + TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    (-(TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, Global`d2]*
       TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F2]) + 
     2*Global`Nf*TBgamma5[Global`d1, Global`d4]*TBgamma5[Global`d3, 
       Global`d2]*TBT[Global`flavor, Global`f$18690, Global`F1, Global`F4]*
      TBT[Global`flavor, Global`f$18690, Global`F3, Global`F2]))/Global`Nf, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*
    (-(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]) + 
     2*Global`Nf*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
       Global`d4]*TBT[Global`flavor, Global`f$11435, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$11435, Global`F3, Global`F4]) + 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
      TBgamma5[Global`d1, Global`d4]*TBgamma5[Global`d3, Global`d2] - 
     2*Global`Nf*TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, 
       Global`d2]*TBT[Global`flavor, Global`f$11451, Global`F1, Global`F4]*
      TBT[Global`flavor, Global`f$11451, Global`F3, Global`F2]))/Global`Nf, 
 (TBepsFund[Global`flavor, Global`F2, Global`F4]*
   TBepsFund[Global`color, Global`a$127218, Global`A2, Global`A4]*
   (-(TBepsFund[Global`flavor, Global`F1, Global`F3]*
      TBepsFund[Global`color, Global`a$127218, Global`A1, Global`A3]*
      (8*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
         Global`d4] + 8*TBgamma[Global`vi1$40267, Global`d1, Global`d2]*
        TBgamma[Global`vi1$40267, Global`d3, Global`d4] + 
       (TBgamma[Global`vi2$40270, Global`dint2$40291, Global`d2]*
          TBgamma[Global`vi3$40273, Global`d1, Global`dint2$40291] - 
         TBgamma[Global`vi2$40270, Global`d1, Global`dint1$40285]*
          TBgamma[Global`vi3$40273, Global`dint1$40285, Global`d2])*
        (TBgamma[Global`vi2$40270, Global`dint2$40294, Global`d4]*
          TBgamma[Global`vi3$40273, Global`d3, Global`dint2$40294] - 
         TBgamma[Global`vi2$40270, Global`d3, Global`dint1$40288]*
          TBgamma[Global`vi3$40273, Global`dint1$40288, Global`d4]) + 
       8*(TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] + 
         TBgamma[Global`vi4$40276, Global`d1, Global`di1$40279]*
          TBgamma[Global`vi4$40276, Global`d3, Global`di2$40282]*
          TBgamma5[Global`di1$40279, Global`d2]*TBgamma5[Global`di2$40282, 
           Global`d4]))) + TBepsFund[Global`flavor, Global`F3, Global`F1]*
     TBepsFund[Global`color, Global`a$127218, Global`A3, Global`A1]*
     (8*TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, 
        Global`d2] + 8*TBgamma[Global`vi1$40310, Global`d1, Global`d4]*
       TBgamma[Global`vi1$40310, Global`d3, Global`d2] + 
      (TBgamma[Global`vi2$40313, Global`dint2$40334, Global`d2]*
         TBgamma[Global`vi3$40316, Global`d3, Global`dint2$40334] - 
        TBgamma[Global`vi2$40313, Global`d3, Global`dint1$40328]*
         TBgamma[Global`vi3$40316, Global`dint1$40328, Global`d2])*
       (TBgamma[Global`vi2$40313, Global`dint2$40337, Global`d4]*
         TBgamma[Global`vi3$40316, Global`d1, Global`dint2$40337] - 
        TBgamma[Global`vi2$40313, Global`d1, Global`dint1$40331]*
         TBgamma[Global`vi3$40316, Global`dint1$40331, Global`d4]) + 
      8*(TBgamma5[Global`d1, Global`d4]*TBgamma5[Global`d3, Global`d2] + 
        TBgamma[Global`vi4$40319, Global`d1, Global`di2$40325]*
         TBgamma[Global`vi4$40319, Global`d3, Global`di1$40322]*
         TBgamma5[Global`di1$40322, Global`d2]*TBgamma5[Global`di2$40325, 
          Global`d4]))))/16, 
 (-(TBdeltaFund[Global`color, Global`A1, Global`A4]*
     TBdeltaFund[Global`color, Global`A3, Global`A2]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
     TBgamma[0, Global`d1, Global`d4]*TBgamma[0, Global`d3, Global`d2]) + 
   TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4])/
  Global`Nf, (TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (-(TBdeltaLorentz[Global`i$8012, 0]*TBgamma[0, Global`d1, Global`d2]) + 
     TBgamma[Global`i$8012, Global`d1, Global`d2])*
    (-(TBdeltaLorentz[Global`i$8012, 0]*TBgamma[0, Global`d3, Global`d4]) + 
     TBgamma[Global`i$8012, Global`d3, Global`d4]) - 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    (-(TBdeltaLorentz[Global`i$8028, 0]*TBgamma[0, Global`d1, Global`d4]) + 
     TBgamma[Global`i$8028, Global`d1, Global`d4])*
    (-(TBdeltaLorentz[Global`i$8028, 0]*TBgamma[0, Global`d3, Global`d2]) + 
     TBgamma[Global`i$8028, Global`d3, Global`d2]))/Global`Nf, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$43806, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$43806, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$43806, 0]*TBgamma[0, Global`d3, 
          Global`d4]) + TBgamma[Global`i$43806, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$43806, 0]*TBgamma[0, Global`d1, 
          Global`dc$43809]) + TBgamma[Global`i$43806, Global`d1, 
        Global`dc$43809])*(-(TBdeltaLorentz[Global`i$43806, 0]*
         TBgamma[0, Global`d3, Global`dc$43812]) + TBgamma[Global`i$43806, 
        Global`d3, Global`dc$43812])*TBgamma5[Global`dc$43809, Global`d2]*
      TBgamma5[Global`dc$43812, Global`d4]) - 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    ((-(TBdeltaLorentz[Global`i$43828, 0]*TBgamma[0, Global`d1, Global`d4]) + 
       TBgamma[Global`i$43828, Global`d1, Global`d4])*
      (-(TBdeltaLorentz[Global`i$43828, 0]*TBgamma[0, Global`d3, 
          Global`d2]) + TBgamma[Global`i$43828, Global`d3, Global`d2]) - 
     (-(TBdeltaLorentz[Global`i$43828, 0]*TBgamma[0, Global`d1, 
          Global`dc$43834]) + TBgamma[Global`i$43828, Global`d1, 
        Global`dc$43834])*(-(TBdeltaLorentz[Global`i$43828, 0]*
         TBgamma[0, Global`d3, Global`dc$43831]) + TBgamma[Global`i$43828, 
        Global`d3, Global`dc$43831])*TBgamma5[Global`dc$43831, Global`d2]*
      TBgamma5[Global`dc$43834, Global`d4]))/Global`Nf, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
     TBgamma[0, Global`d1, Global`dc$8317]*TBgamma[0, Global`d3, 
       Global`dc$8320]*TBgamma5[Global`dc$8317, Global`d2]*
      TBgamma5[Global`dc$8320, Global`d4]) - 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    (TBgamma[0, Global`d1, Global`d4]*TBgamma[0, Global`d3, Global`d2] + 
     TBgamma[0, Global`d1, Global`dc$8339]*TBgamma[0, Global`d3, 
       Global`dc$8336]*TBgamma5[Global`dc$8336, Global`d2]*
      TBgamma5[Global`dc$8339, Global`d4]))/Global`Nf, 
 (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$264546]*TBgamma[0, Global`d3, 
       Global`dc$264549]*TBgamma5[Global`dc$264546, Global`d2]*
      TBgamma5[Global`dc$264549, Global`d4])*TBT[Global`color, 
     Global`a$264552, Global`A1, Global`A2]*TBT[Global`color, 
     Global`a$264552, Global`A3, Global`A4] + 
   TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    (-(TBgamma[0, Global`d1, Global`d4]*TBgamma[0, Global`d3, Global`d2]) + 
     TBgamma[0, Global`d1, Global`dc$264571]*TBgamma[0, Global`d3, 
       Global`dc$264568]*TBgamma5[Global`dc$264568, Global`d2]*
      TBgamma5[Global`dc$264571, Global`d4])*TBT[Global`color, 
     Global`a$264574, Global`A1, Global`A4]*TBT[Global`color, 
     Global`a$264574, Global`A3, Global`A2])/Global`Nf, 
 (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$27354, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$27354, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$27354, 0]*TBgamma[0, Global`d3, 
          Global`d4]) + TBgamma[Global`i$27354, Global`d3, Global`d4]) + 
     (-(TBdeltaLorentz[Global`i$27354, 0]*TBgamma[0, Global`d1, 
          Global`dc$27357]) + TBgamma[Global`i$27354, Global`d1, 
        Global`dc$27357])*(-(TBdeltaLorentz[Global`i$27354, 0]*
         TBgamma[0, Global`d3, Global`dc$27360]) + TBgamma[Global`i$27354, 
        Global`d3, Global`dc$27360])*TBgamma5[Global`dc$27357, Global`d2]*
      TBgamma5[Global`dc$27360, Global`d4])*TBT[Global`color, Global`a$27363, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$27363, Global`A3, 
     Global`A4] - TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    ((-(TBdeltaLorentz[Global`i$27379, 0]*TBgamma[0, Global`d1, Global`d4]) + 
       TBgamma[Global`i$27379, Global`d1, Global`d4])*
      (-(TBdeltaLorentz[Global`i$27379, 0]*TBgamma[0, Global`d3, 
          Global`d2]) + TBgamma[Global`i$27379, Global`d3, Global`d2]) + 
     (-(TBdeltaLorentz[Global`i$27379, 0]*TBgamma[0, Global`d1, 
          Global`dc$27385]) + TBgamma[Global`i$27379, Global`d1, 
        Global`dc$27385])*(-(TBdeltaLorentz[Global`i$27379, 0]*
         TBgamma[0, Global`d3, Global`dc$27382]) + TBgamma[Global`i$27379, 
        Global`d3, Global`dc$27382])*TBgamma5[Global`dc$27382, Global`d2]*
      TBgamma5[Global`dc$27385, Global`d4])*TBT[Global`color, Global`a$27388, 
     Global`A1, Global`A4]*TBT[Global`color, Global`a$27388, Global`A3, 
     Global`A2])/Global`Nf, 
 ((TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
    TBT[Global`color, Global`a$74583, Global`A1, Global`A2]*
    TBT[Global`color, Global`a$74583, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     2*Global`Nf*TBT[Global`flavor, Global`f$74586, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$74586, Global`F3, Global`F4]) - 
   (TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, Global`d2] - 
     TBgamma5[Global`d1, Global`d4]*TBgamma5[Global`d3, Global`d2])*
    TBT[Global`color, Global`a$74602, Global`A1, Global`A4]*
    TBT[Global`color, Global`a$74602, Global`A3, Global`A2]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F2] - 
     2*Global`Nf*TBT[Global`flavor, Global`f$74605, Global`F1, Global`F4]*
      TBT[Global`flavor, Global`f$74605, Global`F3, Global`F2]))/Global`Nf}
