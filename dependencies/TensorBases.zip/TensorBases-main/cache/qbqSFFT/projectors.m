(* Created with the Wolfram Language : www.wolfram.com *)
{((-1/4*I)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBgamma[0, Global`d1, Global`d2])/Global`Nc, 
 ((I/4)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBgamma[Global`mu$52, Global`d1, Global`d2]*
   TBvecs[Global`p1, Global`mu$52])/(Global`Nc*TBsps[Global`p1, Global`p1]), 
 (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaFund[Global`color, Global`A1, 
    Global`A2])/(4*Global`Nc)}
