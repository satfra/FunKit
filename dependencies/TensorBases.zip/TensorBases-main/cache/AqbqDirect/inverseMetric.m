(* Created with the Wolfram Language : www.wolfram.com *)
{{(6*Global`Nf - 6*Global`Nc^2*Global`Nf)^(-1), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, (TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
    TBsp[Global`p3, Global`p3])/(16*(-1 + Global`Nc^2)*Global`Nf*
    (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
      TBsp[Global`p3, Global`p3])), 
  (TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
    TBsp[Global`p3, Global`p3])/(16*(-1 + Global`Nc^2)*Global`Nf*
    (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
      TBsp[Global`p3, Global`p3])), 
  (TBsp[Global`p2, Global`p2] - TBsp[Global`p3, Global`p3])/
   (16*(-1 + Global`Nc^2)*Global`Nf*(TBsp[Global`p2, Global`p3]^2 - 
     TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3])), 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, (TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
    TBsp[Global`p3, Global`p3])/(16*(-1 + Global`Nc^2)*Global`Nf*
    (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
      TBsp[Global`p3, Global`p3])), 
  -1/16*(TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
     TBsp[Global`p3, Global`p3])/((-1 + Global`Nc^2)*Global`Nf*
     (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
       TBsp[Global`p3, Global`p3])), 
  (-TBsp[Global`p2, Global`p2] + TBsp[Global`p3, Global`p3])/
   (16*(-1 + Global`Nc^2)*Global`Nf*(TBsp[Global`p2, Global`p3]^2 - 
     TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3])), 0, 0, 0, 0, 0, 
  0, 0, 0}, {0, (-TBsp[Global`p2, Global`p2] + TBsp[Global`p3, Global`p3])/
   (16*(-1 + Global`Nc^2)*Global`Nf*(TBsp[Global`p2, Global`p3]^2 - 
     TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3])), 
  (TBsp[Global`p2, Global`p2] - TBsp[Global`p3, Global`p3])/
   (16*(-1 + Global`Nc^2)*Global`Nf*(TBsp[Global`p2, Global`p3]^2 - 
     TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3])), 
  (TBsp[Global`p2, Global`p2] - 2*TBsp[Global`p2, Global`p3] + 
    TBsp[Global`p3, Global`p3])/(16*(-1 + Global`Nc^2)*Global`Nf*
    (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
      TBsp[Global`p3, Global`p3])), 0, 0, 0, 
  -1/8*1/((-1 + Global`Nc^2)*Global`Nf*(TBsp[Global`p2, Global`p3]^2 - 
      TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3])), 0, 0, 0, 0}, 
 {0, 0, 0, 0, (3*TBsp[Global`p2, Global`p2]^2 - 
    4*TBsp[Global`p2, Global`p3]^2 - 2*TBsp[Global`p2, Global`p2]*
     TBsp[Global`p3, Global`p3] + 3*TBsp[Global`p3, Global`p3]^2)/
   (64*(-1 + Global`Nc^2)*Global`Nf*(TBsp[Global`p2, Global`p3]^2 - 
      TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3])^2), 
  (3*(TBsp[Global`p2, Global`p2] - TBsp[Global`p3, Global`p3])*
    (TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
     TBsp[Global`p3, Global`p3]))/(64*(-1 + Global`Nc^2)*Global`Nf*
    (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
       TBsp[Global`p3, Global`p3])^2), 
  1/(8*(-1 + Global`Nc^2)*Global`Nf*(TBsp[Global`p2, Global`p3]^2 - 
     TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3])), 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, (-3*(TBsp[Global`p2, Global`p2] - TBsp[Global`p3, Global`p3])*
    (TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
     TBsp[Global`p3, Global`p3]))/(64*(-1 + Global`Nc^2)*Global`Nf*
    (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
       TBsp[Global`p3, Global`p3])^2), 
  (-3*(TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
      TBsp[Global`p3, Global`p3])^2)/(64*(-1 + Global`Nc^2)*Global`Nf*
    (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
       TBsp[Global`p3, Global`p3])^2), 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 1/(8*(-1 + Global`Nc^2)*Global`Nf*
    (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
      TBsp[Global`p3, Global`p3])), 0, 
  1/(4*(-1 + Global`Nc^2)*Global`Nf*(TBsp[Global`p2, Global`p3]^2 - 
     TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3])), 0, 0, 0, 0, 0}, 
 {0, 0, 0, -1/8*1/((-1 + Global`Nc^2)*Global`Nf*
     (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
       TBsp[Global`p3, Global`p3])), 0, 0, 0, 
  (-3*(TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
     TBsp[Global`p3, Global`p3]))/(16*(-1 + Global`Nc^2)*Global`Nf*
    (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
       TBsp[Global`p3, Global`p3])^2), 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 
  ((TBsp[Global`p2, Global`p2] - 2*TBsp[Global`p2, Global`p3] + 
     TBsp[Global`p3, Global`p3])*(TBsp[Global`p2, Global`p2] + 
     2*TBsp[Global`p2, Global`p3] + TBsp[Global`p3, Global`p3]))/
   (8*(-1 + Global`Nc^2)*Global`Nf*(TBsp[Global`p2, Global`p3]^2 - 
     TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3])), 0, 
  (TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
    TBsp[Global`p3, Global`p3])/(8*(-1 + Global`Nc^2)*Global`Nf*
    (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
      TBsp[Global`p3, Global`p3])), 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 
  -1/2*(TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
     TBsp[Global`p3, Global`p3])/((-1 + Global`Nc^2)*Global`Nf*
     (TBsp[Global`p2, Global`p2] - TBsp[Global`p3, Global`p3])^2), 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, (TBsp[Global`p2, Global`p2] + 
    2*TBsp[Global`p2, Global`p3] + TBsp[Global`p3, Global`p3])/
   (8*(-1 + Global`Nc^2)*Global`Nf*(TBsp[Global`p2, Global`p3]^2 - 
     TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3])), 0, 
  -1/8*(TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
      TBsp[Global`p3, Global`p3])^2/((-1 + Global`Nc^2)*Global`Nf*
     (TBsp[Global`p2, Global`p2] - TBsp[Global`p3, Global`p3])^2*
     (-TBsp[Global`p2, Global`p3]^2 + TBsp[Global`p2, Global`p2]*
       TBsp[Global`p3, Global`p3])), 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  -1/2*(TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p2, Global`p3] + 
     TBsp[Global`p3, Global`p3])/((-1 + Global`Nc^2)*Global`Nf*
     (TBsp[Global`p2, Global`p2] - TBsp[Global`p3, Global`p3])^2*
     (-TBsp[Global`p2, Global`p3]^2 + TBsp[Global`p2, Global`p2]*
       TBsp[Global`p3, Global`p3]))}}
