(* Created with the Wolfram Language : www.wolfram.com *)
{{(6*Global`Nf - 6*Global`Nc^2*Global`Nf)^(-1), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0}, {0, 1/(6*(-1 + Global`Nc^2)*Global`Nf), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, (12*Global`Nf - 12*Global`Nc^2*Global`Nf)^(-1), 0, 0, 0, 0, 0, 0, 0, 
  0, 0}, {0, 0, 0, (6*Global`Nf - 6*Global`Nc^2*Global`Nf)^(-1), 0, 0, 0, 0, 
  0, 0, 0, 0}, {0, 0, 0, 0, (6*Global`Nf - 6*Global`Nc^2*Global`Nf)^(-1), 0, 
  0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 
  (12*Global`Nf - 12*Global`Nc^2*Global`Nf)^(-1), 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 1/(12*(-1 + Global`Nc^2)*Global`Nf), 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, (3*Global`Nf - 3*Global`Nc^2*Global`Nf)^(-1), 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 
  ((TBsp[Global`p2, Global`p2] - 2*TBsp[Global`p2, Global`p3] + 
     TBsp[Global`p3, Global`p3])*(TBsp[Global`p2, Global`p2] + 
     2*TBsp[Global`p2, Global`p3] + TBsp[Global`p3, Global`p3]))/
   (8*(-1 + Global`Nc^2)*Global`Nf*(TBsp[Global`p2, Global`p3]^2 - 
     TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3])), 0, 
  (Sqrt[TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p3] + 
      TBsp[Global`p3, Global`p3]]*(TBsp[Global`p2, Global`p2] + 
     2*TBsp[Global`p2, Global`p3] + TBsp[Global`p3, Global`p3]))/
   (4*Sqrt[6]*(-1 + Global`Nc^2)*Global`Nf*(TBsp[Global`p2, Global`p3]^2 - 
     TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3])), 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 
  -1/3*((TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p3] + 
      TBsp[Global`p3, Global`p3])*(TBsp[Global`p2, Global`p2] + 
      2*TBsp[Global`p2, Global`p3] + TBsp[Global`p3, Global`p3]))/
    ((-1 + Global`Nc^2)*Global`Nf*(TBsp[Global`p2, Global`p2] - 
       TBsp[Global`p3, Global`p3])^2), 0, 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 
  (Sqrt[TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p3] + 
      TBsp[Global`p3, Global`p3]]*(TBsp[Global`p2, Global`p2] + 
     2*TBsp[Global`p2, Global`p3] + TBsp[Global`p3, Global`p3]))/
   (4*Sqrt[6]*(-1 + Global`Nc^2)*Global`Nf*(TBsp[Global`p2, Global`p3]^2 - 
     TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3])), 0, 
  -1/12*((TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p3] + 
      TBsp[Global`p3, Global`p3])*(TBsp[Global`p2, Global`p2] + 
       2*TBsp[Global`p2, Global`p3] + TBsp[Global`p3, Global`p3])^2)/
    ((-1 + Global`Nc^2)*Global`Nf*(TBsp[Global`p2, Global`p2] - 
       TBsp[Global`p3, Global`p3])^2*(-TBsp[Global`p2, Global`p3]^2 + 
      TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3])), 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  ((TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p3] + 
     TBsp[Global`p3, Global`p3])*(TBsp[Global`p2, Global`p2] + 
     2*TBsp[Global`p2, Global`p3] + TBsp[Global`p3, Global`p3]))/
   (3*(-1 + Global`Nc^2)*Global`Nf*(TBsp[Global`p2, Global`p2] - 
      TBsp[Global`p3, Global`p3])^2*(TBsp[Global`p2, Global`p3]^2 - 
     TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3]))}}
