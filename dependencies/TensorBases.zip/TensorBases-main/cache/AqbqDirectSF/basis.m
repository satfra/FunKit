(* Created with the Wolfram Language : www.wolfram.com *)
{I*TBgamma[Global`rho, Global`d2, Global`d3]*TBT[Global`color, Global`a1, 
   Global`A2, Global`A3]*Global`transProj[-Global`p2 - Global`p3, Global`mu, 
   Global`rho], TBdeltaDirac[Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho], 
 TBgamma[Global`mu$37791, Global`d2, Global`md]*
  TBgamma[Global`rho, Global`md, Global`d3]*TBT[Global`color, Global`a1, 
   Global`A2, Global`A3]*(TBvec[Global`p2, Global`mu$37791] - 
   TBvec[Global`p3, Global`mu$37791])*Global`transProj[
   -Global`p2 - Global`p3, Global`mu, Global`rho], 
 -(TBgamma[Global`mu$37793, Global`d2, Global`md]*
   TBgamma[Global`rho, Global`md, Global`d3]*TBT[Global`color, Global`a1, 
    Global`A2, Global`A3]*(TBvec[Global`p2, Global`mu$37793] + 
    TBvec[Global`p3, Global`mu$37793])*Global`transProj[
    -Global`p2 - Global`p3, Global`mu, Global`rho]), 
 I*TBgamma[Global`mu$37795, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`mu$37795] + TBvec[Global`p3, Global`mu$37795])*
  (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho], 
 (-1/3*I)*TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  ((4*TBgamma[Global`rho, Global`d2, Global`d3]*
     (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
       TBsp[Global`p3, Global`p3]))/(TBsp[Global`p2, Global`p2] + 
     2*TBsp[Global`p2, Global`p3] + TBsp[Global`p3, Global`p3]) + 
   3*TBgamma[Global`mu$37797, Global`d2, Global`d3]*
    (TBvec[Global`p2, Global`mu$37797] - TBvec[Global`p3, Global`mu$37797])*
    (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho]))*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho], 
 (I/2)*TBgamma[Global`rho, Global`dint2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (-(TBgamma[Global`mu$37799, Global`dint1, Global`dint2]*
     TBgamma[Global`mu$37801, Global`d2, Global`dint1]*
     TBvec[Global`p2, Global`mu$37799]*TBvec[Global`p3, Global`mu$37801]) + 
   TBgamma[Global`mu$37803, Global`d2, Global`dint1]*
    TBgamma[Global`mu$37805, Global`dint1, Global`dint2]*
    TBvec[Global`p2, Global`mu$37803]*TBvec[Global`p3, Global`mu$37805])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho], 
 (TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   (-(TBgamma[Global`mu$37807, Global`md1, Global`d3]*
      TBgamma[Global`mu$37809, Global`d2, Global`md1]*
      TBvec[Global`p2, Global`mu$37807]*TBvec[Global`p3, Global`mu$37809]) + 
    TBgamma[Global`mu$37811, Global`d2, Global`md1]*
     TBgamma[Global`mu$37813, Global`md1, Global`d3]*
     TBvec[Global`p2, Global`mu$37811]*TBvec[Global`p3, Global`mu$37813])*
   (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho])*
   Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho])/2, 
 I*Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho]*
  TBgamma[Global`rho, Global`d2, Global`d3]*TBT[Global`color, Global`a1, 
   Global`A2, Global`A3], Global`longProj[-Global`p2 - Global`p3, Global`mu, 
   Global`rho]*TBdeltaDirac[Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho]), 
 (-I)*Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho]*
  TBgamma[Global`mu$37815, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`mu$37815] - TBvec[Global`p3, Global`mu$37815])*
  (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho]), 
 (Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho]*
   TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   (-(TBgamma[Global`mu$37817, Global`md1, Global`d3]*
      TBgamma[Global`mu$37819, Global`d2, Global`md1]*
      TBvec[Global`p2, Global`mu$37817]*TBvec[Global`p3, Global`mu$37819]) + 
    TBgamma[Global`mu$37821, Global`d2, Global`md1]*
     TBgamma[Global`mu$37823, Global`md1, Global`d3]*
     TBvec[Global`p2, Global`mu$37821]*TBvec[Global`p3, Global`mu$37823])*
   (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho]))/2}
