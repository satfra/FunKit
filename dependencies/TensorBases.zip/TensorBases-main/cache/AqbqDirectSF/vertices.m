(* Created with the Wolfram Language : www.wolfram.com *)
{I*TBgamma[Global`rho$10729, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho$10729], 
 TBdeltaDirac[Global`d2, Global`d3]*TBT[Global`color, Global`a1, Global`A2, 
   Global`A3]*(TBvec[Global`p2, Global`rho$2840] - 
   TBvec[Global`p3, Global`rho$2840])*Global`transProj[
   -Global`p2 - Global`p3, Global`mu, Global`rho$2840], 
 TBgamma[Global`mu$2823, Global`d2, Global`md$2829]*
  TBgamma[Global`rho$2826, Global`md$2829, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`mu$2823] - TBvec[Global`p3, Global`mu$2823])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2826], 
 -(TBgamma[Global`mu$3118, Global`d2, Global`md$3124]*
   TBgamma[Global`rho$3121, Global`md$3124, Global`d3]*
   TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   (TBvec[Global`p2, Global`mu$3118] + TBvec[Global`p3, Global`mu$3118])*
   Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho$3121]), 
 I*TBgamma[Global`mu$3344, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`mu$3344] + TBvec[Global`p3, Global`mu$3344])*
  (TBvec[Global`p2, Global`rho$3347] - TBvec[Global`p3, Global`rho$3347])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho$3347], 
 (-1/3*I)*TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  ((4*TBgamma[Global`rho$3179, Global`d2, Global`d3]*
     (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
       TBsp[Global`p3, Global`p3]))/(TBsp[Global`p2, Global`p2] + 
     2*TBsp[Global`p2, Global`p3] + TBsp[Global`p3, Global`p3]) + 
   3*TBgamma[Global`mu$3176, Global`d2, Global`d3]*
    (TBvec[Global`p2, Global`mu$3176] - TBvec[Global`p3, Global`mu$3176])*
    (TBvec[Global`p2, Global`rho$3179] - TBvec[Global`p3, Global`rho$3179]))*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho$3179], 
 (I/2)*TBgamma[Global`rho$2739, Global`dint2$2745, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (-(TBgamma[Global`mu$2727, Global`dint1$2742, Global`dint2$2745]*
     TBgamma[Global`mu$2730, Global`d2, Global`dint1$2742]*
     TBvec[Global`p2, Global`mu$2727]*TBvec[Global`p3, Global`mu$2730]) + 
   TBgamma[Global`mu$2733, Global`d2, Global`dint1$2742]*
    TBgamma[Global`mu$2736, Global`dint1$2742, Global`dint2$2745]*
    TBvec[Global`p2, Global`mu$2733]*TBvec[Global`p3, Global`mu$2736])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2739], 
 (TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   (-(TBgamma[Global`mu$2774, Global`md1$2789, Global`d3]*
      TBgamma[Global`mu$2777, Global`d2, Global`md1$2789]*
      TBvec[Global`p2, Global`mu$2774]*TBvec[Global`p3, Global`mu$2777]) + 
    TBgamma[Global`mu$2780, Global`d2, Global`md1$2789]*
     TBgamma[Global`mu$2783, Global`md1$2789, Global`d3]*
     TBvec[Global`p2, Global`mu$2780]*TBvec[Global`p3, Global`mu$2783])*
   (TBvec[Global`p2, Global`rho$2786] - TBvec[Global`p3, Global`rho$2786])*
   Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2786])/2, 
 I*Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2523]*
  TBgamma[Global`rho$2523, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3], 
 Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2329]*
  TBdeltaDirac[Global`d2, Global`d3]*TBT[Global`color, Global`a1, Global`A2, 
   Global`A3]*(TBvec[Global`p2, Global`rho$2329] - 
   TBvec[Global`p3, Global`rho$2329]), 
 (-I)*Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2565]*
  TBgamma[Global`mu$2562, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`mu$2562] - TBvec[Global`p3, Global`mu$2562])*
  (TBvec[Global`p2, Global`rho$2565] - TBvec[Global`p3, Global`rho$2565]), 
 (Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2616]*
   TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   (-(TBgamma[Global`mu$2604, Global`md1$2619, Global`d3]*
      TBgamma[Global`mu$2607, Global`d2, Global`md1$2619]*
      TBvec[Global`p2, Global`mu$2604]*TBvec[Global`p3, Global`mu$2607]) + 
    TBgamma[Global`mu$2610, Global`d2, Global`md1$2619]*
     TBgamma[Global`mu$2613, Global`md1$2619, Global`d3]*
     TBvec[Global`p2, Global`mu$2610]*TBvec[Global`p3, Global`mu$2613])*
   (TBvec[Global`p2, Global`rho$2616] - TBvec[Global`p3, Global`rho$2616]))/2}
