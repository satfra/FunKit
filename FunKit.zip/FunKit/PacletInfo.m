(* ::Package:: *)

PacletObject[
    <|
        "Name" -> "FunKit",
        "Version" -> "1.0.0",
        "WolframVersion" -> "13.3+",
        "Extensions" ->
            {
                {
                    "Kernel",
                    "Context" -> {
                        { "FunKit`" , "FunKit.m" }
                    }
                },
                {
                    "Documentation",
                    "Language" -> "English"
                }
            }
    |>
]
